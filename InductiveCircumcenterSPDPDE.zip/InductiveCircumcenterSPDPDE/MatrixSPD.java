 

import Jama.*;

public class MatrixSPD
{
public static double sqr(double x){return x*x;}  
  public static boolean Dominate(Matrix M, Matrix [] set)
{
  for (int i=0; i<set.length; i++)
  {
    if (!isSPD( M.minus(set[i]) ) )
      return false;
  }

  return true;
}


public static boolean Dominated(Matrix M, Matrix [] set)
{
  for (int i=0; i<set.length; i++)
  {
    if (!isSPD( set[i].minus(M) ) )
      return false;
  }

  return true;
}



public static boolean isSPD(Matrix M)
{
  boolean spd=true;
  EigenvalueDecomposition evd=M.eig();
  Matrix diag=evd.getD();

  for (int i=0; i<diag.getColumnDimension(); i++)
    if (diag.get(i, i)<0)
      spd=false;  

  return spd;
}


public static Matrix randomGL(int d)
{
int i,j;
double [][] array=new double[d][d];
Matrix M;
  double eps=1.0-3;
  
for(i=0;i<d;i++)
  for(j=0;j<=i;j++)
    {array[i][j]=Math.random();}
 
 M=new Matrix(array);
 
if (Math.abs(M.det())>eps) return M; else  return randomGL(d);   
}
 
 
 
 public static double [] eigenvalues2x2(Matrix M)
 {
   double [] res=new double[2];
   double tr=M.trace();
   double det=M.det();
   
   res[0]=(tr-Math.sqrt(tr*tr-4*det))/2.0;
   res[1]=(tr+Math.sqrt(tr*tr-4*det))/2.0;
   return res;
 }

public static Matrix randomSPDCholesky(int d)
{
int i,j;
double [][] array=new double[d][d];
Matrix L;
  
for(i=0;i<d;i++)
  for(j=0;j<=i;j++)
    {array[i][j]=Math.random();}

L=new Matrix(array);
// Cholesky
return L.times(L.transpose());  
}  


// Non-integer power of a matrix
public static Matrix power(Matrix M, double p)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();
// power on the positive eigen values
for(int i=0; i<D.getColumnDimension();i++)
  D.set(i,i,Math.pow(D.get(i,i),p));

Matrix V=evd.getV();

return V.times(D.times(V.transpose()));
}



public static double LambdaMax(Matrix M)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

double lmax=0;
for(int i=0; i<D.getColumnDimension();i++)
  if (D.get(i,i)>lmax) lmax=D.get(i,i);

return lmax;
}


public static double LambdaMin(Matrix M)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

double lmin=Double.MAX_VALUE;
for(int i=0; i<D.getColumnDimension();i++)
  if (D.get(i,i)<lmin) lmin=D.get(i,i);

return lmin;
}



public static Matrix Min2Sqrt(Matrix P, Matrix Q)
{
 Matrix PminusQ= P.minus(Q);
return ( sqrt((PminusQ.times(PminusQ.transpose()))).times(0.5)).plus( (P.plus(Q)).times(0.5)) ;  
}

public static Matrix Min2Abs(Matrix P, Matrix Q)
{
 Matrix PminusQ= P.minus(Q);
return ((PminusQ).times(0.5)).plus( (P.plus(Q)).times(0.5)) ;  
}

public static Matrix Min2 (Matrix P, Matrix Q)
{return Min2Abs(P,Q);
}

public static Matrix Min2GL(Matrix P, Matrix Q)
{
Matrix I=Matrix.identity(P.getRowDimension(),P.getRowDimension());
Matrix L=(new CholeskyDecomposition(P)).getL(); 
Matrix term=((L.inverse()).times(Q)).times((L.inverse()).transpose());
return (L.times(Min2Sqrt(I,term))).times(L.transpose());
}



 

public static Matrix Max2(Matrix P, Matrix Q)
{
return Min2(P.inverse(),Q.inverse()).inverse();  
}


// Absolute value of a SPD matrix  
public static Matrix abs(Matrix M)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

// Logarithm on the positive eigen values
for(int i=0; i<D.getColumnDimension();i++)
  D.set(i,i,Math.abs(D.get(i,i)));

Matrix V=evd.getV();

return V.times(D.times(V.transpose()));
}

// sqrtof a SPD matrix  
public static Matrix sqrt(Matrix M)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

// Logarithm on the positive eigen values
for(int i=0; i<D.getColumnDimension();i++)
  D.set(i,i,Math.sqrt(D.get(i,i)));

Matrix V=evd.getV();

return V.times(D.times(V.transpose()));
}


// Exponential of a SPD matrix  
public static Matrix exp(Matrix M)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

// exponential on the positive eigen values
for(int i=0; i<D.getColumnDimension();i++)
  D.set(i,i,Math.exp(D.get(i,i)));

Matrix V=evd.getV();

return V.times(D.times(V.transpose()));
}

// Logarithm of a SPD matrix  
public static Matrix log(Matrix M)
{
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

// Logarithm on the positive eigen values
for(int i=0; i<D.getColumnDimension();i++)
  D.set(i,i,Math.log(D.get(i,i)));

Matrix V=evd.getV();

return V.times(D.times(V.transpose()));
}  


public static Matrix LogEuclideanMean(Matrix [] set)
{
int i;
int n=set.length; 
int d=set[0].getColumnDimension();
Matrix R=new Matrix(d,d);

for(i=0;i<n;i++)
{
R=R.plus(log(set[i]).times(1.0/n))  ;
}

return exp(R);
}

public static double RiemannianDistance(Matrix P, Matrix Q)
{
double result=0.0d;
Matrix M=P.inverse().times(Q);
EigenvalueDecomposition evd=M.eig();
Matrix D=evd.getD();

for(int i=0; i<D.getColumnDimension();i++)
  result+=sqr(Math.log(D.get(i,i)));

return Math.sqrt(result);  
}

public static Matrix RiemannianGeodesic(Matrix P, Matrix Q, double lambda)
{
Matrix result;
Matrix Phalf=power(P,0.5);
Matrix Phalfinv=power(P,-0.5);

result=Phalfinv.times(Q).times(Phalfinv);
result=power(result,lambda);

return (Phalf.times(result)).times(Phalf);  
}

// Cut the geodesic [PQ] into [PR] and [RQ] so that d(P,R)=cut*d(P,Q)
// For SPD matrices, the geodesic lambda split is equal to cut so we do not need the while loop
// see paper for explanation.
public static Matrix CutGeodesic(Matrix P, Matrix Q, double cut)
{
double dist=RiemannianDistance(P,Q);
double minl=0, maxl=1.0, maxm=0.5;
Matrix M=null; 
double distc;

while (maxl-minl>1.0e-5)
{
maxm=0.5*(minl+maxl);
M=RiemannianGeodesic(P,Q,maxm);
distc=RiemannianDistance(P,M);

if (distc>dist*cut)
  maxl=maxm; else minl=maxm;  
}

//System.out.println("wanted:"+cut+" obtained for lambda="+maxm);
  
return M;  
}

// Maximum distance from the current centerpoint C
public static double MaxCenter(Matrix[] set, Matrix C)
{
double result=0.0;

for(int i=0;i<set.length;i++)
  {
  if  (RiemannianDistance(set[i],C)>result)
    result=RiemannianDistance(set[i],C);
  }

return result;  
}

// Return the index of the farthest point
public static int argMaxCenter(Matrix[] set, Matrix C)
{
int winner=-1; double result=0.0;

for(int i=0;i<set.length;i++)
  {
  if  (RiemannianDistance(set[i],C)>result)
    {result=RiemannianDistance(set[i],C); winner=i;}
  }

return winner;  
}

// Performs the generalization of Badoiu-Clarkson algorithm:
// see paper: Smaller core-sets for balls. SODA 2003: 801-802
// see On the Riemannian 1-Center 
public static Matrix MinMax(Matrix[] set, int nbIter)
{
int i,j,f;
double ratio;
Matrix C=new Matrix(set[0].getArrayCopy());
  
for(i=1;i<=nbIter;i++)
{
f=argMaxCenter(set,C);
ratio=1.0/(i+1);
C=CutGeodesic(C,set[f],ratio);  
//System.out.println(i+"\t"+MaxCenter(set,C));
}

return C;  
}

static Matrix COpt;
static double ropt;

// Print on the console the statistics
public static Matrix MinMaxVerbose(Matrix[] set, int nbIter)
{
int i=0,j,f;
double ratio, distance, radius;

Matrix C=new Matrix(set[0].getArrayCopy());
distance=RiemannianDistance(C,COpt)/ropt;
radius=RiemannianDistance(C,set[argMaxCenter(set,C)]);

System.out.println(i+"\t"+distance+"\t"+radius);
  
for(i=1;i<=nbIter;i++)
{
f=argMaxCenter(set,C);
ratio=1.0/(i+1);
C=CutGeodesic(C,set[f],ratio);  

distance=RiemannianDistance(C,COpt)/ropt;
radius=RiemannianDistance(C,set[argMaxCenter(set,C)]);
System.out.println(i+"\t"+distance+"\t"+radius);
}

return C;  
}


  
public static void Test()
{
// Number of matrices
int n=100;

// Dimension of square matrices
int d=5;

System.out.println("Approximating the Riemannian Minimax\n on "+n+" symmetric positive definite matrices (SPD) of dimension "+d);

int i;

// Create data-set
Matrix [] set=new Matrix[n];
for(i=0;i<n;i++)
    {
    set[i]=randomSPDCholesky(d);
    }

// Norm-based center
System.out.println("Log-Euclidean SPD mean:");
Matrix LECenter=LogEuclideanMean(set);
LECenter.print(6,5);

// Intrinsic circumcenter
System.out.println("Riemannian intrinsic circumcenter BC-AN (1000 iterations):");
Matrix C=MinMax(set,1000);
C.print(6,5);

 

System.out.println("That is all folks!");  
  
}  
  
}
