import Jama.*;

abstract class GaugeNorm
{
  abstract double Phi(double[] u);
  
  
  double Norm(Matrix M)
  {
    EigenvalueDecomposition evd=M.eig();
    Matrix D=evd.getD();
    int d=M.getRowDimension();
    
 
    double[] eigenvalue=new double [d];

 for(int i=0; i<d;i++)
   eigenvalue[i]=D.get(i,i);
   
    return Phi(eigenvalue);
  }
  
  
  double Distance(Matrix P1, Matrix P2)
  {
    Matrix P1halfinv=MatrixSPD.power(P1,-0.5);
    Matrix tmp=MatrixSPD.log(P1halfinv.times(P2.times(P1halfinv)));
    return Norm(tmp);
  }
  
  
  
  public static Matrix Geodesic(Matrix P, Matrix Q, double lambda)
{
Matrix result;
Matrix Phalf=MatrixSPD.power(P,0.5);
Matrix Phalfinv=MatrixSPD.power(P,-0.5);

result=Phalfinv.times(Q).times(Phalfinv);
result=MatrixSPD.power(result,lambda);

return (Phalf.times(result)).times(Phalf);  
}



  public   int argMaxCenter(Matrix[] set, Matrix C)
{
int winner=-1; double result=0.0;

for(int i=0;i<set.length;i++)
  {
  if  (Distance(set[i],C)>result)
    {result=Distance(set[i],C); winner=i;}
  }

return winner;  
}

public   Matrix MinMax(Matrix[] set, int nbIter)
{
int i,j,f;
double ratio;
Matrix C=new Matrix(set[0].getArrayCopy());
  
for(i=1;i<=nbIter;i++)
{
f=argMaxCenter(set,C);
ratio=1.0/(i+1);
C=Geodesic(C,set[f],ratio);  
}

return C;  
}
 
  

  
}
