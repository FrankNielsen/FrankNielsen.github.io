class SchattenNorm extends GaugeNorm
{
 double p;
 
 
  SchattenNorm(double pp){p=pp;}
  
   double Phi(double[] u)
   {
    double res=0;
    int i;
    int d=u.length;
    for(i=0;i<d;i++)
    {
    res=res+Math.pow(Math.abs(u[i]),p);
}
    res=Math.pow(res,1.0/p);
    return res;
     
   }
  
  
}
