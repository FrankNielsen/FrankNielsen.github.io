import Jama.*;

class Thompson
{
  static double max(double a, double b) {
    if (a>b) return a; 
    else return b;
  }

  public static double Distance(Matrix P1, Matrix P2)
  {
    Matrix tmp1=P1.times(P2.inverse());
    Matrix tmp2=P2.times(P1.inverse());

    return Math.log(max(MatrixSPD.LambdaMax(tmp1), MatrixSPD.LambdaMax(tmp2)));
  }

  public static Matrix Geodesic(Matrix P1, Matrix P2, double t)
  {
    double a, b;
    double lM, lm;
    Matrix tmp=P2.times(P1.inverse());
    lM=MatrixSPD.LambdaMax(tmp);
    lm=MatrixSPD.LambdaMin(tmp);

    a=(Math.pow(lM, t)-Math.pow(lm, t))/(lM-lm);
    b=(lM*Math.pow(lm, t)-lm*Math.pow(lM, t))/(lM-lm);

    return (P2.times(a)).plus(P1.times(b));
  }


  public static int argMaxCenter(Matrix[] set, Matrix C)
  {
    int winner=-1; 
    double result=0.0;

    for (int i=0; i<set.length; i++)
    {
      if  (Distance(set[i], C)>result)
      {
        result=Distance(set[i], C); 
        winner=i;
      }
    }

    return winner;
  }

  public static Matrix MinMax(Matrix[] set, int nbIter)
  {
    int i, j, f;
    double ratio;
    Matrix C=new Matrix(set[0].getArrayCopy());

    for (i=1; i<=nbIter; i++)
    {
      f=argMaxCenter(set, C);
      ratio=1.0/(i+1);
      C=Geodesic(C, set[f], ratio);
    }

    return C;
  }


  public static void Test()
  {
    double [][]array1={{0.95, -0.6}, {-0.6, 1.1}};
    double [][]array2={{1, 0.5}, {0.5, 2.1}};
    double [][]array3={{2.5, -0.2}, {-0.2, 1.2}};

    Matrix [] set=new Matrix[3];

    set[0]=new Matrix(array1);
    set[1]=new Matrix(array2);
    set[2]=new Matrix(array3);

    //Matrix IMR=MinMax(set,100000);
    Matrix IMR=MinMax(set, 300);

    IMR.print(6, 3);
  }
}
