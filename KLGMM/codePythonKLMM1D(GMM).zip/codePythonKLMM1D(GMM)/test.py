#!/usr/bin/env python

from __future__ import print_function

from MM import RMM, GMM
from Distribution import Rayleigh1D, Gaussian1D
import numpy as np
import matplotlib.pyplot as plt
import sys, time

from matplotlib import rc
rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
rc('text', usetex=True)

gmm1 = GMM( [
              Gaussian1D( -5,   1, alpha=.5 ),
              Gaussian1D( -2,  .5, alpha=1 ),
              Gaussian1D( 5,   .3, alpha=2 ),
              Gaussian1D( 10,  .5, alpha=2 ),
              Gaussian1D( 15,  .4, alpha=.5 ),
              Gaussian1D( 25,  .5, alpha=3 ),
              Gaussian1D( 30,   2, alpha=1 ),
            ] )

gmm2 = GMM( [
              Gaussian1D(-16, .5,  alpha=1 ),
              Gaussian1D(-12, .2,  alpha=1 ),
              Gaussian1D(-8,  .5,  alpha=1 ),
              Gaussian1D(-4,  .2,  alpha=1 ),
              Gaussian1D( 0,  .5,  alpha=2 ),
              Gaussian1D( 4,  .2,  alpha=1 ),
              Gaussian1D( 8,  .5,  alpha=1 ),
              Gaussian1D(12,  .2,  alpha=1 ),
              Gaussian1D(16,  .5,  alpha=1 ),
            ] )

rmm1 = RMM( [
              Rayleigh1D( .5  , alpha=1 ),
              Rayleigh1D(  2 ,  alpha=1 ),
              Rayleigh1D(  10 , alpha=1 ),
           ] )

rmm2 = RMM( [
              Rayleigh1D(   5, alpha=1 ),
              Rayleigh1D(  60, alpha=1 ),
              Rayleigh1D( 100, alpha=2 ),
          ] )

def reseed( s ):
    gmm1.seed( s )
    gmm2.seed( s )
    rmm1.seed( s )
    rmm2.seed( s )

def showsignal( ax, mm, xmin, xmax, title ):
    x = np.linspace( xmin, xmax, 200 )
    y = np.exp( mm.loglikelihood( x ) )
    ax.plot( x, y )
    ax.fill_between( x, 0, y )
    ax.set_title( title, fontsize=24 )

def visualize():
    fig = plt.figure()

    showsignal( fig.add_subplot( 221 ), gmm1, -10, 35, 'GMM1' )
    showsignal( fig.add_subplot( 222 ), gmm2, -20, 20, 'GMM2' )
    showsignal( fig.add_subplot( 223 ), rmm1,   0, 20, 'RMM1' )
    showsignal( fig.add_subplot( 224 ), rmm2,   0,200, 'RMM2' )

    plt.show()
    fig.savefig( 'signals.pdf', bbox_inches='tight', pad_inches=0, transparent=True )

def exp( ax, mm1, mm2, title, repeat=100, init_seed=2016 ):
    sample_size_range = [ 10, 1e2, 1e3, 1e4, 1e5 ]
    results = np.zeros( [ len(sample_size_range), repeat ] )

    for i, sample_size in enumerate( sample_size_range ):
        print( 'trying sample_size=%d' % sample_size )
        for j in range( repeat ):
            mm1.seed( init_seed+j )
            mm2.seed( init_seed+j )
            results[i,j] = mm1.kl_sampling( mm2, sample_size )

    bounds = mm1.kl_lse_bound( mm2 )
    _min = results.min( 1 )
    _max = results.max( 1 )
    mean = results.mean( 1 )
    std  = results.std( 1 )

    x = [ i+0.5 for i,_ in enumerate(sample_size_range) ]
    ax.axhline( bounds[0], linewidth=3, alpha=.6, color='green' )
    ax.axhline( bounds[1], linewidth=3, alpha=.6, color='red'  )
    #ax.fill_between( x, bounds[0], bounds[1], alpha=.9, color='blue' )
    ax.errorbar( x, mean, yerr=std, fmt='o', color='black', elinewidth=2 )
    xshifted = [ i+.2 for i in x ]
    ax.errorbar( xshifted, mean, yerr=[mean-_min, _max-mean], fmt='none', color='blue' )

    ax.set_xticks( x )
    ax.set_xticklabels( [ r'$10$', r'$10^2$', r'$10^3$', r'$10^4$', r'$10^5$' ] )
    ax.set_xlim( 0, len(sample_size_range) )
    ax.set_title( title, fontsize=16 )

def __benchmark( mm1, mm2, repeat=1000 ):
    for sample_size in [ 1e3, 1e4 ]:
        start_t = time.time()
        for i in range( repeat ):
            mm1.kl_sampling( mm2, sample_size )
            mm2.kl_sampling( mm1, sample_size )
        speed = ( time.time() - start_t ) * 1.0 / (repeat*2)
        print('sample_size=%d speed=%f' % ( sample_size, speed ) )

    start_t = time.time()
    for i in range( repeat ):
        mm1.kl_lse_bound( mm2 )
        mm2.kl_lse_bound( mm1 )
    speed = ( time.time() - start_t ) * 1.0 / (repeat*2)
    print('Bounds speed=%f' % speed )

def benchmark():
    print( 'GMM' )
    gaussians1 = []
    gaussians2 = []
    for i in range( 100 ):
        gaussians1.append( Gaussian1D( i, 1 )    )
        gaussians2.append( Gaussian1D( i+.5, 1 ) )
    gmm1 = GMM( gaussians1 )
    gmm2 = GMM( gaussians2 )
    __benchmark( gmm1, gmm2, repeat=1 )

    #print( 'RMM' )
    #__benchmark( rmm1, rmm2 )

if __name__ == '__main__':
    #visualize()

    fig = plt.figure()
    exp( fig.add_subplot(221), gmm1, gmm2, r'KL($\mathtt{GMM}_1$:$\mathtt{GMM}_2$)' )
    exp( fig.add_subplot(222), gmm2, gmm1, r'KL($\mathtt{GMM}_2$:$\mathtt{GMM}_1$)' )
    exp( fig.add_subplot(223), rmm1, rmm2, r'KL($\mathtt{RMM}_1$:$\mathtt{RMM}_2$)' )
    exp( fig.add_subplot(224), rmm2, rmm1, r'KL($\mathtt{RMM}_2$:$\mathtt{RMM}_1$)' )
    fig.savefig( 'results.pdf', bbox_inches='tight', pad_inches=0, transparent=True )


