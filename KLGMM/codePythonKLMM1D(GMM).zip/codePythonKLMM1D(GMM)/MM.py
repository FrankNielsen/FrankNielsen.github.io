from __future__ import print_function

from scipy.misc import logsumexp
from scipy.special import erf, gammainc
import scipy.integrate as integrate
import numpy as np
import sys

class MM( object ):
    '''
    mixture model
    '''

    ##############################################################
    # Interfaces
    def _segment_integral( self, scomp, ocomp, begin, end ):
        '''
        compute the integral 
        Int scomp(x) \ln ocomp(x) dx, x \in [begin, end]
        '''
        raise NotImplementedError()

    def _update_envelope( self, intervals, idx ):
        '''
        update the envelope given by intervals
        based on self.dist[idx]
        return the updated envelope
        '''
        raise NotImplementedError()
    ##############################################################

    def __init__( self, components, random_seed=None ):
        '''
        components is a list of Distributions
        '''
        self.dtype = np.float64
        self.eps   = np.finfo( self.dtype).eps
        self.chaos = np.random.RandomState( random_seed )

        # sort the components based on distibutions's key() method
        # ensure all components have same dimension
        self.dist = sorted( components, key=lambda c:c.key() )

        self.ndim = self.dist[0].dim()
        for _d in self.dist: assert( self.ndim == _d.dim() )

        # Important: re-normalize the weights
        alpha = np.array( [ _d.alpha for _d in self.dist ] )
        alpha /= alpha.sum()
        for _a, _d in zip( alpha, self.dist ): _d.alpha = _a

    def __str__( self ):
        return '\n'.join( [ '%s' % str(_d)
                            for _d in self.dist ] )

    def dim( self ):
        return self.ndim

    def left( self ):
        return self.dist[0].left()

    def right( self ):
        return self.dist[0].right()

    def seed( self, random_seed ):
        '''
        reseed the internal random generator
        '''
        self.chaos.seed( random_seed )

    def draw( self, num_samples ):
        '''
        draw samples from the mixture model
        '''
        alpha = np.array( [ _d.alpha for _d in self.dist ] )
        counts  = self.chaos.multinomial( num_samples, alpha )
        samples = [ _d.draw( _c, self.chaos )
                    for _c,_d in zip( counts, self.dist ) ]

        if samples[0].ndim == 1:
            return np.hstack( samples )
        if samples[0].ndim == 2:
            return np.vstack( samples )
        else:
            raise NotImplementedError()

    def comp_ll( self, x, idx ):
        if ( np.size( x ) == 1 ) and np.isinf( x ):
            return 0
        else:
            return self.dist[idx].loglikelihood( x )

    def loglikelihood( self, x ):
        '''
        compute the loglikelihood of x
        x can be a scalar (one sample)
        or 1darray of samples
        or 2darray with one sample per row
        '''
        ll = np.array( [ self.comp_ll( x, i )
                         for i, _d in enumerate( self.dist ) ] )
        return logsumexp( ll, axis=0 )

    def kl_sampling( self, other, num_samples ):
        '''
        measure the KL divergence KL(self, other)
        based on random sampling
        '''
        samples = self.draw( num_samples )
        return np.mean( self.loglikelihood( samples )
                     - other.loglikelihood( samples ) )

    def kl_lse_bound( self, other ):
        '''
        KL divergence based on LSE bounding
        '''
        lb1, ub1 = self.__cross( self )
        lb2, ub2 = self.__cross( other )
        return lb1 - ub2, ub1 - lb2

    def __cross( self, other ):
        '''
        compute \int self(x) \ln other(x) dx
        the negative cross entropy
        '''
        integral = 0
        for _d in self.dist:
            integral += _d.alpha * sum( [
                self._segment_integral( _d, other.dist[idx], begin, end )
                    for begin, end, idx in other.envelope() ] )

        return integral, integral+np.log( len(other.dist) )

    def envelope( self ):
        '''
        only for 1d mixture models

        partition the real line into several intervals,
        so that one component will dominate one interval
        '''

        assert( self.ndim == 1 )

        intervals = [ ( self.left(), self.right(), 0 ) ]
        for idx in range( 1, len(self.dist) ):
            intervals = self._update_envelope( intervals, idx )

        return intervals

    def _search_location( self, value, intervals ):
        '''
        binary searching of intervals that contains value
        '''
        begin = 0               # inclusive
        end   = len(intervals)  # not invlusive

        while True:
            candi = ( begin + end ) / 2
            side = self.__location( value, intervals[candi] )
            if side == -1:
                end   = candi
            elif side == 1:
                begin = candi + 1
            else:
                break

        return candi

    def __location( self, value, interval ):
        '''
        determine value on which side of the interval
        '''
        if value < interval[0]:
            return -1
        elif value > interval[1]:
            return 1
        else:
            return 0

    def _cut_left( self, intervals, idx, callback ):
        '''
        binary searching the left break point
        '''
        begin = 0
        end   = len( intervals )

        while begin < end:
            candi = ( begin + end ) / 2
            breaked = self.__break( idx, intervals[candi], callback )
            if breaked == 1:
                end = candi
            elif breaked == -1:
                begin = candi + 1
            else:
                break

        if begin == end: return [ ( self.left(), intervals[-1][1], idx ) ]

        # idx intersect the evelope at intervals[candi]
        begin, end, domi = intervals[candi]
        l = [ p
              for p in self.dist[idx].intersect( self.dist[domi] )
              if self.__location( p, intervals[candi] ) == 0 ]
        if len( l ) == 0: return [ ( self.left(), intervals[-1][1], idx ) ]

        return intervals[:candi] + [ ( begin, min(l), domi ) ]

    def _cut_right( self, intervals, idx, callback ):
        '''
        binary searching the right break point
        '''
        begin = 0
        end   = len( intervals )

        while begin < end:
            candi = ( begin + end ) / 2
            breaked = self.__break( idx, intervals[candi], callback )
            if breaked == 1:
                begin = candi + 1
            elif breaked == -1:
                end = candi
            else:
                break

        if begin == end: return [ ( intervals[0][0], self.right(), idx ) ]

        # idx intersect the evelope at intervals[candi]
        begin, end, domi = intervals[candi]
        l = [ p
              for p in self.dist[idx].intersect( self.dist[domi] )
              if self.__location( p, intervals[candi] ) == 0 ]
        if len( l ) == 0: return [ ( intervals[0][0], self.right(), idx ) ]

        return [ ( max(l), end, domi ) ] + intervals[(candi+1):]

    def __break( self, idx, interval, callback ):
        '''
        check if component[idx] cut the closed interval
        '''
        begin, end, domi = interval

        if np.isinf( begin ) or np.isinf( end ):
            l = [ p for p in self.dist[idx].intersect( self.dist[domi] )
                  if self.__location( p, interval ) == 0 ]

            if len( l ) == 0:
                if not np.isinf( begin ):
                    candi = begin + 1
                elif not np.isinf( end ):
                    candi = end - 1
                else:
                    candi = 0

                if callback( candi, idx ) > callback( candi, domi ):
                    return 1
                else:
                    return -1
            else:
                return 0

        bdiff = callback( begin, idx ) - callback( begin, domi )
        ediff = callback( end,   idx ) - callback( end,   domi )

        if ( bdiff * ediff <= 0 ):
            return 0
        elif bdiff > 0:
            return 1
        else:
            return -1

    def _simplify( self, intervals ):
        '''
        merge intervals. if two nearby intervals
        share the same dominator, then merge them
        '''
        simplified = []
        itr = 0
        while itr < len( intervals ):
            domi = intervals[itr][-1]
            span = itr+1
            while( span < len( intervals ) and intervals[span][-1] == domi ):
                span += 1

            simplified.append( ( intervals[itr][0], intervals[span-1][1], domi ) )
            itr = span

        return simplified

class GMM( MM ):
    '''
    Gaussian Mixture
    '''
    def _update_envelope( self, intervals, idx ):
        '''
        update the partitions based on i'th component
        '''

        # find component[idx].mu is in which interval 
        loc = self._search_location( self.dist[idx].mu, intervals )
        begin, end, domi = intervals[loc]

        # idx didn't break out the envelope
        mu = self.dist[idx].mu
        if self.comp_ll( mu, idx ) <= self.comp_ll( mu, domi ): return

        # split intervals into two half
        left_intervals  = intervals[:loc] + [ ( begin, mu, domi ) ]
        right_intervals = [ (mu, end, domi) ] + intervals[(loc+1):]

        l = self._cut_left(  left_intervals,  idx, self.comp_ll )
        r = self._cut_right( right_intervals, idx, self.comp_ll )

        return self._simplify( l + [ ( l[-1][1], r[0][0], idx ) ] + r )

    def _segment_integral( self, s, o, begin, end ):
        comp_int = o.const() * s.prob( begin, end )

        comp_int -= .5 * self.__int( o.mu - s.mu,
                                     s.sigma,
                                     begin - o.mu,
                                     end   - o.mu,
                     ) / ( o.sigma**2 * np.sqrt(2*np.pi) * s.sigma ) 

        return comp_int

    def __int( self, mu, sigma, a, b ):
        '''
        Integrate( x^2 exp( - ( x + mu )^2 / (2*sigma^2) ) )
        from a to b
        '''
        term1 = np.sqrt(2*np.pi) * (mu**2+sigma**2) \
                * ( erf( (b+mu) / (np.sqrt(2)*sigma ) )
                  - erf( (a+mu) / (np.sqrt(2)*sigma ) ) )

        if np.isinf( a ):
            term2 = 0
        else:
            term2 = 2*sigma * (a-mu) * np.exp( -(a+mu)**2/(2*sigma**2) )

        if np.isinf( b ):
            term3 = 0
        else:
            term3 = 2*sigma * (mu-b) * np.exp( -(b+mu)**2/(2*sigma**2) )

        return .5*sigma*( term1+term2+term3 )

class RMM( MM ):
    '''
    Rayleigh Mixture
    '''

    def __quad( self, x, idx ):
        '''
        for computing the envelope
        loglikelihood without the logx term
        '''
        return np.log( self.dist[idx].alpha ) \
               - 2 * np.log( self.dist[idx].sigma ) \
               - (x**2) / ( 2*self.dist[idx].sigma**2 )

    def _update_envelope( self, intervals, idx ):
        '''
        update the envelope
        '''
        begin, end, domi = intervals[0]

        # idx didn't break out the envelope
        if self.__quad( 0, idx ) <= self.__quad( 0, domi ): return

        # idx will become intervlas[0]
        r = self._cut_right( intervals, idx, self.__quad )
        return self._simplify( [ ( 0, r[0][0], idx ) ] + r )

    def _segment_integral( self, s, o, a, b ):
        # need to acess mathematica
        comp_int = s.prob( a, b ) * ( np.log( o.alpha ) - 2 * np.log( o.sigma ) )

        comp_int += -(2*s.sigma**2+a**2) \
                    * np.exp( -a**2/(2*s.sigma**2) ) \
                    / ( 2*o.sigma**2 )

        if not np.isinf( b ):
            comp_int += (2*s.sigma**2+b**2) \
                        * np.exp( -b**2/(2*s.sigma**2) ) \
                        / ( 2*o.sigma**2 )

        def elnx( x ):
            return np.log( x ) * x * np.exp( -x**2/(2*s.sigma**2) ) / (s.sigma**2)
        comp_int += integrate.quad( elnx, a, b, limit=100 )[0]

        #term1 = .5 * gammainc( 0, a**2/(2*s.sigma**2) )
        #if not np.isinf( b ):
        #    term1 -= .5 * gammainc( 0, b**2/(2*s.sigma**2) )
        #print( term1 )

        #term2 = np.log(a+self.eps) * np.exp( -a**2/(2*s.sigma**2) )
        #if not np.isinf( b ):
        #    term2 -= np.log(b) * np.exp( -b**2/(2*s.sigma**2) )
        #comp_int += term1 + term2
        #print( term1, term2, comp_int )
            
        return comp_int

