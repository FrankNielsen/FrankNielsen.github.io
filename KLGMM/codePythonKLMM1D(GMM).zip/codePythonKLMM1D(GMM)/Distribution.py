from __future__ import print_function

import numpy as np
from scipy.special import erf

class Distribution( object ):
    '''
    general probability distribution
    '''
    def __init__( self ):
        '''
        common constants
        '''
        self.dtype = np.float64
        self.eps   = np.finfo( self.dtype ).eps

    ############### Interfaces ###############
    def dim( self ):
        '''dimensionality'''
        raise NotImplementedError()

    def key( self ):
        '''sort key'''
        raise NotImplementedError()

    def left( self ):
        '''left bound of support'''
        raise NotImplementedError()

    def right( self ):
        '''right bound of support'''
        raise NotImplementedError()

    def loglikelihood( self ):
        '''log likelihood
           weight is also considered in the computation
        '''
        raise NotImplementedError()

    def draw( self ):
        '''draw samples'''
        raise NotImplementedError()

    def intersect( self, other ):
        '''compute intersection points'''
        raise NotImplementedError()

    def prob( self, a, b ):
        '''probability mass from a to b'''
        raise NotImplementedError()

class Gaussian1D( Distribution ):
    '''
    univariate Gaussian
    '''
    def __init__( self, mu, sigma, alpha=1 ):
        super( self.__class__, self ).__init__()

        self.mu    = self.dtype( mu )

        self.sigma = self.dtype( sigma )
        if self.sigma <= 0: self.sigma = self.eps

        self.alpha = self.dtype( alpha )
        if self.alpha <= 0: self.alpha = self.eps

    def __str__( self ):
        return ( 'G(%5g, %5g) weight=%g' % ( self.mu,
                                             self.sigma,
                                             self.alpha ) )

    def dim( self ):
        return 1

    def key( self ):
        '''
        sort Gaussians from big sigma to small sigma
        '''
        return ( -self.sigma )

    def left( self ):
        return -np.inf

    def right( self ):
        return np.inf

    def const( self ):
        '''
        constant scalar for computing the loglikelihood
        '''
        return ( -.5*np.log( 2*np.pi )
                 -np.log( self.sigma )
                 +np.log( self.alpha ) )

    def loglikelihood( self, x ):
        '''
        compute the loglikelihood of x
        x can be a scalar, or 1darray of samples
        return a scalar or 1darray of the same shape
        '''
        return -(x-self.mu)**2 / (2*self.sigma**2) + self.const()

    def draw( self, num_samples, chaos ):
        '''
        draw samples from the Gaussian
        chaos is RandomGenerator
        return a 1darray
        '''
        return chaos.normal( self.mu, self.sigma, num_samples )

    def intersect( self, other ):
        l1 = -.5 / (self.sigma**2)
        l2 = -.5 / (other.sigma**2)

        a = l1 - l2
        b = -2 * l1 * self.mu + 2 * l2 * other.mu
        c = l1 * self.mu**2 + self.const() - l2 * other.mu**2 - other.const()

        # solve ax^2 + bx + c = 0
        if a == 0 and b == 0:
            return []
        elif a == 0 and b != 0:
            return [ -c/b ]
        else:
            return self.__solve( a, b, c )

    def __solve( self, a, b, c ):
        _ = b**2 - 4*a*c
        if _ < 0:
            return []
        elif _ == 0:
            return [ -.5 * b / a ]
        else:
            _ = np.sqrt( _ )
            return [ -.5 * ( b - _ ) / a,
                     -.5 * ( b + _ ) / a ]

    def prob( self, a, b ):
        '''
        integrating the Gaussian density (mu, sigma) from a to b
        '''
        return .5 * ( erf( ( b - self.mu ) / ( np.sqrt(2)*self.sigma) )
                    - erf( ( a - self.mu ) / ( np.sqrt(2)*self.sigma) ) )

class Rayleigh1D( Distribution ):
    '''
    univariate Rayleigh
    '''
    def __init__( self, sigma, alpha=1 ):
        super( self.__class__, self ).__init__()

        self.sigma = self.dtype( sigma )
        if self.sigma <= 0: self.sigma = self.eps

        self.alpha = self.dtype( alpha )
        if self.alpha <= 0: self.alpha = self.eps

    def __str__( self ):
        return ( 'Rayleigh(%5g) weight=%g' % ( self.sigma,
                                               self.alpha ) )

    def dim( self ):
        return 1

    def key( self ):
        '''
        objects will be sorted based on sigma
        '''
        return ( -self.sigma )

    def left( self ):
        return 0

    def right( self ):
        return np.inf

    def loglikelihood( self, x ):
        '''
        loglikelihood of x
        '''
        return np.log(x) - (x**2) / (2*self.sigma**2) \
               - 2 * np.log( self.sigma ) \
               + np.log( self.alpha )

    def draw( self, num_samples, chaos ):
        '''
        draw samples from the Rayleigh
        '''
        return chaos.rayleigh( self.sigma, num_samples )

    def intersect( self, other ):
        '''
        find intersection
        '''
        # solve ax^2 + b = 0
        if self.sigma == other.sigma: return []

        a = .5/(self.sigma**2) - .5/(other.sigma**2)
        b = np.log(self.alpha) - 2 * np.log(self.sigma) \
            - np.log(other.alpha) + 2 * np.log(other.sigma)
        squarex = b / a
        if squarex <= 0:
            return []
        else:
            return [ np.sqrt( squarex ), ]

    def prob( self, a, b ):
        '''
        probability mass from a to b
        '''
        l = -.5 / (self.sigma**2)
        return np.exp( l * a**2 ) - np.exp( l * b**2 )

