# Relative Natural Gradient Descent (RNGD)

## Requirements

1. Python >= 2.7.10
2. numpy >= 1.12
3. TensorFlow >= 1.1
4. Python 3.4 Enum 

## Filelist
     MLP.py -- MLP with different optimizers
test_mlp.py -- test script to run MNIST classification experiments
visualizer.py -- plot learning curves based on npz files produced by test_mlp.py

## Example (run the experiment on a GPU)

$ ./test_mlp.py plain  sgd a --lrate 0.1 5e-2 1e-2 5e-3 1e-3
$ ./test_mlp.py plain adam a --lrate 1e-2 5e-3 1e-3 5e-4 1e-4
$ ./test_mlp.py plain rngd a --lrate 0.01 0.005
$ ./visualize.py --last 50 mnist_full_PLAIN*.npz
(this may take around 1 day)

$ ./test_mlp.py bna sgd  a --lrate 0.1 5e-2 1e-2 5e-3 1e-3
$ ./test_mlp.py bna adam a --lrate 1e-2 5e-3 1e-3 5e-4 1e-4
$ ./test_mlp.py bna rngd a --lrate 0.01 0.005
$ ./visualize.py --last 50 mnist_full_BNA*.npz
(this may take around 1 day)

## ToDo

more efficient implementations of RNGD
investigate the effect of dropout
