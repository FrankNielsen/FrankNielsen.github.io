#!/bin/sh

# PLAIN
#python test_mlp.py plain sgd  a 1e-1 1e-2 1e-3 1e-4
#python test_mlp.py plain adam a 1e-1 1e-2 1e-3 1e-4
#python test_mlp.py plain rngd a 1e-1 1e-2 1e-3 1e-4

## SGD
#python test_mlp.py bna   sgd  a 1e-2 1e-1
#python test_mlp.py bnb   sgd  a 1e-2 1e-1

## ADAM
#python test_mlp.py plain adam a 1e-2
#python test_mlp.py bna   adam a 1e-2
#python test_mlp.py bnb   adam a 1e-2

#python test_mlp.py plain rngd a 1e-2
#python test_mlp.py bna   rngd a 1 --repeat 1 --nepochs 100
