from __future__ import print_function

from enum import Enum
import numpy as np
import sys

def sigmoid( x ):
    '''     1
       ------------
        1 + exp(-x)
    =
          exp(.5x) - exp(-.5x)
      .5  -------------------- + .5
          exp(.5x) + exp(-.5x)
    '''
    return ( .5 * np.tanh( .5 * x ) + .5 )

def add_column_ones( X ):
    '''
    copy the 2D array X, then add a colum of ones
    '''
    assert( X.ndim == 2 )
    return np.append( X,
               np.ones( [ X.shape[0], 1 ], dtype=X.dtype ),
               axis=1 )

def check_mean_cov( X, atol=1e-4, rtol=1e-4 ):
    '''
    check if X has zero mean and unit covariance
    '''

    _mean = X.mean( 0 )
    if np.allclose( _mean, 0, atol=atol, rtol=rtol ):
        print( 'X is centered' )
    else:
        print( _mean.min(), _mean.max() )
        raise RuntimeError( 'WARNING: X is not centered!')

    _cov = np.cov( X.T )
    _diag_cov = np.diag( np.diag( _cov ) )
    if np.allclose( _cov, _diag_cov, atol=atol, rtol=rtol ):
        print( 'cov of X is diagonal' )
    else:
        print( np.abs( _cov - _diag_cov ).max() )
        raise RuntimeError( 'WARNING: cov of X is not diagonal!' )

    bin_dims = ( np.abs( np.diag( _cov ) ) < atol ).sum() \
             + ( np.abs( np.diag( _cov ) - 1 ) < atol ).sum()
    if bin_dims == X.shape[1]:
        print( 'all dims are normalized ' )
    else:
        raise RuntimeError( 'WARNING: not all dims are normalized!')

class Methods( Enum ):
    GD        = 1      # gradient descent
    NGD       = 2      # (relative) natural gradient
    WhiteGD   = 3      # GD  with whitened features
    WhiteNGD  = 4      # NGD with whitened features

    SAMPLE    = 5      # NGD based on sampling
    SCALE     = 6      # feature re-scalling

class Logistic( object ):

    def __init__( self,
                  X,
                  Y,
                  method,
                  lrate=.1,         # learning rate
                  momentum=.5,      # momentum
                  seed=None,        # random seed
                  output_intv=10,   # output interval
                  ngd_eps=1e-2,     # for NGD/WhiteNGD to avoid singular metric
                                    # emperically, choose .001-0.1
                  cov_eps=1e-5,     # determine singular dimensions of input space
                                    # only for whitening transformation
                  eps=1e-10,        # general purpose eps
                  dtype=np.float64 ):

        # constants that will remain unchanged
        self.method       = method

        assert( lrate >= 0 )
        self.lrate        = lrate

        assert( momentum >= 0 )
        assert( momentum < .95 )
        self.momentum     = momentum

        self.output_intv  = output_intv
        self.ngd_eps      = ngd_eps
        self.eps          = eps
        self.dtype        = dtype
        self.debug        = False
        if self.debug: print( '%s: I am in debuging mode' % str(self) )

        # training data: X and Y
        self.X = np.array( X, dtype=self.dtype )
        self.Y = np.array( Y, dtype=self.dtype ).flatten()
        assert( self.X.shape[0] > self.X.shape[1] )

        # internal parameters 
        self.chaos       = np.random.RandomState( seed )
        self.theta       = 1e-4 * self.chaos.randn( self.X.shape[1] + 1 ).astype( self.dtype )
        self.delta_theta = np.zeros_like( self.theta )

        if self.method in ( Methods.GD, Methods.NGD ):
            self.__X = add_column_ones( self.X )

        elif self.method in ( Methods.WhiteGD, Methods.WhiteNGD, Methods.SAMPLE, Methods.SCALE ):
            self.a = -self.X.mean( 0 )
            U, s, V = np.linalg.svd( self.X + self.a, full_matrices=False )

            inv_s = np.zeros_like( s )
            regular_dims = ( np.abs(s) > np.abs(s).mean()*cov_eps )
            inv_s[regular_dims] = 1.0 / ( s[regular_dims] + self.eps )
            self.A = inv_s[:,None] * V * np.sqrt( self.X.shape[0] - 1 )

            newX = np.dot( self.X + self.a, self.A.T )
            if self.debug:
                print( "%d singular dimensions" % ( s.size - regular_dims.sum() ) )
                print( "%d regular  dimensions" % regular_dims.sum() )
                check_mean_cov( newX )

            self.__X = add_column_ones( newX )

            if self.method == Methods.SCALE:
                self.b = np.zeros_like( self.a )
                self.c = np.ones_like(  self.a )

        else:
            raise RuntimeError( 'unknown method %s' % str(self.method) )

    def __predict( self, givenX=None ):
        '''
        compute the y corresponding to a given X
        '''

        # from X to __X, add a whitening layer if necessary
        if givenX is None:
            __X = self.__X

        elif self.method in ( Methods.GD, Methods.NGD ):
            __X = add_column_ones( givenX )

        elif self.method in ( Methods.WhiteGD, Methods.WhiteNGD, Methods.SAMPLE, Methods.SCALE ):
            __X = add_column_ones( np.dot( givenX + self.a, self.A.T ) )

        else:
            raise RuntimeError( 'no idea on how to predict' )

        # SCALE adds one additional layer of
        # bias and scalling applied upon __X
        if self.method == Methods.SCALE:
            __X = __X + np.append( self.b, 0 )
            __X[:,:-1] *= self.c

        return sigmoid( ( __X * self.theta ).sum(1) )

    def cost( self ):
        '''
        evaluate the cost function: average cross entropy
        '''
        mu = self.__predict()
        return ( - self.Y     * np.log( mu + self.eps )
                 - (1-self.Y) * np.log( 1.0 - mu + self.eps )
               ).mean()

    def train( self, num_epochs ):
        '''
        training by gradient descent
        for a given number of epochs
        '''
        learning_curve = [ self.cost() ]
        print( '[epoch0oo0] cost=%.4f' % learning_curve[0] )

        for epoch in range( 1, num_epochs+1 ):
            self.__descent( epoch == 1 )

            # go back if necessary
            if self.cost() > 2 * learning_curve[-1]:
                self.theta -= self.delta_theta
                self.delta_theta = np.zeros_like( self.theta )
                self.lrate *= .5

            learning_curve.append( self.cost() )
            if epoch % self.output_intv == 0:
                print( '[epoch%4d] cost=%8.2f x1e-4' % ( epoch, learning_curve[-1]*1e4 ) )

        return learning_curve

    def accuracy( self, X, Y ):
        '''
        testing self's accuracy in percentage on ( X, Y )
        '''
        X = np.array( X )
        Y = np.array( Y ).flatten()

        correct = 1.0 * ( ( self.__predict( X ) >= .5 ) == ( Y >= .5 ) )
        return correct.mean()

    def __descent( self, first_epoch ):
        '''one gradient descent step to minimize the cost'''

        if self.method in ( Methods.GD, Methods.WhiteGD ):
            grad_theta = ( ( self.__predict() - self.Y )[:,None] * self.__X ).mean( 0 )

        elif self.method in ( Methods.NGD, Methods.WhiteNGD ):
            '''compute natural gradient'''
            mu     = self.__predict()
            firing = ( mu * (1-mu) )
            C = np.dot( self.__X.T * firing, self.__X ) / firing.size
            energy_per_dim = np.trace( C ) / C.shape[0]
            C += self.ngd_eps * energy_per_dim * np.eye( C.shape[0] )

            grad_theta = ( ( mu - self.Y )[:,None] * self.__X ).mean( 0 )
            try:
                ngd_grad_theta = np.linalg.solve( C, grad_theta )

            except np.linalg.LinAlgError:
                # fail safe procedure
                print( 'singular metric occured, using regular gradient instead' )
                #C += ( 1 + 1e-3 * np.trace( C ) ) * np.eye( C.shape[0] )
                #grad_theta = np.linalg.solve( C, grad_theta )
                ngd_grad_theta = None

            grad_theta = grad_theta if ngd_grad_theta is None else ngd_grad_theta

        elif self.method == Methods.SAMPLE:
            self.rngd_n=1000,      # how much samples to draw
            self.rngd_eps=1e-1,
            self.rngd_lrate=1e-3,  # for learning the FIM

            mu     = self.__predict()
            firing = mu * ( 1-mu )
            grad_theta = ( ( mu - self.Y )[:,None] * self.__X ).mean( 0 )

            if first_epoch:
                self.Fisher = np.eye( self.__X.shape[1] )

            else:
                idx = self.chaos.multinomial( self.rngd_n, firing/firing.sum() )
                self.Fisher += np.dot( self.__X[idx].T, self.__X[idx] ) * firing.sum() / ( self.rngd_n * firing.size )
                self.Fisher *= .5
                #self.Fisher *= firing.sum() / self.__X.shape[0]

                #C = np.dot( self.__X.T, firing * self.__X ) / firing.sum()
                #trC = np.trace( C )
                #transC = trC * np.eye( C.shape[0] ) - C
                #if first_epoch:
                #    W, self.V = power( transC, self.V, max_iterations=10, tol=1e-2 )
                #else:
                #    W, self.V = power( transC, self.V, max_iterations=5, tol=1e-2 )
                #W = trC - W
                #r = ( trC - W.sum() ) / ( C.shape[0] - self.prngd_eigs )
                #tmp = ( 1./ ( W + self.rngd_eps * trC / C.shape[0] ) - 1./r ) * ( grad_theta * self.V ).sum(1)
                #grad_theta /= r
                #grad_theta += ( tmp[:,None] * self.V ).sum(0)

                #w, v = power( self.Fisher, np.random.rand( 1, self.Fisher.shape[0] ) )
                #self.Fisher += self.rngd_eps * w[0] * np.eye( self.Fisher.shape[0] )
                #self.Fisher += ( self.rngd_eps * np.trace( self.Fisher ) / self.Fisher.shape[0] ) * np.eye( self.Fisher.shape[0] )

                self.Fisher += np.eye( self.Fisher.shape[0] )
                self.Fisher *= .5
                grad_theta = np.linalg.solve( self.Fisher, grad_theta )

        elif self.method == Methods.SCALE:
            mu     = self.__predict()
            firing = ( mu * (1-mu) )[:,None]

            #firing /= ( firing.sum() + self.eps )
            #new_b = -( firing  * self.__X ).sum( 0 )

            tmp = ( firing * ( self.__X )**2 ).mean( 0 )[:-1] + 1
            new_c = 0.05 / np.sqrt( tmp ) + 0.95 * self.c

            #new_b = new_b[:-1]
            #new_c = ( new_c[:-1] + self.c ) / 2

            #coef = self.theta[:-1] * self.c
            self.theta[:-1] *= self.c / new_c
            #self.theta[-1]  += ( coef * ( self.b - new_b ) ).sum()

            #self.b = new_b
            self.c = new_c

            if self.debug:
                new_mu = self.__predict()
                if np.allclose( mu, new_mu, atol=1e-4, rtol=1e-4 ):
                    print( 'the model does not change at all..peace...' )
                else:
                    print( np.abs( new_mu - mu ).max() )
                    raise RuntimeError( 'the model changed. BAD!!' )

            #__X = self.__X + np.append( self.b, 0 )
            #__X[:,:-1] *= self.c
            __X = self.__X * np.append( self.c , 1 )
            grad_theta = ( ( mu - self.Y )[:,None] * __X ).mean( 0 )

        else:
            raise RuntimeError( 'unknown method %s' % self.method )

        # gradient descent
        self.delta_theta *= self.momentum
        self.delta_theta -= self.lrate * grad_theta
        self.theta       += self.delta_theta

