#!/usr/bin/env python 

from __future__ import print_function

import matplotlib.pyplot as plt
import numpy as np
import sys, os, argparse, math

def smooth( x, intv ):
    '''
    x -- 1d numpy array
    average x over every intv items
    '''
    #print( 'smoothing over %d iterations' % intv )

    num_intvs = int( math.ceil( x.size / intv ) )
    return np.array( [ np.mean( x[i*intv : (i+1)*intv] )
                       for i in range( num_intvs ) ] )

def final_mean_std( results, sharp ):
    '''
    results -- 3d array of experimental results
      sharp -- sharp ratio

    return get the mean and std of the final results defined by the sharp ratio
    along the first dimension of results without invalid entries
    '''

    nepochs = results.shape[-1]
    final_results = results[:,:,-int(nepochs*sharp):]

    _m = []
    _v = []
    for arr in final_results:
        valid_runs = [ run for run in arr
                       if not( np.isnan( np.mean(run) )
                            or np.isinf( np.mean(run) )
                            or ( run[-1] > 100 ) ) ]

        if len( valid_runs ) > 0:
            _m.append( np.mean( valid_runs ) )
            _v.append( np.std( valid_runs ) )
        else:
            _m.append( np.inf )
            _v.append( np.inf )
    return np.array( _m ), np.array( _v )

def mean_curve( results, idx ):
    '''
    remove invalid runs and get the average results
    '''
    valid_runs = [ run for run in results[idx]
                   if not( np.isnan( np.mean(run) )
                        or np.isinf( np.mean(run) )
                        or ( run[-1] > run[0] ) ) ]
    print( 'averaging based on %d valid runs' % len( valid_runs ) )

    if len( valid_runs ) > 0:
        return np.mean( valid_runs, 0 )
    else:
        return None

def visualize( filenames, top, sharp, smooth_intv ):
    '''
    analyse npz files, output statistics and figures
    '''

    fig = plt.figure( figsize=[4,4], frameon=True, dpi=300 )
    ax  = plt.Axes( fig, [ 0., 0., 1., 1. ] )
    fig.add_axes( ax )

    patterns = [
               ( 'GD'        , 'g:s' ),
               ( 'SGD'       , 'g:'  ),
               ( 'WhiteGD'   , 'r--o' ),
               ( 'NGD'       , 'b-.^' ),
               ( 'WhiteNGD'  , 'k-*'  ),
               ( 'PLAIN+SGD' , 'r-.' ),
               ( 'PLAIN+ADAM', 'g-.' ),
               ( 'PLAIN+RNGD', 'b-.' ),
               ( 'BNA+SGD'   , 'r-.' ),
               ( 'BNA+ADAM'  , 'g--o' ),
               ( 'BNB+SGD'   , 'g-.' ),
               ( 'BNB+ADAM'  , 'r--*' ),
               ]

    # load results from disk into "curves"
    curves = {}
    for filename in filenames:
        dirname = os.path.dirname( filename )
        dataset = '_'.join( os.path.basename( filename ).split( '_' )[:2] )
        method  = os.path.basename( filename ).split( '_' )[2]

        _raw    = np.load( filename )
        configs = _raw[ 'configs' ]
        results = _raw[ 'results' ]
        curves[ method ] = [ configs, results ]

    # scan all existing methods
    for method, pat in patterns:
        if not method in curves: continue

        configs  = curves[method][0]
        results  = curves[method][1]
        n_epochs = results.shape[-1]

        final_mean, final_std = final_mean_std( results, sharp )
        best_idx = np.argsort( final_mean )

        print( '--==== %-10s ====--' % method )
        for rank, idx in enumerate( best_idx ):
            print( 'lrate=%-10g' % configs[idx,0], end=" " )
            print( '|'.join( ['%-10g' % _ for _ in configs[idx,1:] ] ), end=" " )
            print( 'sharp(%g)=%f-%f' % ( sharp, final_mean[idx], final_std[idx] ) )
            if rank >= top: continue

            curve = mean_curve( results, idx )
            if curve is not None:
                if n_epochs > 1000:
                    smoothed_curve = smooth( curve, smooth_intv )
                    x_plot = [ j*smooth_intv for j in range( len( smoothed_curve ) ) ]
                else:
                    smoothed_curve = curve
                    x_plot = [ j for j in range( len( smoothed_curve ) ) ]

            plt.plot( x_plot, smoothed_curve, pat, label=method, alpha=.6 )
        print( '' )

    leg = plt.legend( loc=1 )
    leg.get_frame().set_alpha(0.5)
    ax.tick_params( right='off', top='off' )

    if n_epochs > 1000:
        ax.set_xlabel( '#iterationis' )
    else:
        ax.set_xlabel( '#epochs' )

    ax.set_yscale( "log" )
    ax.set_ylabel( 'training error' )
    ax.set_xlim( [0, 55000] )
    #ax.set_ylim( [1e-7, 1e-2] )

    ofilename = os.path.join( dirname, '%s_curves' % dataset ).replace( '.', '_' )
    fig.savefig( ofilename+'.pdf', bbox_inches='tight', pad_inches=0, transparent=True )

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument( 'filenames', type=str,   nargs='+' )
    parser.add_argument( '--top',     type=int,   default=1 )
    parser.add_argument( '--smooth',  type=int,   default=10 )
    parser.add_argument( '--sharp',   type=float, default=.05,
                         help='use this percentage of epochs to compute the sharpness' )
    args = parser.parse_args()

    visualize( args.filenames, args.top, args.sharp, args.smooth )

