#!/usr/bin/env python

from __future__ import print_function

from tensorflow.python import control_flow_ops
import tensorflow as tf

from enum import Enum
import numpy as np
import time, sys, math

class MLP( object ):
    '''
    Multilayer Perceptron
    '''

    ##############################################################
    ##############################################################
    class Activation( Enum ):
        '''
        nonlinear activation functions
        '''
        TANH = 1
        SIGM = 2
        RELU = 3
        ELU  = 4

    class Optimizer( Enum ):
        '''
        optimization methods
        '''
        SGD     = 1     # Stochastic Gradient Descent
        ADAM    = 2     # Adam
        RNGD    = 3     # Relative Natural Gradient Descent
        LRNGD   = 4     # A variation of RNGD

    class Arch( Enum ):
        '''
        different architectures
        '''
        PLAIN   = 1     # Plain MLP
        BNA     = 2     # BN after activation
        BNB     = 3     # BN before activation
    ##############################################################
    ##############################################################

    def __activate( self, x, layer_idx ):
        '''
        nonlinear activation function, or identity for last layer
        '''
        if layer_idx < 0:
            return x

        elif self.activation == MLP.Activation.TANH:
            return tf.tanh( x )

        elif self.activation == MLP.Activation.SIGM:
            return tf.sigmoid( x )

        elif self.activation == MLP.Activation.RELU:
            return tf.nn.relu( x )

        else:
            raise NotImplementedError( 'unknown activation' )

    def __eye( self, n, m=None ):
        '''
        if m is None, return the nxn identity matrix

        otherwise, return mxnxn tensor, each nxn row
        of this tensor is identity
        '''
        if m is None:
            return tf.diag( tf.ones( [n,] ) )
        else:
            eyes = [ tf.expand_dims( tf.diag( tf.ones( [n,] ) ), 0 )
                     for i in range( m ) ]
            return tf.concat( 0, eyes )

    def __inv( self, m, dim ):
        '''
        matrix inverse for natural gradient optimization
        to avoid singular m, compute instead

            (m + epsilon I)^{-1}

        where epsilon is deteremined by heuristics
        '''
        scale = self.ngd_rel_eps * tf.trace( m ) / dim

        #with tf.control_dependencies( [tf.Print(scale,[scale,])] ):
        return tf.matrix_inverse( tf.add( m, scale * self.__eye( dim ) ) )

    def __batch_inv( self, m, dim ):
        '''
        batch matrix inverse 
        '''
        scale = tf.reduce_sum( tf.batch_matrix_diag_part( m ), 1 ) \
                * self.ngd_rel_eps / dim

        epsilonI = tf.expand_dims( tf.expand_dims( scale, -1 ), -1 ) \
                   * tf.expand_dims( self.__eye( dim ), 0 )

        return tf.batch_matrix_inverse( tf.add( m, epsilonI ) )

    def __bn( self, x, affine=True, scope='bn' ):
        '''
        a batch normalization layer

             x -- 2D input tensor
        affine -- whether to add affine transformation
        return the normalized x
        '''

        with tf.variable_scope( scope ):
            batch_mean, batch_var = tf.nn.moments( x, [0], name='moments' )
            ema = tf.train.ExponentialMovingAverage( decay=self.bn_decay )

            def mean_var_batch():
                '''update EMA and return the statistics of current batch'''
                ema_apply_op = ema.apply( [batch_mean, batch_var] )
                with tf.control_dependencies( [ema_apply_op] ):
                    return tf.identity( batch_mean ), tf.identity( batch_var )

            def mean_var_ema():
                return ema.average( batch_mean ), ema.average( batch_var )

            mean, var = control_flow_ops.cond( self.phase_train,
                                               mean_var_batch,
                                               mean_var_ema )

            beta  = tf.Variable( tf.constant( 0.0, shape=[ x.get_shape()[1], ] ),
                                 name='beta', trainable=affine )
            gamma = tf.Variable( tf.constant( 1.0, shape=[ x.get_shape()[1], ] ),
                                 name='gamma', trainable=affine )
            return tf.nn.batch_normalization( x, mean, var, beta, gamma, self.bn_eps )

    def __metric( self, current, new, current_dim, new_dim, scope='metric' ):
        '''
        get the EMA-updated metric operator
        '''
        with tf.variable_scope( scope ):
            if new is None:
                # first layer and last layer, only do feature whitening
                metric = tf.Variable( self.__eye( current_dim ),
                                      trainable=False,
                                      name="metric" )
            else:
                metric = tf.Variable( self.__eye( current_dim, new_dim ),
                                      trainable=False,
                                      name="metric" )
            ema = tf.train.ExponentialMovingAverage( decay=self.metric_decay )

            def metric_with_update():
                cov = tf.expand_dims( current, 1 ) * tf.expand_dims( current, -1 )
                if new is None:
                    metric_assign_op = metric.assign( tf.reduce_mean( cov, 0 ) )

                else:
                    sel = tf.cast( new > 0, "float" )
                    metric_assign_op = metric.assign( tf.reduce_mean(
                             tf.expand_dims( tf.expand_dims( sel, -1 ), -1 )
                             * tf.expand_dims( cov, 1 ),
                           0 ) )

                # first assign the metric, then apply EMA
                # then return the EMA
                with tf.control_dependencies( [metric_assign_op] ):
                    ema_apply_op = ema.apply( [metric] )
                    with tf.control_dependencies( [ema_apply_op] ):
                        return tf.identity( ema.average( metric ) )

            def metric_no_update():
                return tf.identity( ema.average( metric ) )

            return control_flow_ops.cond( self.phase_train,
                                          metric_with_update,
                                          metric_no_update )

    def __inv_metric( self, metric, current_dim, new_dim, scope='inv_metric' ):
        '''
        get the inverse metric op, either return the stored inverse metric,
        or recompute the inverse metric and then return this new value
        '''
        with tf.variable_scope( scope ):
            if new_dim is None:
                inv_metric = tf.Variable(
                             tf.constant( 0.0, shape=[ current_dim,
                                                       current_dim ] ),
                             trainable=False, name="inv_metric" )

            else:
                inv_metric = tf.Variable(
                             tf.constant( 0.0, shape=[ new_dim,
                                                       current_dim,
                                                       current_dim ] ),
                             trainable=False, name="inv_metric" )

            def inv_metric_with_update():
                if new_dim is None:
                    update_inv_op = inv_metric.assign(
                                    self.__inv( metric, current_dim ) )
                else:
                    update_inv_op = inv_metric.assign(
                                    self.__batch_inv( metric, current_dim ) )

                #with tf.control_dependencies( [tf.Print( inv_metric, [tf.trace(metric),])] ):
                with tf.control_dependencies( [update_inv_op] ):
                    return tf.identity( inv_metric )

            def inv_metric_no_update():
                return tf.identity( inv_metric )

            return control_flow_ops.cond( self.update_inv,
                                          inv_metric_with_update,
                                          inv_metric_no_update )

    def __apply_ng( self, grads ):
        '''
        apply natural gradient
        '''
        for grad_v, v in grads:
            if not v in self.natural:
                print( grads )
                raise RuntimeError( 'all parameters should be natural' )

            if self.natural[v].get_shape().ndims == 2:
                new_dv = tf.matmul( self.natural[v], grad_v )

            else:
                new_dv = tf.batch_matmul( self.natural[v],
                         tf.expand_dims( tf.transpose(grad_v), -1 ) )
                new_dv = tf.transpose( tf.squeeze( new_dv ) )

            yield ( new_dv, v )

    def __layer_name( self, layer_idx ):
        if layer_idx == -1:
            return "layerL"
        else:
            return ( "layer%d" % layer_idx )

    def __layer_linear( self, current, s1, s2 ):
        '''
        one vanilla linear layer
        '''
        W     = tf.Variable( tf.random_normal( [s1, s2] ), name="W" )
        b     = tf.Variable( tf.random_normal( [s2,] ),    name="b" )

        return tf.add( tf.matmul( current, W ), b )

    def __layer_bna( self, current, s1, s2, layer_idx ):
        '''
        BN AFTER each activation of all hidden layers
        '''
        if layer_idx == 0:
            # first layer is a vanilla layer
            return self.__layer_linear( current, s1, s2 )

        else:
            # no bias is necessary here because BN already has a bias term beta
            W     = tf.Variable( tf.random_normal( [s1, s2] ), name="W" )
            return tf.matmul( self.__bn( current ), W )

    def __layer_bnb( self, current, s1, s2, layer_idx ):
        '''
        BN BEFORE each activation
        BN already contains the bias variables (beta)
        '''
        if layer_idx >= 0:
            W     = tf.Variable( tf.random_normal( [s1, s2] ), name="W" )
            return self.__bn( tf.matmul( current, W ) )

        else:
            # last layer is a vanilla layer
            return self.__layer_linear( current, s1, s2 )

    def __layer_rngd( self, current, s1, s2, layer_idx, with_bn=False ):
        '''
        a RNGD layer

        current   -- the input op
        s1        -- input dimension
        s2        -- output dimension
        layer_idx -- index of the layer 
        with_bn   -- with batch normalization or not

        return the layer output op
        '''
        # augment the current tensor with a colum of ones
        # then apply a linear transformation
        if with_bn: current = self.__bn( current, affine=False )

        o = tf.ones( shape=tf.pack( [ tf.shape(current)[0], 1 ] ) )
        current = tf.concat( 1, [current, o ] )
        W = tf.Variable( tf.random_normal( [s1+1, s2] ), name="W" )
        new = tf.matmul( current, W )

        if layer_idx <= 0:
            # first and last layer, compute simplified metric
            metric = self.__metric( current, None, s1+1, None )
            self.natural[W] = self.__inv_metric( metric, s1+1, None )
        else:
            metric = self.__metric( current, new, s1+1, s2 )
            self.natural[W] = self.__inv_metric( metric, s1+1, s2 )

        with tf.control_dependencies( [metric] ):
            return tf.identity( new )

    def __build_graph( self, nn_shape ):
        '''
        build the TF graph of a MLP

        return the output op of the computational graph
        '''

        # initialize "current" with the input placeholder
        # current will be the latest op
        # in building the MLP graph
        current  = self.x

        layer_shapes = zip( nn_shape, nn_shape[1:] )
        for layer_idx, ( s1, s2 ) in enumerate( layer_shapes ):
            if layer_idx == len(layer_shapes)-1: layer_idx = -1
            with tf.variable_scope( self.__layer_name(layer_idx) ):
                # this will be the operations inside layer_idx
                # the last layer is indexed by -1

                if self.optimizer == MLP.Optimizer.RNGD:
                    if self.arch == MLP.Arch.PLAIN:
                        current = self.__layer_rngd( current, s1, s2, layer_idx )

                    elif self.arch == MLP.Arch.BNA:
                        current = self.__layer_rngd( current, s1, s2, layer_idx, with_bn=True )

                    else:
                        raise NotImplementedError( 'not implemented' )

                else:
                    if self.arch == MLP.Arch.PLAIN:
                        current = self.__layer_linear( current, s1, s2 )

                    elif self.arch == MLP.Arch.BNA:
                        current = self.__layer_bna( current, s1, s2, layer_idx )

                    elif self.arch == MLP.Arch.BNB:
                        current = self.__layer_bnb( current, s1, s2, layer_idx )

                    else:
                        raise RuntimeError( 'unknown architecture' )

                # IMPORTANT: must activate before the next layer
                current = self.__activate( current, layer_idx )

        return current

    def __cost_and_train( self, out ):
        '''
        build cost ops and train ops
        '''

        # add a final softmax layer 
        # and measure the average cross entropy with the input y
        self.cost = tf.reduce_mean( tf.nn.softmax_cross_entropy_with_logits( out, self.y ) )

        # measure accuracy in correct rate (0~1)
        _correct = tf.equal( tf.argmax(out, 1), tf.argmax(self.y, 1) )
        self.accuracy = tf.reduce_mean( tf.cast( _correct, "float" ) )

        if self.optimizer == MLP.Optimizer.SGD:
            self.train_op = tf.train.GradientDescentOptimizer(
                                self.lrate ).minimize( self.cost )

        elif self.optimizer == MLP.Optimizer.ADAM:
            self.train_op = tf.train.AdamOptimizer(
                                self.lrate ).minimize( self.cost )

        elif self.optimizer == MLP.Optimizer.RNGD:
            optimizer = tf.train.GradientDescentOptimizer( self.lrate )
            grads = optimizer.compute_gradients( self.cost, tf.trainable_variables() )
            self.train_op = optimizer.apply_gradients( self.__apply_ng( grads ) )

        else:
            raise RuntimeError( 'unknown method' )

    def __init__( self,
              nn_shape,             # shape of all layers, from x to y
                  arch,             # architecture
             optimizer,             # optimizer
            activation,             # activation function
                 lrate,             # learning rate
            batch_size=100,         # batch size
                bn_eps=1e-3,        # epsilon   (BN)
              bn_decay=.9,          # EMA decay (BN)
          metric_decay=.995,        # (NG) metric
           ngd_rel_eps=1e-2,        # (NG) epsilon
        ngd_inv_update=100,         # (NG) update interval of inverse metric
           output_intv=1,           # output interval
         ):
        '''
        record hyper parameters, build the graph
        '''

        self.arch           = arch
        self.optimizer      = optimizer
        self.activation     = activation
        self.lrate          = lrate
        self.batch_size     = batch_size
        self.bn_eps         = bn_eps
        self.bn_decay       = bn_decay
        self.metric_decay   = metric_decay
        self.ngd_rel_eps    = ngd_rel_eps
        self.ngd_inv_update = ngd_inv_update
        self.output_intv    = output_intv

        self.x = tf.placeholder( "float", [ None, nn_shape[0] ], name="x" )
        self.y = tf.placeholder( "float", [ None, nn_shape[-1]], name="y" )
        self.phase_train = tf.placeholder( tf.bool, name="phase_train" )
        self.update_inv  = tf.placeholder( tf.bool, name="update_inv" )

        self.natural = {}
        self.__cost_and_train( self.__build_graph( nn_shape ) )

        # only save trainable variables
        to_save = {}
        for v in tf.trainable_variables():
            print( v.name, v.get_shape() )
            to_save[v.name] = v
        self.saver = tf.train.Saver()

    def test( self, dataset ):
        '''
        test accuracy on a given dataset
        '''
        with tf.Session() as sess:
            self.saver.restore( sess, "/tmp/model.ckpt" )

            return self.accuracy.eval( { self.x: dataset.images,
                                         self.y: dataset.labels,
                                         self.phase_train: False,
                                         self.update_inv: False } )

    def train( self, dataset, num_epochs ):
        '''
        start a training session

        dataset    -- the training set
        num_epochs -- #epochs to train

        return the learning curve
        '''

        batch_per_epoch = int( math.ceil( dataset.num_examples / self.batch_size ) )
        lcurve = np.zeros( batch_per_epoch * num_epochs )
        age = 0

        init_op = tf.initialize_all_variables()
        with tf.Session() as sess:
            sess.run( init_op )

            start_time = time.time()
            for epoch in range( num_epochs ):
                for i in range( batch_per_epoch ):
                    if i % 10 == 0: print( '#', end="" )

                    batch_xs, batch_ys = dataset.next_batch( self.batch_size )
                    try:
                        sess.run( self.train_op, feed_dict={ self.x: batch_xs,
                                                             self.y: batch_ys,
                                                   self.phase_train: True,
                                                    self.update_inv: (i % self.ngd_inv_update == 0) } )

                    except tf.python.framework.errors.InvalidArgumentError:
                        # inverse the RFIM may cause exception
                        print( 'updating the inverse metric failed' )
                        sess.run( self.train_op, feed_dict={ self.x: batch_xs,
                                                             self.y: batch_ys,
                                                   self.phase_train: True,
                                                    self.update_inv: False } )

                    lcurve[age] = sess.run( self.cost,
                                            feed_dict={ self.x: batch_xs,
                                                        self.y: batch_ys,
                                              self.phase_train: False,
                                               self.update_inv: False } )
                    age += 1

                print( "" )
                epoch_cost = lcurve[age-batch_per_epoch:age].mean()
                if epoch % self.output_intv == 0:
                    train_acc = self.accuracy.eval( { self.x: dataset.images,
                                                      self.y: dataset.labels,
                                                      self.phase_train: False,
                                                      self.update_inv: False } )
                    speed = ( time.time() - start_time ) / (epoch+1)
                    print( "[%04d] cost=%.7f acc=%.3f (%3ds/epoch)" %
                           ( epoch+1, epoch_cost, train_acc, speed ) )

                if np.isinf( epoch_cost ) \
                   or np.isnan( epoch_cost ) \
                   or epoch_cost > 2*lcurve[0]:
                    break

            save_path = self.saver.save( sess, "/tmp/model.ckpt" )
            print( "Model saved in file: %s" % save_path )
            sess.close()

        lcurve[age:] = lcurve[age-1]
        return lcurve

