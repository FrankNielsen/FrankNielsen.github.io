#!/usr/bin/env python

'''
A demo of the learning curves of
*
* gradient
* gradient + whitened features
* natural gradient
* natural gradient + whitened features
*
* using Logistic regression
'''

from __future__ import print_function

from Logistic import Logistic, Methods

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.datasets import fetch_mldata
from sklearn.cross_validation import train_test_split

import numpy as np
import argparse
import time, sys, gc, math, re

def preprocess_features( X, std_eps=1e-5 ):
    '''
    simple feature engineering
    '''
    X -= X.mean( 0 )

    _std = X.std( 0 )
    regular_dims = ( _std > std_eps )
    inv_std = np.zeros_like( _std )
    inv_std[regular_dims] = 1. / _std[regular_dims]
    X *= inv_std

    return X

def news( test_size, seed, class0='sci.space', class1='sci.electronics' ):

    dataset = fetch_20newsgroups( subset='all',
                                  categories=[class0,class1],
                                  shuffle=True,
                                  random_state=seed )

    vectorizer = TfidfVectorizer( max_df=0.5,
                                  min_df=2,
                                  max_features=500,
                                  stop_words='english' )
    X = vectorizer.fit_transform( dataset.data )
    X = X.todense().astype( np.float32 )
    X = preprocess_features( X )

    y = dataset.target.astype( np.float32 )

    return train_test_split( X, y, test_size=test_size, random_state=seed )

def mnist( dataname, test_size, seed, dtype=np.float32 ):
    '''
    get two classes from MNIST for logistic regression
    '''

    mnist = fetch_mldata( 'MNIST original', data_home='/tmp' )
    match = re.search( '^mnist(\d+)', dataname )
    if not match: raise RuntimeError( "unknow data: %s" % dataname )
    digits = match.group( 1 )

    X = [ mnist.data[ mnist.target==int(d) ] for d in digits ]
    y = [ i*np.ones( arr.shape[0] )  for i,arr in enumerate(X) ]

    X = np.vstack( X ).astype( dtype )
    y = np.hstack( y ).astype( dtype )
    X = preprocess_features( X )

    return train_test_split( X, y, test_size=test_size, random_state=seed )

def benchmark( dataname, test_size, method, lrates, momentums,
               repeat=10, num_epochs=100, init_seed=2016 ):
    '''
    benchmark "method" on "dataname" with
        -- different learning rates
        -- different momentums
        -- different random seeds
    '''
    configs = [ (l,m) for l in lrates for m in momentums ]
    results = np.zeros( [ len(configs), repeat, num_epochs+1 ] )
    speed = []

    for i, ( lrate, momentum ) in enumerate( configs ):
        for j in range( repeat ):
            start_t = time.time()
            print( "method=%s lrate=%g momentum=%g trial %d/%d" % ( method.name, lrate, momentum, j+1, repeat ) )

            if dataname.startswith( 'mnist' ):
                X_train, X_test, y_train, y_test = mnist( dataname, test_size, init_seed )
            elif dataname == 'news':
                X_train, X_test, y_train, y_test = news( test_size, init_seed )
            else:
                raise RuntimeError()

            learner = Logistic( X_train,
                                y_train,
                                method,
                                lrate=lrate,
                                momentum=momentum,
                                seed=init_seed+j )
            results[i,j,:] = learner.train( num_epochs )

            print( "train: %.1f%%" % ( 100 * learner.accuracy( X_train, y_train ) ),
                    end=" " )
            print( "test: %.1f%%"  % ( 100 * learner.accuracy( X_test, y_test ) ),
                    end="\n" )

            speed.append( ( time.time() - start_t ) / 60. )
            print( "%.1fm/run" % np.mean( speed ) )

            rest_runs = ( len(configs)-i-1 ) * repeat + ( repeat-j-1 ) 
            if rest_runs > 0:
                print( "%.0f minutes to go!\n" % ( np.mean( speed ) * rest_runs ) )

            gc.collect()

    avg_error = results[:,:,-1].mean( 1 )
    idx = avg_error.argmin()
    best_lrate, best_momentum = configs[idx]
    print( 'lrate %.2f momentum %.2f achieved %f' % ( best_lrate, best_momentum, avg_error[idx] ) )

    outfile = ( '%s_%g_%s_%g_%g_%g_%g' % ( dataname, test_size, method.name,
                                           lrates[0], lrates[-1],
                                           momentums[0], momentums[-1] ) )
    np.savez( outfile, configs=np.array(configs), results=results )
    print( 'results saved to %s' % outfile )

    return results

def drange( start, stop, step=1, eps=1e-5 ):
    '''
    generate a list of float numbers
    from start to stop, inclusive
    '''
    num_steps = int( math.ceil( ( stop-start ) * 1.0 / step ) )
    items = [ (start + i*step) for i in range( num_steps ) ]
    if items[-1] < stop - eps: items.append( stop )
    return items

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument( 'dataset',    type=str,   choices=('mnist35', 'mnist49') )
    parser.add_argument( '--testsize', type=float, default=.5 )
    args = parser.parse_args()

    lrates    = [ 1e-2, 1e-1, 1, 10, 100 ]
    momentums = [ 0, .8 ]
    methods   = [ Methods.GD, Methods.NGD, Methods.WhiteGD, Methods.WhiteNGD ]

    # take several hours on a mordern PC
    start_t = time.time()
    for method in methods:
        benchmark( args.dataset, args.testsize, method, lrates, momentums )
    print( '%.1f hours, WOW' % ( ( time.time() - start_t ) / 3600 ) )

