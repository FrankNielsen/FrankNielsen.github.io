# Relative Natural Gradient Descent (RNGD)

## Requirements

1. Python >= 2.7.10
2. numpy >= 1.11
3. TensorFlow >= 0.8
4. Python 3.4 Enum 
