#!/usr/bin/env python

from __future__ import print_function

from MLP import MLP
from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf

import numpy as np
import argparse
import sys, time, gc

def batch_exp( arch,                        # architecture
               optimizer,                   # 
               nn_shape,                    # shape of the NN
               lrates,                      # learning rates to try
               batch_size,                  # batch size to try
               nepochs,                     # number of epochs
               repeat,                      # repeat for each config
               activation=MLP.Activation.RELU,  # activation
             ):
    '''
    perform a batch run of one single method on MNIST
    based on a grid of configurations
    '''

    print( arch.name, optimizer.name )
    print( 'MLP shape', nn_shape )
    print( 'learning rate: [%g-%g]' % ( lrates[0], lrates[-1] ) )
    print( 'batch size: %d' % batch_size )
    print( 'num epochs: %d' % nepochs )
    print( 'repeat: %d'     % repeat )
    print( 'activation', activation.name )

    mnist = input_data.read_data_sets( "/tmp", one_hot=True )

    results = []
    batch_sizes = [ batch_size ]
    configs = [ (float(l),b) for l in lrates for b in batch_sizes ]
    for i, (lrate, bs) in enumerate( configs ):
        result_i = []
        for j in range( repeat ):
            gc.collect()
            tf.reset_default_graph()
            print( 'lrate=%g trial%2d/%2d' % ( lrate, j+1, repeat ) )

            start_t = time.time()
            mlp = MLP( nn_shape, arch, optimizer, activation, lrate, batch_size=bs )
            lcurve = mlp.train( mnist.train, nepochs )
            result_i.append( lcurve )

            train_acc = mlp.test( mnist.train )
            test_acc  = mlp.test( mnist.test )
            print( 'train: %.4f test: %.4f' % ( train_acc, test_acc ) )

            min_per_run = ( time.time() - start_t ) / 60.
            rest_runs = ( len(configs)-i-1 )*repeat + ( repeat-j-1 )
            if rest_runs > 0:
                print( 'speed=%.1fm/experiment' % min_per_run )
                print( '%.1fm to go!' % ( min_per_run*rest_runs ) )

        results.append( result_i )
    results = np.array( results )

    avg_error = results[:,:,(-len(lcurve)/nepochs):].mean( (1,2) )
    avg_error = [ np.inf if ( np.isnan(_) or np.isinf(_) ) else _
                  for _ in avg_error ]
    idx = np.argmin( avg_error )
    l, b = configs[idx]
    print( 'lrate %f bs %f achieved %f' % ( l, b, avg_error[idx] ) )

    outfile = ( 'mnist_full_%s+%s_%g_%g' % ( arch.name, optimizer.name,
                                             lrates[0], lrates[-1] ) )
    np.savez( outfile, configs=configs, results=results )
    print( 'results saved to %s' % outfile )

    return results

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument( 'arch',        type=str,   choices=('plain', 'bna', 'bnb') )
    parser.add_argument( 'optimizer',   type=str,   choices=('sgd', 'adam', 'rngd') )
    parser.add_argument( 'shape',       type=str,   choices=('a', 'b') )
    parser.add_argument( 'lrate',       type=float, nargs='+' )
    parser.add_argument( '--batchsize', type=int,   default=100 )
    parser.add_argument( '--nepochs',   type=int,   default=100 )
    parser.add_argument( '--repeat',    type=int,   default=10 )
    args = parser.parse_args()

    SHAPES     = {
                    'a': [ 784, 64, 64, 64, 10 ],
                 }
    ARCHS      = {
                 'plain': MLP.Arch.PLAIN,
                   'bna': MLP.Arch.BNA,
                   'bnb': MLP.Arch.BNB,
                 }
    OPTIMIZERS = {
                   'sgd': MLP.Optimizer.SGD,
                  'adam': MLP.Optimizer.ADAM,
                  'rngd': MLP.Optimizer.RNGD,
                 }

    sys.stdout = sys.stderr
    start_t = time.time()
    batch_exp( ARCHS[args.arch],
               OPTIMIZERS[args.optimizer],
               SHAPES[args.shape],
               args.lrate, 
               args.batchsize,
               args.nepochs,
               args.repeat )
    print( '%.1f hours, WOW' % ( ( time.time() - start_t ) / 3600 ) )

