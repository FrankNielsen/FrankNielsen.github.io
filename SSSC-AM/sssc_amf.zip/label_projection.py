import numpy as np

def label_projection(sp_labels, index_invalid):
    '''
    Build a relation between original labels and processed labels.
    Return a dictionnay.
    '''
    TSPNumb = np.max(sp_labels)+1
    index_proj = np.arange(0, TSPNumb, 1)
    index_proj = np.delete(index_proj, index_invalid[1], axis = 0)
    index_dict = dict(zip(index_proj, range(index_proj.shape[0])))
    return index_dict
    