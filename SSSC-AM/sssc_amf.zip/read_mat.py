import os
import scipy.io as sio

def read_mat(matName, root):
    ''' load mat files'''
    # change directory
    os.chdir(root)
    #raw_input('\nInspect the contents of the MATLAB file. Press enter to continue!!!')
    print ('Loading MATLAB file...\n')
    mat_contents = sio.loadmat(os.path.join(root,matName))
    print 'Done!\n'
    return mat_contents