// Frank.Nielsen@acm.org
//
// August 2023
//
// (1+eps) guaranteed approximation of the Rao distance between multivariate normal distributions
// double FisherRaoMVN(vM N0, vM N1, double eps)

//  https://math.nist.gov/javanumerics/jama/
import Jama.*;

class StandAloneFisherRaoMVN
{
  public static double sqr(double x) {
    return x*x;
  }

  public static double min(double a, double b) {
    if (a<b) return a;
    else return b;
  }
  public static double max(double a, double b) {
    if (a>b) return a;
    else return b;
  }
  
  public static double arccosh(double x)
  {
    return Math.log(x+Math.sqrt(x*x-1.0));
  }
  
  
  public static Matrix InductiveAHM(Matrix X, Matrix Y, int nbiter)
{
 Matrix XX,YY;
 int i;
 
 for(i=0;i<nbiter;i++)
 {
   XX=ArithmeticMean(X,Y);
   YY=HarmonicMean(X,Y);
   X=XX;Y=YY;
 }
 return X;
}


  public static double MobiusDistance(double a, double b, double c, double d)
  {
    return Math.sqrt((sqr(c-a)+2.0*sqr(d-b))/(sqr(c-a)+2.0*sqr(d+b)));
  }
  
    // OK
  public static double RaoDistance1D(double m1, double s1, double m2, double s2)
  {
    return Math.sqrt(2)*Math.log((1.0+MobiusDistance(m1, s1, m2, s2))/(1.0-MobiusDistance(m1, s1, m2, s2)));
  }

public static Matrix ArithmeticMean(Matrix X, Matrix Y)
{
return (X.times(0.5)).plus(Y.times(.05));
}

public static Matrix HarmonicMean(Matrix X, Matrix Y)
{
return (X.inverse().times(0.5)).plus(Y.inverse().times(0.5)).inverse();
}


  
  public static  Matrix IsometricSPDEmbeddingCalvoOller(vM N)
  {
    Matrix mu=N.v;
    Matrix Sigma=N.M;
    int d=mu.getRowDimension();
    Matrix res=new Matrix(d+1, d+1);
    Matrix tmp=new Matrix(d, d);

    int i, j;

    tmp=Sigma.plus(  (mu.times(mu.transpose()))  );

    // Left top corner
    for (i=0; i<d; i++)
      for (j=0; j<d; j++)
      {
        res.set(i, j, tmp.get(i, j));
      }

    // Left column
    for (i=0; i<d; i++)
    {
      res.set(d, i, mu.get(i, 0));
    }

    // Bottom row
    for (i=0; i<d; i++)
    {
      res.set(i, d, mu.get(i, 0));
    }

    // Last element is one
    res.set(d, d, 1);

    return res;
  }

  public static double LowerBoundCalvoOller(vM N1, vM N2)
  {
    Matrix P1bar=IsometricSPDEmbeddingCalvoOller(N1);
    Matrix P2bar=IsometricSPDEmbeddingCalvoOller(N2);
    // We calculated (1/sqrt(2))*RiemannSPD(d+1)
    return ScaledRiemannianSPDDistance(P1bar, P2bar);
  }

  public static double UpperBoundSqrtJeffreys(vM N1, vM N2)
  {
    return Math.sqrt(JeffreysMVN(N1, N2));
  }

  public static double JeffreysMVN(vM N1, vM N2)
  {
    return KLMVN(N1.v, N1.M, N2.v, N2.M)+KLMVN(N2.v, N2.M, N1.v, N1.M);
  }


  public static double KLMVN(Matrix m1, Matrix S1, Matrix m2, Matrix S2)
  {
    int d=S1.getColumnDimension();
    Matrix Deltam=m1.minus(m2);

    return 0.5*(
      ((S2.inverse()).times(S1)).trace()-d+
      ((Deltam.transpose().times(S2.inverse())).times(Deltam)).trace()
      +Math.log(S2.det()/S1.det())
      );
  }

  // scale the trace metric by 1/2
  public static double ScaledRiemannianSPDDistance(Matrix P, Matrix Q)
  {
    double result=0.0d;
    Matrix M=P.inverse().times(Q);
    EigenvalueDecomposition evd=M.eig();
    Matrix D=evd.getD();

    for (int i=0; i<D.getColumnDimension(); i++)
    {
      result+=sqr(Math.log(D.get(i, i)));
    }

    return Math.sqrt(result/2.0);// ok beta=1/2
  }



  public static vM KobayashiMVNGeodesic(vM N0, vM N1, double t)
  {
    vM result;
    Matrix G0, G1, Gt;

    G0=EmbedBlockCholesky(N0);
    G1=EmbedBlockCholesky(N1);

    Gt=RiemannianGeodesic(G0, G1, t); // Rie geodesic in SPD(2d+1)
    // Extract
    result=L2MVN(Gt);

    return result;
  }

  Matrix RiemannianGeodesic(Matrix P0, Matrix P1)
  {
    return RiemannianGeodesic(P0, P1, 0.5);
  }


  public static Matrix RiemannianGeodesic(Matrix P, Matrix Q, double lambda)
  {
    if (lambda==0.0) return P;
    if (lambda==1.0) return Q;

    Matrix result;
    Matrix Phalf=power(P, 0.5);
    Matrix Phalfinv=power(P, -0.5);

    result=Phalfinv.times(Q).times(Phalfinv);
    result=power(result, lambda);



    result=(Phalf.times(result)).times(Phalf);



    return result;
  }

  // Non-integer power of a matrix
  public static Matrix power(Matrix M, double p)
  {
    EigenvalueDecomposition evd=M.eig();
    Matrix D=evd.getD();
    // power on the positive eigen values
    for (int i=0; i<D.getColumnDimension(); i++)
      D.set(i, i, Math.pow(D.get(i, i), p));

    Matrix V=evd.getV();

    return V.times(D.times(V.transpose()));
  }

  public static Matrix EmbedBlockCholesky(vM N)
  {
    int i, j, d=N.M.getRowDimension();
    Matrix Sigma=N.M;
    Matrix SigmaInv=N.M.inverse();
    Matrix mut=N.v.transpose();
    Matrix minusmu=N.v.times(-1.0);


    Matrix M, D, L; // Block Cholesky
    M=new Matrix(2*d+1, 2*d+1);
    D=new Matrix(2*d+1, 2*d+1);

    D.set(d, d, 1.0);

    for (i=0; i<d; i++)
      for (j=0; j<d; j++)
      {
        D.set(i, j, SigmaInv.get(i, j));
        D.set(d+1+i, d+1+j, Sigma.get(i, j));
      }



    M.set(d, d, 1.0);

    for (j=0; j<d; j++)
    {
      M.set(d, j, mut.get(0, j)); // row vector
      M.set(d+1+j, d, minusmu.get(j, 0)); // column vector
    }

    // add identity matrices
    for (i=0; i<d; i++)
      for (j=0; j<d; j++)
      {
        M.set(i, i, 1.0);
        M.set(i+d+1, i+d+1, 1.0);
      }

    // Block Cholesky decomposition
    L=M.times(D).times(M.transpose());

    return L;
  }


  static vM L2MVN(Matrix L)
  {
    int i, j, d;
    d= (L.getRowDimension()-1)/2;

    // System.out.println("extract mvn d="+d);

    Matrix Delta=new Matrix(d, d), delta=new Matrix(d, 1);
    for (i=0; i<d; i++)
      for (j=0; j<d; j++)
      {
        Delta.set(i, j, L.get(i, j));
      }

    for (j=0; j<d; j++)
    {
      delta.set(j, 0, L.get(d, j));
    }

    Matrix mu, Sigma;

    // convert natural parameters to ordinary parameterization
    Sigma=Delta.inverse();
    mu=Sigma.times(delta);

    return new vM(mu, Sigma);
  }


  public static double FisherRaoMVN(vM N0, vM N1, double eps)
  {
    double lb, ub;
    lb=LowerBoundCalvoOller(N0, N1);
    ub=UpperBoundSqrtJeffreys(N0, N1);
    if (ub/lb<1+eps) return ub;
    else
    {
      vM Nmid=KobayashiMVNGeodesic(N0, N1, 0.5);
      return FisherRaoMVN(N0, Nmid, eps)+FisherRaoMVN(Nmid, N1, eps);
    }
  }
  
    public static double SqrMahalanobisDistance(Matrix m1, Matrix m2, Matrix Sigma)
 {Matrix res;
 Matrix m12=m1.minus(m2);
 res=m12.transpose().times(Sigma.inverse()).times(m12);
 return res.get(0,0);
 }
 
 
  // non-totally geodesic submanifold
  	public static double FisherRaoSameCovariance(Matrix m1, Matrix m2, Matrix Sigma)
 {
  
 return  Math.sqrt(2)*arccosh(1.0+0.25*SqrMahalanobisDistance(m1,m2,Sigma));
 		
 }
 
 
 // totally geodesic submanifold
   	public static double FisherRaoSameMean(Matrix m, Matrix S1, Matrix S2)
 {
  
 return  ScaledRiemannianSPDDistance(S1,S2);
 		
 }



  public static void main (String [] args)
  {
    System.out.println("Fisher-Rao MVN distance");
    Test();//good
    //Test2();
  }


 public static  Matrix randomSPDCholesky(int d)
  	  {
    int i, j;
    double [][] array=new double[d][d];
    Matrix L;

    for (i=0; i<d; i++)
      for (j=0; j<=i; j++)
      {
        array[i][j]=Math.random();
      }

    L=new Matrix(array);
    // Cholesky
    if (L.det()==0) return randomSPDCholesky(d);
    return L.times(L.transpose());
  }

  public static void Test()
  {
    Matrix m1, S1, m2, S2;
    vM N1, N2;
    
    System.out.println("Test Fisher-Rao distance between multivariate normal distributions");

    m1=new Matrix(2, 1);
    m1.set(0, 0, 0);
    m1.set(1, 0, 0);
    S1=new Matrix(2, 2);
    S1.set(0, 0, 1.0);
    S1.set(0, 1, 0);
    S1.set(1, 0, 0);
    S1.set(1, 1, 0.1);

    m2=new Matrix(2, 1);
    m2.set(0, 0, 1);
    m2.set(1, 0, 1);
    //m2=new Matrix(2,1);m2.set(0,0,0);m2.set(1,0,0);
    S2=new Matrix(2, 2);
    S2.set(0, 0, 0.1);
    S2.set(0, 1, 0);
    S2.set(1, 0, 0);
    S2.set(1, 1, 1);

    N1=new vM(m1, S1);
    N2=new vM(m2, S2);
    
    
    
double err;
    double eps=0.01;
    
    double fr,lb,ub;
    
    fr=FisherRaoMVN(N1, N2, eps);
 lb=LowerBoundCalvoOller(N1, N2);
    ub=UpperBoundSqrtJeffreys(N1, N2);
     System.out.println("Han & Park 2014 example (mid range).");
    System.out.println("Fisher-Rao distance (eps="+eps+"):"+fr);
  System.out.println("lower bound:"+lb+" upper bound:"+ub);
    // 3.1329
    
    
   
    m1=new Matrix(2,1);S1=Matrix.identity(2,2);
    m2=new Matrix(2,1);m2.set(0,0,10000);
    S2=Matrix.identity(2,2).times(10);
        N1=new vM(m1, S1);
    N2=new vM(m2, S2);
    
 fr=FisherRaoMVN(N1, N2, eps);
 lb=LowerBoundCalvoOller(N1, N2);
    ub=UpperBoundSqrtJeffreys(N1, N2);
     System.out.println("Han & Park 2014 example (long range).");
    System.out.println("Fisher-Rao distance (eps="+eps+"):"+fr);
  System.out.println("lower bound:"+lb+" upper bound:"+ub);

    // 23.5
    
    m1=new Matrix(2,1);m1.set(0,0,Math.random());m1.set(1,0,Math.random());
    m2=new Matrix(2,1);m2.set(0,0,Math.random());m2.set(1,0,Math.random());
    S1=S2=randomSPDCholesky(2);
            N1=new vM(m1, S1);
    N2=new vM(m2, S2);
 fr=FisherRaoMVN(N1, N2, eps);
double  exact;
exact=FisherRaoSameCovariance(m1,m2,S1);
  System.out.println("Same covariance matrix:");
  System.out.println("Fisher-Rao distance (eps="+eps+"):"+fr);
  System.out.println("exact="+exact);
  
  S1=randomSPDCholesky(2);
  S2=randomSPDCholesky(2);
  m1=m2;
   N1=new vM(m1, S1);
    N2=new vM(m2, S2);
 fr=FisherRaoMVN(N1, N2, eps);
   exact=FisherRaoSameMean(m1,S1,S2);
    System.out.println("Same mean:");
  System.out.println("Fisher-Rao distance (eps="+eps+"):"+fr);
  System.out.println("exact="+exact);
  
  double sigma1,sigma2;
  double mu1=Math.random();
  double mu2=Math.random();
  m1=new Matrix(1,1);m1.set(0,0,mu1);
  sigma1=1+Math.random();
  S1=new Matrix (1,1); S1.set(0,0,sqr(sigma1));
  
  m2=new Matrix(1,1);m2.set(0,0,mu2);
  sigma2=1+Math.random();
  S2=new Matrix (1,1); S2.set(0,0,sqr(sigma2));
  N1=new vM(m1, S1);
    N2=new vM(m2, S2);
 fr=FisherRaoMVN(N1, N2, eps);
 exact=RaoDistance1D(mu1,sigma1,mu2,sigma2);
 err=Math.abs(fr-exact)/exact;
 
     System.out.println("Rao distance in 1d case:");
  System.out.println("Fisher-Rao distance (eps="+eps+"):"+fr);
  System.out.println("exact="+exact);
  System.out.println("relative error="+err);
      }
      
     public static  void Test2()
      {int i,nb=200; int d=1;
      double fr;
      Matrix m1,S1,m2,S2;
      vM N1,N2;
      double eps=0.001;
      
      for(i=0;i<nb;i++)
      {
      	
       
  m1=new Matrix(d,1); 
  	  m2=new Matrix(d,1); 
  	  	for(int j=0;j<d;j++) {m1.set(j,0,Math.random());m2.set(j,0,Math.random());
  	  	}
  	S1=randomSPDCholesky(d);
  S2=randomSPDCholesky(d);
  
 
  N1=new vM(m1, S1);
    N2=new vM(m2, S2);
    
    double jey;
     fr=FisherRaoMVN(N1, N2, eps);
 jey=JeffreysMVN(N1,N2);
 System.out.println(jey+"\t"+fr);
 
      }
      	
      }
}



// compound (vector,Matrix) type for encoding multivariate normal distributions
class vM
{
  Matrix v, M;

  vM(Matrix vv, Matrix MM)
  {
    v=vv.copy();
    M=MM.copy();
  }

  // case of 1D constructor, say univariate normals
  vM(double mm, double vv)
  {
    v=new Matrix(1, 1);
    v.set(0, 0, mm);
    M=new Matrix(1, 1);
    M.set(0, 0, vv);
  }
  // compound inner product
  public static double inner(vM p1, vM p2)
  {
    return ((p1.v.transpose()).times(p2.v)).trace() + ((p1.M).times(p2.M)).trace();
  }

void print(String s)
{
System.out.println(s+":\n");
v.print(6,3); M.print(6,3);	
}

  public vM times(double l)
  {
    return new vM(v.times(l), M.times(l));
  }

  // compound subtraction
  public vM minus(vM p)
  {
    Matrix vv, MM;

    vv=v.minus(p.v);
    MM=M.minus(p.M);

    return new vM(vv, MM);
  }
  
  
    public vM plus(vM p)
  {
    Matrix vv, MM;

    vv=v.plus(p.v);
    MM=M.plus(p.M);

    return new vM(vv, MM);
  }

  public static String ToString(Matrix M)
  {
    int c=M.getColumnDimension();
    int l=M.getRowDimension();
    int i, j;
    String res="";

    for (i=0; i<l; i++)
    {
      for (j=0; j<c; j++)
      {
        res+=M.get(i, j)+" ";
      }
      res=res+"\n";
    }

    return res;
  }

  public String toString()
  {
    String res="";
    res+="v=\n"+ToString(v)+"\nM=\n"+ToString(M);
    return res;
  }
}

