// Frank.Nielsen@am.org
// October 2024
// Question: if input is on b bits, how many bits required to get result with b bits?
//
import org.apfloat.Apfloat;
import org.apfloat.ApfloatMath;

import java.util.Random;


class JeffreysCentroidApfloat
{
  static long nbprecision=200; //=Apfloat.INFINITE;

  static Apfloat one=new Apfloat(1, nbprecision);

  static Apfloat half=one.divide(new Apfloat(2, nbprecision)); // 1/2

  static Apfloat ten=new Apfloat(10, nbprecision);


  static Random generator = new Random(23); // for being deterministic


  // 10^{-nbprecision}
  static Apfloat prec=power(ten, new Apfloat(-nbprecision));

  static Apfloat TotalVariation(Apfloat [] array1, Apfloat [] array2)
  {
    int d=array1.length;
    Apfloat  res=new Apfloat(0, nbprecision);
    int i;
    for (i=0; i<d; i++)  res=res.add(ApfloatMath.abs(array1[i].subtract(array2[i])));

    return res.multiply(new Apfloat(0.5, nbprecision));
  }



  static Apfloat sum(Apfloat [] array)
  {
    Apfloat res=new Apfloat(0, nbprecision);
    for (int i=0; i<array.length; i++) res=res.add(array[i]);
    return res;
  }


  static Apfloat [] Normalize(Apfloat [] array)
  {
    int d=array.length;
    Apfloat [] res=new Apfloat [d];
    int i;
    Apfloat norm=sum(array);
    for (i=0; i<d; i++) res[i]=array[i].divide(norm);
    return res;
  }

  // $x^y=\exp(y\log x)$
  static Apfloat power(Apfloat x, Apfloat y)
  {
    return ApfloatMath.exp(y.multiply(ApfloatMath.log(x)));
  }


// main test
  static  void testJeffreysCentroid()
  {
    System.out.println("NF| Apfloat test Jeffreys centroid: precision="+nbprecision+" bits");

    // setSeed(23);

    int n=2, d=5;
    int i, j;
    Apfloat [][] set=new Apfloat[n][];

    for (i=0; i<n; i++) {
      set[i]=new Apfloat[d];
      for (j=0; j<d; j++)
      {
        set[i][j]=new Apfloat(generator.nextDouble(), nbprecision);
      }
      
 
      
      set[i]=Normalize(set[i]);
    }

/*

   // pathological case "0.999999999999999999"
      set[0][0]=new Apfloat("0.6",nbprecision);set[0][1]=new Apfloat(1, nbprecision).subtract(set[0][0]);
      
      set[1][0]=new Apfloat(1, nbprecision).divide(new Apfloat(2, nbprecision)); 
      set[0][1]=new Apfloat(1, nbprecision).divide(new Apfloat(2, nbprecision)); 
*/


    Apfloat [] A=ArithmeticMean(set);
    Apfloat [] G=NormalizedGeometricMean(set);

    Apfloat [] inductiveJ=inductiveJeffreysCentroid(A, G, prec);
    
    
    Apfloat [] J=NormalizedJeffreysCentroid(A, G);
    
    
    
    Apfloat cinductiveJ=sum(inductiveJ);
    Apfloat cJ=sum(J);
    System.out.println("cumulative sum inductive:"+cinductiveJ);
    System.out.println("cumulative sum Jeffreys:"+cJ);
    
    
 System.out.println("inductive Jeffreys center: (a, normalized g) mean");
 
    for (i=0; i<d; i++)
    {
      System.out.println(inductiveJ[i]);
    }
    
     System.out.println("normalized Jeffreys center: ");
     
     for (i=0; i<d; i++)
    {
      System.out.println(J[i]);
    }
    
    
    Apfloat tv=TotalVariation(inductiveJ,J);
System.out.println("Difference in total variation:"+tv);  
}



  // Arithmetic mean is always normalized
  static Apfloat [] ArithmeticMean(Apfloat [][] set)
  {
    int n=set.length, d=set[0].length;
    Apfloat [] res=new Apfloat [d];
    int i, j;
    for (i=0; i<d; i++)
    {
      res[i]=new Apfloat(0);
      for (j=0; j<n; j++) res[i]=res[i].add(set[j][i]);
      res[i]=res[i].divide(new Apfloat(n));
    }
    return res;
  }



  // Geometric mean needs to be normalized
  static Apfloat  [] NormalizedGeometricMean( Apfloat [][] set)
  {
    int n=set.length, d=set[0].length;
    Apfloat  [] res=new Apfloat  [d];
    int i, j;
    for (i=0; i<d; i++)
    {
      res[i]=new Apfloat(1);

      for (j=0; j<n; j++) res[i]=res[i].multiply(set[j][i]);

      res[i]=power(res[i], (one.divide(new Apfloat(n))));
    }

    return Normalize(res);
  }


static int nbrec=0;

  static Apfloat [] inductiveJeffreysCentroid(Apfloat [] p, Apfloat [] q, Apfloat eps)
  {
    int dim=p.length;
    Apfloat [][] set=new Apfloat[2][dim];
    set[0]=p;
    set[1]=q;

    Apfloat [] A, G;
    Apfloat error;

    A=ArithmeticMean(set);
    G=NormalizedGeometricMean(set);

    error=TotalVariation(A, G);

    if (error.compareTo(eps)==-1) {
      System.out.println("# recursion steps:"+nbrec);
      return A; // or G
  }
    else    {nbrec++; return inductiveJeffreysCentroid(A, G, eps);}
  }



  static Apfloat Jeffreys1D(Apfloat a, Apfloat g, Apfloat lambda)
  {
    return a.divide(ApfloatMath.w(ApfloatMath.exp((one.add(lambda))).multiply(a.divide(g))));
  }


  static Apfloat [] UnnormalizedJeffreysCentroid(Apfloat [] array1, Apfloat [] array2, Apfloat lambda)
  {
    int d=array1.length;
    Apfloat [] res=new Apfloat [d];
    int i;
    for (i=0; i<d; i++) res[i]= Jeffreys1D(array1[i], array2[i], lambda);
    return res;
  }


static Apfloat [] NormalizedJeffreysCentroid(Apfloat[] p, Apfloat[] q)
  {int dim=p.length;
    Apfloat [][] set=new Apfloat[2][dim];
    set[0]=p;
    set[1]=q;
    return NormalizedJeffreysCentroid(set);
  }


  static Apfloat [] NormalizedJeffreysCentroid(Apfloat [][] set)
  {
    Apfloat [] A, G;

    A=ArithmeticMean(set);
    G=NormalizedGeometricMean(set);


    Apfloat  lmin=new Apfloat(-1, nbprecision), lmax=new Apfloat(0, nbprecision), l, csum=new Apfloat(0, nbprecision);

    Apfloat eps=power(new Apfloat(10, nbprecision), new Apfloat(-nbprecision+2, nbprecision));

// System.out.println("Precision required:"+eps);

    while ((ApfloatMath.abs(lmax.subtract(lmin))).compareTo(eps)==1)
    {
      l=half.multiply(lmax.add(lmin));

      csum=sum(UnnormalizedJeffreysCentroid(A, G, l));

      if (csum.compareTo(one)==1) lmin=l;
      else lmax=l;
    }
    l=half.multiply(lmax.add(lmin));

    return UnnormalizedJeffreysCentroid(A, G, l);
  }
}
