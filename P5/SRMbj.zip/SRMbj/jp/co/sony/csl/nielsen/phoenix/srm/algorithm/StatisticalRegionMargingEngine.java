package jp.co.sony.csl.nielsen.phoenix.srm.algorithm;

import java.awt.Point;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jp.co.sony.csl.nielsen.phoenix.srm.Mark;

/**
 * This class is the implementation of Statistical Region Marging segmentation algorithm.
 * 
 * @author Hidehiko Abe
 */
public class StatisticalRegionMargingEngine {

	/**
	 * parameter g
	 */
	private double g;
	
	/**
	 * parameter q
	 */
	private double q;

	/**
	 * borderSize of length
	 */
	private int borderSize;
	
	public StatisticalRegionMargingEngine() {
		this(256.0, 32.0);
	}
	
	public StatisticalRegionMargingEngine(double g, double q) {
		this.g = g;
		this.q = q;
		this.borderSize = 0;
	}
	
	public SegmentationResult segmentation(int[] rasters, int width, int height, Map<Point, Mark> markMap) {
		assert rasters != null;
		assert rasters.length > 0;
		assert rasters.length == width * height;
		assert markMap != null;

        final double logDelta = 2.0*Math.log(6.0*rasters.length);
		
		RegionManager regionManager = RegionManager.createManager(rasters, markMap, width);
		Edge[] edges = Edge.createEdges(rasters, width, height);
		
		// sort by difference
		Arrays.sort(edges);

		for ( Edge edge : edges ) {
			// find region
			Region region1 = regionManager.getRegion(edge.getIndex1());
			Region region2 = regionManager.getRegion(edge.getIndex2());

			// test and marge
			if ( region1 == region2 ) {
				continue;
			}
			
			Mark mark1 = region1.getMark();
			Mark mark2 = region2.getMark();
			if ( mark1 == null && mark2 == null ) {
				if ( margePredicate(region1, region2, logDelta) ) {
					regionManager.merge(region1, region2);
				}
				continue;
			}

			if ( mark1 != null && mark2 != null ) {
				continue;
			}
			
			if ( mark1 == null ) {
				// swap
				{
					Region tmp = region1;
					region1 = region2;
					region2 = tmp;
				}
				{
					Mark tmp = mark1;
					mark1 = mark2;
					mark2 = tmp;
				}
			}

			// mark2 == null
			double minDifference = Double.MAX_VALUE;
			Region margeRegion = null;

			for ( Region region : regionManager.getRegionSet(mark1) ) {
				if ( margePredicate(region, region2, logDelta) ) {
					double redDifference   = region.getRedAverage()   - region2.getRedAverage();
					double greenDifference = region.getGreenAverage() - region2.getGreenAverage();
					double blueDifference  = region.getBlueAverage()  - region2.getBlueAverage();
					
					double tmp =  Math.max(redDifference   * redDifference,
								  Math.max(greenDifference * greenDifference,
										   blueDifference  * blueDifference));
					
					if ( tmp < minDifference ) {
						minDifference = tmp;
						margeRegion = region;
					}
				}
			}
			
			if ( margeRegion != null ) {
				regionManager.merge(margeRegion, region2);
			}
		}

		// marge small region
		{
			int smallRegion = rasters.length / 1000;
			if ( smallRegion > 0 ) {
				for ( int y = 0; y < height; ++y ) {
					for ( int x = 1; x < width; ++x ) {
						int index = y * width + x;
						Region region1 = regionManager.getRegion(index);
						Region region2 = regionManager.getRegion(index-1);
		
						
						if ( region1 != region2 && (region1.getMark() == null || region2.getMark() == null ) 
							&& (region1.getCount() < smallRegion || region2.getCount() < smallRegion) )
						{
							regionManager.merge(region1, region2);
						}
					}
				}
			}
		}

		// marge common mark region
		{
			for ( Mark mark : Mark.values() ) {
				while ( true ) {
					Set<Region> regionSet = regionManager.getRegionSet(mark);
					if ( regionSet == null || regionSet.size() <= 1 ) {
						break;
					}

					Iterator<Region> iterator = regionSet.iterator();
					Region region1 = iterator.next();
					Region region2 = iterator.next();
				
					regionManager.merge(region1, region2);
				}
			}
		}
		
		return new SegmentationResult(regionManager, width, height, borderSize);
	}
	
	private double dev(Region region, double logDelta) {
		assert region != null;

		int count = region.getCount();
		return (g * g) / (2.0 * q * count) * (Math.min(g, count) * Math.log(1.0 + count) + logDelta);
	}
	
	private boolean margePredicate(Region region1, Region region2, double logDelta) {
		assert region1 != null;
		assert region2 != null;
		
		double redDifference   = region1.getRedAverage()   - region2.getRedAverage();
		double greenDifference = region1.getGreenAverage() - region2.getGreenAverage();
		double blueDifference  = region1.getBlueAverage()  - region2.getBlueAverage();

		
		double threshold = dev(region1, logDelta) + dev(region2, logDelta);
		return    (redDifference   * redDifference   < threshold)
				&& (greenDifference * greenDifference < threshold)
				&& (blueDifference  * blueDifference  < threshold);
	}

	public void setParameterQ(double value) {
		this.q = value;
	}

	public double getParameterQ() {
		return this.q;
	}
	

}
