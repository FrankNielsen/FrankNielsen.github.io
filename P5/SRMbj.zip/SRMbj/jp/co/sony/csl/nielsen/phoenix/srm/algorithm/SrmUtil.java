package jp.co.sony.csl.nielsen.phoenix.srm.algorithm;

class SrmUtil {

	static int getRed(int color) {
		return  color        & 0xFF;
	}
	
	static int getGreen(int color) {
		return (color >>  8) & 0xFF;
	}
	
	static int getBlue(int color) {
		return (color >> 16) & 0xFF;
	}

	static int clamp(int value) {
		return Math.min(Math.max(0, value), 255);
	}
	
	private SrmUtil() {
	}
	
}
