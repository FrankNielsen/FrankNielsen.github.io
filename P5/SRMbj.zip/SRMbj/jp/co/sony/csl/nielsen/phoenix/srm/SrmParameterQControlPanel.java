package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

@SuppressWarnings("serial")
public class SrmParameterQControlPanel extends JPanel implements AdjustmentListener {

	private static class ParameterQDisplayLabel extends JLabel {
		
		private final SrmDocument document;

		public ParameterQDisplayLabel(SrmDocument document) {
			assert document != null;
			
			this.document = document;
			setPreferredSize(new Dimension(64, 10));
			setText("Q:" + document.getParameterQ());
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.setText("Q:" + document.getParameterQ());
			super.paintComponent(g);
		}
		
	}
	
	/**
	 * document object
	 */
	private final SrmDocument document;
	
	public SrmParameterQControlPanel(SrmDocument document) {
		this.document = document;

		this.setLayout(new BorderLayout());
		
		JScrollBar scrollBar = new JScrollBar(JScrollBar.HORIZONTAL, 32, 10, 1, 1024);
		scrollBar.addAdjustmentListener(this);
		
		this.add(BorderLayout.CENTER, scrollBar);
		this.add(BorderLayout.EAST,   new ParameterQDisplayLabel(document));
	}

	public void adjustmentValueChanged(AdjustmentEvent e) {
		document.setParameterQ(e.getValue());
		if ( !e.getValueIsAdjusting() ) {
			document.update();
		}
		getRootPane().repaint();
	}
	
}
