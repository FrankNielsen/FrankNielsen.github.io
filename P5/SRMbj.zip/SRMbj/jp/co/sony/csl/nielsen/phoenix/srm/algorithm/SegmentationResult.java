package jp.co.sony.csl.nielsen.phoenix.srm.algorithm;

import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

import jp.co.sony.csl.nielsen.phoenix.srm.Mark;

public class SegmentationResult {

	private final RegionManager regionManager;

	private final int width;
	
	private final int height;
	
	private final int borderSize;
	
	private final Map<Mark, BufferedImage> filterMap;
	
	SegmentationResult(RegionManager regionManager, int width, int height, int borderSize) {
		assert regionManager != null;

		this.regionManager = regionManager;
		this.width = width;
		this.height = height;
		this.borderSize = borderSize;
		this.filterMap = new HashMap<Mark, BufferedImage>();
	}

	public BufferedImage getResultImage() {
		// emit
		int[] result = new int[width * height];
		for ( int i = 0; i < result.length; ++i ) {
			Region region = regionManager.getRegion(i);

			int red   = SrmUtil.clamp((int)region.getRedAverage());
			int green = SrmUtil.clamp((int)region.getGreenAverage());
			int blue  = SrmUtil.clamp((int)region.getBlueAverage());
			
			result[i] = (blue << 16) | (green << 8) | red;
		}
		
		// draw segmentation line
		for ( int y = 1; y < height; ++y ) {
			for ( int x = 1; x < width; ++x ) {
				int index = y * width + x;
				Region region1 = regionManager.getRegion(index);
				Region region2 = regionManager.getRegion(index - 1 - width);

				if ( region1 != region2 ) {
					for ( int i = -borderSize; i <= borderSize; ++i ) {
						for ( int j = -borderSize; j <= borderSize; ++j ) {
							int tmp = (y + i) * width + (x + j);
							if ( tmp >= 0 && tmp < result.length ) {
								result[tmp] = 0xFFFFFF;
							}
						}
					}
				}
			}
		}
		
		BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_BGR);
		image.setRGB(0, 0, width, height, result, 0, width);
		return image;
	}

	public BufferedImage getFilterImage(Mark mark) {
		if ( mark == null ) {
			return null;
		}
		
		BufferedImage image = filterMap.get(mark);
		if ( image == null ) {
			image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

			int[] tmp = new int[width * height];
			for ( int i = 0; i < tmp.length; ++i ) {
				Region region = regionManager.getRegion(i);
				tmp[i] = (region.getMark() == mark) ? 0 : 0xFF000000;
			}
			image.setRGB(0, 0, width, height, tmp, 0, width);

			filterMap.put(mark, image);
		}
		return image;
	}
	
}
