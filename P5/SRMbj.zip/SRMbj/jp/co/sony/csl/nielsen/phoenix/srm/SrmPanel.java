package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Map;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SrmPanel extends JPanel implements MouseListener {

	/**
	 * The document of this applet
	 */
	private final SrmDocument document;
	
	/**
	 * Create Instance of the image paint panel
	 * @param document 
	 * @throws NullPointerException
	 */
	public SrmPanel(SrmDocument document) throws NullPointerException {
		if ( document == null ) {
			throw new NullPointerException();
		}
		this.document = document;

		this.setBackground(Color.WHITE);
		this.setDoubleBuffered(true);
		this.addMouseListener(this);
	}

	/**
	 * draw input and output images
	 */
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		// fit to the size of panel
		int width  = getWidth();
		int height = getHeight();

		int imageWidth  = document.getWidth();
		int imageHeight = document.getHeight();
		
		double ratio = Math.min((double)((width - 8) / 2) / imageWidth,
								(double)(height - 4)      / imageHeight);

		int drawWidth  = (int)(imageWidth  * ratio);
		int drawHeight = (int)(imageHeight * ratio);
		
		int xOffset = (width / 2 - drawWidth) / 2;
		int yOffset = (height - drawHeight) / 2;
		
		// draw the input image
		Image inputImage  = document.getInputImage();
		g.drawImage(inputImage, xOffset, yOffset, drawWidth, drawHeight, this);

		{
			Image filter = document.getFilterImage();
			if ( filter != null ) {
				g.drawImage(filter, xOffset, yOffset, drawWidth, drawHeight, this);
			}
		}
		
		// draw the output image
		int outputXOffset = width / 2 + xOffset;
		Image outputImage = document.getOutputImage();
		if ( outputImage != null ) {
			g.drawImage(outputImage, outputXOffset, yOffset, drawWidth, drawHeight, this);
		}

		if ( document.isShowMark() ) {
			Graphics2D g2d = Graphics2D.class.cast(g);
			Stroke backup = g2d.getStroke();
			g2d.setStroke(new BasicStroke(2.0f));
			
			// draw mark on the input image
			g.translate( xOffset,  yOffset);
			paintMark(g, ratio);
			g.translate(-xOffset, -yOffset);
			
			// draw mark on the output image
			g.translate( outputXOffset,  yOffset);
			paintMark(g, ratio);
			g.translate(-outputXOffset, -yOffset);
			
			g2d.setStroke(backup);
		}
	}

	private void paintMark(Graphics g, double ratio) {
		for ( Map.Entry<Point, Mark> entry : document.getMarkMap().entrySet() ) {
			Point p = entry.getKey();
			
			int x = (int)(p.x * ratio);
			int y = (int)(p.y * ratio);
			g.translate( x,  y);
			entry.getValue().draw(g);
			g.translate(-x, -y);
		}
	}
	
	public void mouseClicked(MouseEvent e) {
		int width  = getWidth();
		int height = getHeight();

		int imageWidth  = document.getWidth();
		int imageHeight = document.getHeight();
		
		double ratio = Math.min((double)((width - 8) / 2) / imageWidth,
								(double)(height - 4)      / imageHeight);

		int drawWidth  = (int)(imageWidth  * ratio);
		int drawHeight = (int)(imageHeight * ratio);
		
		int halfWidth = width / 2;
		
		int xOffset = (halfWidth - drawWidth) / 2;
		int yOffset = (height - drawHeight) / 2;

		int x = e.getX() - xOffset;
		int y = e.getY() - yOffset;

		if ( 0 <= y && y < drawHeight ) {
			if ( x >= halfWidth ) {
				x -= halfWidth;
			}
			if ( 0 <= x && x < drawWidth ) {
				Mark mark = document.getMark();
				int targetX = (int)(x / ratio);
				int targetY = (int)(y / ratio);

				if ( mark == null ) {
					document.removeMark(targetX, targetY);
				} else {
					document.addMark(targetX, targetY, mark);
				}
				if ( document.isAutoSegmentation() ) {
					document.update();
				}
				
				repaint();
			}
		}
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}
}
