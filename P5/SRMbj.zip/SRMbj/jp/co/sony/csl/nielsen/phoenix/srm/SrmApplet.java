package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;

import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 * This class is the applet of Statistical Region Merging
 * by Frank Nielsen and Richard Nock
 * 
 * For more, check:
 * Richard Nock, Frank Nielsen: Statistical Region Merging.
 * IEEE Trans. Pattern Anal. Mach. Intell. 26(11): 1452-1458 (2004)
 * 
 * Find more in the "Visual Computing: Geometry, Graphics, and Vision" book:
 * http://www.csl.sony.co.jp/person/nielsen/visualcomputing/
 * 
 * @author Hidehiko Abe
 */
@SuppressWarnings("serial")
public class SrmApplet extends JApplet {

	private static final String MESSAGE;

	private static final String ERROR_MESSAGE;
	
	static {
		String baseMessage =
			"R. Nock, F. Nielsen: Statistical Region Merging. IEEE Trans. Pattern Anal. Mach. Intell. 26(11): 1452-1458 (2004)\n"
		  + "F. Nielsen: Visual Computing: Geometry, Graphics, and Vision. Charles River Media: ISBN: 1584504277 (2005)\n"
		  + "This application is implemented by Hidehiko Abe.\n";
		
		MESSAGE =
			baseMessage
		  + "Adjust parameter Q with the scrollbar, mark biases by clicking images and press the `Segment' button to segment again.";

		ERROR_MESSAGE =
			baseMessage
		  + "!!! ERROR: COULD NOT READ IMAGE LOCATION FROM APPLET TAGS !!!";
	}
	
	/**
	 * Initialization of Applet
	 */
	@Override
	public void init() {
		try {
			String name = getParameter("img");
			Image inputImage = getImage(getDocumentBase(), name);

			SrmDocument     document     = new SrmDocument(inputImage);
			SrmControlPanel controlPanel = new SrmControlPanel(document);
			SrmPanel        mainPanel    = new SrmPanel(document);

			JTextArea textArea = new JTextArea(4, 0);
			textArea.setText(MESSAGE);
		
			Container c = getContentPane();
			c.add(BorderLayout.NORTH,  controlPanel);
			c.add(BorderLayout.CENTER, mainPanel);
			c.add(BorderLayout.SOUTH,  textArea);
		} catch (Exception e) {
			JLabel title = new SrmTitleLabel();
			JTextArea textArea = new JTextArea(4, 0);
			textArea.setText(ERROR_MESSAGE);

			Container c = getContentPane();
			// �O�̂��߈��폜
			c.removeAll();
			c.add(BorderLayout.NORTH,  title);
			c.add(BorderLayout.CENTER, textArea);
		}
	}

}
