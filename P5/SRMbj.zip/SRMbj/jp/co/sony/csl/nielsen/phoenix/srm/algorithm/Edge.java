package jp.co.sony.csl.nielsen.phoenix.srm.algorithm;

/**
 * This class represents an edge
 * @author Hidehiko Abe
 */
class Edge implements Comparable<Edge> {

	
	static Edge[] createEdges(int[] rasters, int width, int height) {
		
		Edge[] result = new Edge[(width - 1) * (height - 1) * 2 + (width - 1) + (height - 1)];

		int current = 0;
		for ( int y = 0; y < height; ++y ) {
			for ( int x = 0; x < width; ++x ) {
				int index = y * width + x;

				// horizontal edge
				if ( x < width-1 ) {
					int nextIndex = index + 1;
					result[current++] = new Edge(index, rasters[index], nextIndex, rasters[nextIndex]); 
				}

				// vertical edge
				if ( y < height-1 ) {
					int nextIndex = index + width;
					result[current++] = new Edge(index, rasters[index], nextIndex, rasters[nextIndex]);
				}
			}
		}
		
		return result;
	}

	/**
	 * index of point1
	 */
	private int index1;

	/**
	 * index of point2
	 */
	private int index2;

	/**
	 * the difference between point1's color and point2's.
	 * 
	 * c1 = point1's,
	 * c2 = point2's
	 * 
	 * difference = max( abs(c1.r - c2.r), abs(c1.g - c2.g), abs(c1.b - c2.b) )
	 */
	private int difference;

	private Edge(int index1, int color1, int index2, int color2) {
		this.index1 = index1;
		this.index2 = index2;
		
		this.difference = Math.max(
							Math.max(
								Math.abs(SrmUtil.getRed(color1)   - SrmUtil.getRed(color2)),
								Math.abs(SrmUtil.getGreen(color1) - SrmUtil.getGreen(color2))),
								Math.abs(SrmUtil.getBlue(color1)  - SrmUtil.getBlue(color2)));
	}

	int getIndex1() {
		return index1;
	}
	
	int getIndex2() {
		return index2;
	}

	public int compareTo(Edge o) {
		return this.difference - o.difference;
	}


}
