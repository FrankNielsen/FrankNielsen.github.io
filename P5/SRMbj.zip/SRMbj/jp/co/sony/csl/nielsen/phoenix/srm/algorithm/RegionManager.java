package jp.co.sony.csl.nielsen.phoenix.srm.algorithm;

import java.awt.Point;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import jp.co.sony.csl.nielsen.phoenix.srm.Mark;

/**
 * This is region magnager.
 * 
 * This class supports UnionFind algorithm.
 * 
 * @author Hidehiko Abe
 */
class RegionManager {

	/**
	 * create an instance of Region Manager which contains information of input rastres
	 * @param rasters
	 * @return
	 */
	static RegionManager createManager(int[] rasters, Map<Point, Mark> markMap, int width) {
		assert rasters        != null ;
		assert rasters.length !=    0 ;
		
		Region[] regions = new Region[rasters.length];
		Map<Mark, Set<Region>> markedRegion = new EnumMap<Mark, Set<Region>>(Mark.class);
		Point p = new Point();
		for ( int i = 0; i < rasters.length; ++i ) {
			int color = rasters[i];
			int red   = SrmUtil.getRed(color);
			int green = SrmUtil.getGreen(color);
			int blue  = SrmUtil.getBlue(color);

			p.x = i % width;
			p.y = i / width;
			
			Mark mark = markMap.get(p);
			regions[i] = new Region(red, green, blue, mark, i);
			if ( mark != null ) {
				Set<Region> set = markedRegion.get(mark);
				if ( set == null ) {
					set = new HashSet<Region>();
					markedRegion.put(mark, set);
				}
				set.add(regions[i]);
			}
		}
		
		return new RegionManager(regions, markedRegion);
	}

	private Region[] regions;
	
	private int[] parentIndices;
	
	private Map<Mark, Set<Region>> markedRegion;
	
	private RegionManager(Region[] regions, Map<Mark, Set<Region>> markedRegion) {
		assert regions != null;
		this.regions = regions;
		this.parentIndices = new int[regions.length];
		this.markedRegion = markedRegion;
		Arrays.fill(parentIndices, -1);
	}

	private int getRootIndex(int index) {
		int parentIndex = parentIndices[index];
		if ( parentIndex == -1 ) {
			return index;
		}
		parentIndex = getRootIndex(parentIndex);
		parentIndices[index] = parentIndex;
		return parentIndex;
	}
	
	public Region getRegion(int index1) {
		return regions[getRootIndex(index1)];
	}

	void merge(Region region1, Region region2) {
		parentIndices[region1.getIndex()] = region2.getIndex();
		regions[region1.getIndex()] = null;
		region2.merge(region1);

		{
			Set<Region> set = markedRegion.get(region1.getMark());
			if ( set != null )  {
				set.remove(region1);
			}
		}
		
		{
			Set<Region> set = markedRegion.get(region2.getMark());
			if ( set != null ) {
				set.add(region2);
			}
		}
	}
	
	Set<Region> getRegionSet(Mark mark) {
		return markedRegion.get(mark);
	}
}
