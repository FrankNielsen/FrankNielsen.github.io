package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class SrmControlPanel extends JPanel {

	public SrmControlPanel(SrmDocument document) throws NullPointerException {
		if ( document == null ) {
			throw new NullPointerException();
		}

		// create components
		JLabel title        = new SrmTitleLabel();
		JPanel controlPanel = new SrmParameterQControlPanel(document);
		JPanel biasPanel    = new SrmBiasPanel(document);
		
		// setup this panel
		this.setLayout(new BorderLayout());
		this.add(BorderLayout.NORTH,  title);
		this.add(BorderLayout.CENTER, controlPanel);
		this.add(BorderLayout.SOUTH,  biasPanel);
	}

}
