package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.Image;
import java.awt.Point;
import java.awt.image.PixelGrabber;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import jp.co.sony.csl.nielsen.phoenix.srm.algorithm.SegmentationResult;
import jp.co.sony.csl.nielsen.phoenix.srm.algorithm.StatisticalRegionMargingEngine;

/**
 * This class is the document of Statistical Region Merging Algorithm.
 * 
 * @author Hidehiko Abe
 */
public class SrmDocument {

	/**
	 * Input Image Object
	 */
	private Image inputImage;
	
	/**
	 * Output Image Object
	 */
	private Image outputImage;

	/**
	 * The width of image
	 */
	private int width;
	
	/**
	 * The height of image
	 */
	private int height;
	
	/**
	 * The raster array of default RGB model
	 */
	private int[] rasters;
	
	private StatisticalRegionMargingEngine srmEngine;

	private Mark currentSelectedMark;
	
	/**
	 * 
	 */
	private Map<Point, Mark> markMap;

	/**
	 * a flag whether do segmentation automatically or not.
	 */
	private boolean autoSegmentation;

	private SegmentationResult segmentationResult;
	
	private boolean showMark;

	private Mark filterMark;
	
	public SrmDocument(Image inputImage)
		throws NullPointerException, InterruptedException, IllegalArgumentException
	{
		if ( inputImage == null ) {
			throw new NullPointerException();
		}
		PixelGrabber pixelGrabber = new PixelGrabber(inputImage, 0, 0, -1, -1, true);
		if ( !pixelGrabber.grabPixels() ) {
			throw new IllegalArgumentException("Failed to grab pixels.");
		}
		
		this.inputImage  = inputImage;
		this.width       = pixelGrabber.getWidth();
		this.height      = pixelGrabber.getHeight();
		this.rasters     = int[].class.cast(pixelGrabber.getPixels());
		this.srmEngine   = new StatisticalRegionMargingEngine();
		this.markMap     = new HashMap<Point, Mark>();
		this.outputImage = null;
		this.currentSelectedMark = null;
		this.filterMark  = null;
		update();
	}
	
	
	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public Image getInputImage() {
		return inputImage;
	}

	public Image getOutputImage() {
		return outputImage;
	}
	
	public void setParameterQ(double value) {
		this.srmEngine.setParameterQ(value);
	}

	public double getParameterQ() {
		return srmEngine.getParameterQ();
	}

	public void update() {
		SegmentationResult result = srmEngine.segmentation(rasters, width, height, markMap);
		this.outputImage = result.getResultImage();
		this.segmentationResult = result;
	}

	public Map<Point, Mark> getMarkMap() {
		return Collections.unmodifiableMap(markMap);
	}

	public void setMark(Mark mark) {
		currentSelectedMark = mark;
	}
	
	public Mark getMark() {
		return currentSelectedMark;
	}
	
	public void removeMark(int x, int y) {
		Set<Point> keySet = markMap.keySet();
		if ( keySet.isEmpty() ) {
			// Do nothing.
			return;
		}
		
		// find nearest marked point
		final Point removePoint = new Point(x, y);
		Point p = Collections.min(keySet, new Comparator<Point>(){
			public int compare(Point o1, Point o2) {
				double diff = o1.distanceSq(removePoint) - o2.distanceSq(removePoint);
				if ( diff < 0 ) return -1;
				if ( diff > 0 ) return  1;
				return 0;
			}
		});

		// check threshold
		if ( p.distanceSq(removePoint) < 16 ) {
			markMap.remove(p);
		}
	}
	
	public void addMark(int x, int y, Mark mark) {
		assert mark != null;
		if ( x < 0 || width <= x || y < 0 || height <= y ) {
			return;
		}
		markMap.put(new Point(x, y), currentSelectedMark);
	}
	
	public void clearMark() {
		markMap.clear();
	}


	public void setAutoSegmentation(boolean value) {
		autoSegmentation = value;
	}

	public boolean isAutoSegmentation() {
		return autoSegmentation;
	}

	public void setShowMark(boolean value) {
		showMark = value;
	}

	public boolean isShowMark() {
		return showMark;
	}

	public void setFilterImageMark(Mark mark) {
		filterMark = mark;
	}
	
	public Image getFilterImage() {
		return segmentationResult.getFilterImage(filterMark);
	}
}
