package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public class SrmBiasPanel extends JPanel {

	private static class ComboBoxActionAdapter implements ActionListener {

		private final SrmDocument document;

		private final JComboBox comboBox;
		
		public ComboBoxActionAdapter(SrmDocument document, JComboBox comboBox) {
			assert document != null;
			assert comboBox != null;
			
			this.document = document;
			this.comboBox = comboBox;
		}

		public void actionPerformed(ActionEvent e) {
			Object item = comboBox.getSelectedItem();
			if ( item instanceof Mark ) {
				document.setMark(Mark.class.cast(item));
			} else {
				document.setMark(null);
			}
		}
	}
	
	private static class ClearButtonActionAdapter implements ActionListener {
		private final SrmDocument document;

		private final JButton button;
		
		public ClearButtonActionAdapter(SrmDocument document, JButton button) {
			assert document != null;
			assert button != null;
			
			this.document = document;
			this.button = button;
		}

		public void actionPerformed(ActionEvent e) {
			document.clearMark();
			if ( document.isAutoSegmentation() ) {
				document.update();
			}
			button.getRootPane().repaint();
		}
	}
	
	private static class ShowMarkCheckBoxAdapter implements ChangeListener {
		private final SrmDocument document;
		
		private final JCheckBox checkBox;

		public ShowMarkCheckBoxAdapter(SrmDocument document, JCheckBox checkBox) {
			assert document != null;
			assert checkBox != null;
			
			this.document = document;
			this.checkBox = checkBox;
			document.setShowMark(checkBox.isSelected());
		}

		public void stateChanged(ChangeEvent e) {
			document.setShowMark(checkBox.isSelected());
			checkBox.getRootPane().repaint();
		}
	
	}

	private static class SegmentationButtonActionAdapter implements ActionListener {

		private final SrmDocument document;
		
		private final JButton button;
		
		public SegmentationButtonActionAdapter(SrmDocument document, JButton button) {
			assert document != null;
			assert button != null;
			
			this.document = document;
			this.button = button;
		}
		
		public void actionPerformed(ActionEvent e) {
			document.update();
			button.getRootPane().repaint();
		}
		
	}
	
	private static class AutoSegmentationCheckBoxAdapter implements ChangeListener {
		private final SrmDocument document;
		
		private final JCheckBox checkBox;

		public AutoSegmentationCheckBoxAdapter(SrmDocument document, JCheckBox checkBox) {
			assert document != null;
			assert checkBox != null;
			
			this.document = document;
			this.checkBox = checkBox;
		}

		public void stateChanged(ChangeEvent e) {
			document.setAutoSegmentation(checkBox.isSelected());
			checkBox.getRootPane().repaint();
		}
	
	}
	
	private static class FilterComboBoxAdapter implements ActionListener {
		

		private final SrmDocument document;

		private final JComboBox comboBox;
		
		public FilterComboBoxAdapter(SrmDocument document, JComboBox comboBox) {
			assert document != null;
			assert comboBox != null;
			
			this.document = document;
			this.comboBox = comboBox;
		}

		public void actionPerformed(ActionEvent e) {
			Object item = comboBox.getSelectedItem();
			if ( item instanceof Mark ) {
				document.setFilterImageMark(Mark.class.cast(item));
			} else {
				document.setFilterImageMark(null);
			}
			comboBox.getRootPane().repaint();
		}
		
	}
	
	
	
	public SrmBiasPanel(SrmDocument document) {

		this.setLayout(new BorderLayout());
		
		JComboBox comboBox = new JComboBox(Mark.values());
		comboBox.addActionListener(new ComboBoxActionAdapter(document, comboBox));
		document.setMark(Mark.class.cast(comboBox.getSelectedItem()));
		comboBox.addItem("===DELETE===");
		this.add(BorderLayout.CENTER, comboBox);

		JPanel panel = new JPanel();
		{
			panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
			{
				JButton button = new JButton();
				button.setText("Clear");
				button.addActionListener(new ClearButtonActionAdapter(document, button));
				panel.add(button);
			}

			{
				JCheckBox checkBox = new JCheckBox();
				checkBox.setText("ShowMark");
				checkBox.setSelected(true);
				checkBox.addChangeListener(new ShowMarkCheckBoxAdapter(document, checkBox));
				panel.add(checkBox);
			}
			
			{
				JButton button = new JButton();
				button.setText("Segmentation");
				button.addActionListener(new SegmentationButtonActionAdapter(document, button));
				panel.add(button);
			}
			
			{
				JCheckBox checkBox = new JCheckBox();
				checkBox.setText("AutoSegmentation");
				checkBox.addChangeListener(new AutoSegmentationCheckBoxAdapter(document, checkBox));
				panel.add(checkBox);
			}
			
			{
				JComboBox filterComboBox = new JComboBox();
				filterComboBox.addItem("===NO FILTERING===");
				document.setFilterImageMark(null);
				for ( Mark mark : Mark.values() ) {
					filterComboBox.addItem(mark);
				}
				filterComboBox.addActionListener(new FilterComboBoxAdapter(document, filterComboBox));
				panel.add(filterComboBox);
			}
		
		}
		this.add(BorderLayout.EAST, panel);
	}

}
