package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.Color;
import java.awt.Graphics;

/**
 * This enum represents Mark of bias.
 * 
 * @author Hidehiko Abe
 */
public enum Mark {

	/**
	 * diamond mark
	 */
	DIAMOND(Color.ORANGE) {
		protected void drawMark(Graphics g) {
			g.drawLine( 0, -6, -4,  0);
			g.drawLine(-4,  0,  0,  6);
			g.drawLine( 0,  6,  4,  0);
			g.drawLine( 2,  0,  0, -4);
		}
	},

	/**
	 * circle mark
	 */
	CIRCLE(Color.RED) {
		protected void drawMark(Graphics g) {
			g.drawOval(-6, -6, 12, 12);
		}
	},
	
	/**
	 * triangle mark
	 */
	TRIANGLE(new Color(153, 76, 0)) {
		protected void drawMark(Graphics g) {
			g.drawLine( 0, -4, -4,  2);
			g.drawLine(-4,  2,  4,  2);
			g.drawLine( 4,  2,  0, -4);
		}
	},

	/**
	 * square mark
	 */
	SQUARE(Color.GREEN) {
		protected void drawMark(Graphics g) {
			g.drawLine(-4, -4, -4,  4);
			g.drawLine(-4,  4,  4,  4);
			g.drawLine( 4,  4,  4, -4);
			g.drawLine( 4, -4, -4, -4);
		}
	},
	
	/**
	 * cross mark
	 */
	CROSS(Color.BLUE) {
		protected void drawMark(Graphics g) {
			g.drawLine(-4, -4,  4,  4);
			g.drawLine( 4, -4, -4,  4);
		}
	},
	
	/**
	 * star mark
	 */
	STAR(Color.YELLOW) {
		protected void drawMark(Graphics g) {
			g.drawLine( 0, -4, -2,  4);
			g.drawLine( 0, -4,  2,  4);
			g.drawLine(-2,  4,  4, -2);
			g.drawLine( 2,  4, -4, -2);
			g.drawLine(-4, -2,  4, -2);
		}
	},
	
	/**
	 * sharp mark
	 */
	SHARP(new Color(192, 0, 255)) {
		protected void drawMark(Graphics g) {
			g.drawLine(-2, -4, -2,  4);
			g.drawLine( 2, -4,  2,  4);
			g.drawLine(-4, -2,  4, -2);
			g.drawLine(-4,  2,  4,  2);
		}
	},
	
	/**
	 * diagonal box mark
	 */
	DIAGONAL_BOX(Color.WHITE) {
		protected void drawMark(Graphics g) {
			g.drawLine(-4, -4, -4,  4);
			g.drawLine(-4,  4,  4,  4);
			g.drawLine( 4,  4,  4, -4);
			g.drawLine( 4, -4, -4, -4);

			g.drawLine(-4, -4,  4,  4);
			g.drawLine(-4,  4,  4, -4);
		}
	},
	
	/**
	 * kissing triangle mark
	 */
	KISSING_TRIANGLE(Color.PINK) {
		protected void drawMark(Graphics g) {
			g.drawLine(-4,  4,  4,  4);
			g.drawLine( 4, -4, -4, -4);

			g.drawLine(-4, -4,  4,  4);
			g.drawLine(-4,  4,  4, -4);
		}
	},
	;
	
	/**
	 * color of mark
	 */
	private Color color;

	/**
	 * create mark width specified color
	 * @param color  the color of mark
	 */
	private Mark(Color color) {
		assert color != null;
		this.color = color;
	}

	/**
	 * draw mark with specified color
	 * @param g Graphics object
	 */
	public void draw(Graphics g) {
		g.setColor(color);
		drawMark(g);
	}

	/**
	 * draw mark method
	 * @param g Graphics object
	 */
	protected abstract void drawMark(Graphics g);
}
