package jp.co.sony.csl.nielsen.phoenix.srm;

import java.awt.Font;

import javax.swing.JLabel;

/**
 * This class represents the title label of applet.
 * 
 * @author Hidehiko Abe
 */
@SuppressWarnings("serial")
public class SrmTitleLabel extends JLabel {

	/**
	 * text of title
	 */
	private static final String TITLE
		= "SRMbj - Statistical Region Merging with bias in Java by F. Nielsen and R. Nock";

	/**
	 * font of title
	 */
	private static final Font TITLE_FONT
		= new Font("Helvetica", Font.BOLD, 18);
	
	/**
	 * create the title label
	 */
	public SrmTitleLabel() {
		super(TITLE, JLabel.CENTER);
		setFont(TITLE_FONT);
	}

}
