package jp.co.sony.csl.nielsen.phoenix.srm.algorithm;

import jp.co.sony.csl.nielsen.phoenix.srm.Mark;

/**
 * THis class represents a region of image
 * 
 * @author Hidehiko Abe
 */
public class Region {

	/**
	 * The number of pixels which is contained in this region
	 */
	private int count;
	
	/**
	 * average of red color
	 */
	private double redAverage;
	
	/**
	 * average of green color
	 */
	private double greenAverage;
	
	/**
	 * average of blue color
	 */
	private double blueAverage;

	/**
	 * mark of this region
	 */
	private Mark mark;

	private int index;
	
	Region(double red, double green, double blue, Mark mark, int index) {
		this.count        = 1;
		this.redAverage   = red;
		this.greenAverage = green;
		this.blueAverage  = blue;
		this.mark         = mark;
		this.index        = index;
	}

	public void merge(Region other) {
		int    count        = this.count + other.count;
		double redAverage   = (this.count * this.redAverage   + other.count * other.redAverage)   / count;
		double greenAverage = (this.count * this.greenAverage + other.count * other.greenAverage) / count;
		double blueAverage  = (this.count * this.blueAverage  + other.count * other.blueAverage)  / count;

		this.count        = count;
		this.redAverage   = redAverage;
		this.greenAverage = greenAverage;
		this.blueAverage  = blueAverage;

		if ( mark == null ) {
			mark = other.mark;
		} else if ( other.mark == null ) {
			other.mark = mark;
		}
	}

	public int getCount() {
		return count;
	}
	
	public double getRedAverage() {
		return redAverage;
	}
	
	public double getGreenAverage() {
		return greenAverage;
	}
	
	public double getBlueAverage() {
		return blueAverage;
	}

	public Mark getMark() {
		return mark;
	}

	int getIndex() {
		return index;
	}
}
