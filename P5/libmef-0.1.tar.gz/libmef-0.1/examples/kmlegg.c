#include <stdio.h>
#include <stdlib.h>
#include <float.h>

#include <mef.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

void example1(void) {
  int k = 3;
  int n = 5000;
  int d = 1;
  double *data = malloc(k * n * sizeof(double));

  const gsl_rng_type *T;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  gsl_rng *rng = gsl_rng_alloc(T);

  for (unsigned int i=0; i<n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 10;
  }
  for (unsigned int i=n; i<2*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 0;
  }
  for (unsigned int i=2*n; i<3*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + -10;
  }

  kmlegg kmlegg = kmlegg_create(k, data, k*n, d);
  kmlegg->maxiter1 = 10;
  /* kmlegg->maxiter2 = 3; */

  double best_error = DBL_MAX;
  kmeans km;
  kmeans km0;
  for (unsigned int i=0; i<10; i++) {
    km0 = kmeans_create(k, data, k*n, d);
    kmeans_initialize_random(km0, rng);
    kmeans_run(km0);

    if (km0->old_error < best_error) {
      km = km0;
      best_error = km0->old_error;
    }
    else {
      kmeans_destroy(km0);
    }
  }

  kmlegg_initialize_from_clustering(kmlegg, km->weights, km->affectation);
  mixture_fprint(stdout, kmlegg->mixture);

  kmlegg_run(kmlegg);
  mixture_fprint(stdout, kmlegg->mixture);

  kmeans_destroy(km);

  kmlegg_destroy(kmlegg);
}

void example2(void) {
  int k = 3;
  int n = 5000;
  int d = 1;
  double *data = malloc(k * n * sizeof(double));

  const gsl_rng_type *T;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  gsl_rng *rng = gsl_rng_alloc(T);

  for (unsigned int i=0; i<n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 1;
  }
  for (unsigned int i=n; i<2*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 2;
  }
  for (unsigned int i=2*n; i<3*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 0;
  }

  kmlegg kmlegg = kmlegg_create(k, data, k*n, d);
  kmlegg->maxiter1 = 10;
  /* kmlegg->maxiter2 = 3; */

  double best_error = DBL_MAX;
  kmeans km;
  kmeans km0;
  for (unsigned int i=0; i<10; i++) {
    km0 = kmeans_create(k, data, k*n, d);
    kmeans_initialize_random(km0, rng);
    kmeans_run(km0);

    if (km0->old_error < best_error) {
      km = km0;
      best_error = km0->old_error;
    }
    else {
      kmeans_destroy(km0);
    }
  }

  kmlegg_initialize_from_clustering(kmlegg, km->weights, km->affectation);
  mixture_fprint(stdout, kmlegg->mixture);

  kmlegg_run(kmlegg);
  mixture_fprint(stdout, kmlegg->mixture);

  kmeans_destroy(km);

  kmlegg_destroy(kmlegg);
}

int main(int argc, char **argv) {
  example1();
  example2();
}

