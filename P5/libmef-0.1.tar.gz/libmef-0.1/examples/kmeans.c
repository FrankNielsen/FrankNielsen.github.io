#include <stdio.h>
#include <stdlib.h>
#include <mef.h>

int main(int argc, char **argv) {
  double data[8] = {
    0,1,
    2,3,
    4,5,
    6,6,
  };
  kmeans kmeans = kmeans_create(3, data, 4, 2);

  const gsl_rng_type *T;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  gsl_rng *rng = gsl_rng_alloc(T);
  kmeans_initialize_random(kmeans, rng);

  kmeans_run(kmeans);

  printf("Number of iterations: %i\n", kmeans->iter);
  printf("\n");

  printf("Error: %f\n", kmeans->error);
  printf("\n");

  printf("* Affectation\n");
  for(unsigned int i=0; i<kmeans->n; i++) {
    printf("  %i %i\n", i, kmeans->affectation[i]);
  }
  printf("\n");

  printf("* Weights and counts\n");
  for(unsigned int i=0; i<kmeans->k; i++) {
    printf("  %i %f %i\n", i, kmeans->weights[i], kmeans->counts[i]);
  }
  printf("\n");

  printf("* Centroids\n");
  for (unsigned int i=0; i<kmeans->centroids->size1; i++) {
    for (unsigned int j=0; j<kmeans->centroids->size2; j++) {
      printf("  %f", gsl_matrix_get(kmeans->centroids, i, j));
    }
    printf("\n");
  }

  kmeans_destroy(kmeans);
}

