#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <mef.h>

int main(int argc, char **argv) {
  mixture mix = mixture_create(3);

  GeneralizedGaussian_family ef0 = GeneralizedGaussian(-1., 0.5);
  GeneralizedGaussian_family ef1 = GeneralizedGaussian(10., 10.);
  GeneralizedGaussian_family ef2 = GeneralizedGaussian(1. , 1. );
  mix->ef[0] = (family)ef0;
  mix->ef[1] = (family)ef1;
  mix->ef[2] = (family)ef2;;

  mix->params[0] = (param)GeneralizedGaussian_create_source(ef0, 1.);
  mix->params[1] = (param)GeneralizedGaussian_create_source(ef1, 3.);
  mix->params[2] = (param)GeneralizedGaussian_create_source(ef2, 5.);

  mix->weights[0] = 0.2;
  mix->weights[1] = 0.5;
  mix->weights[2] = 0.3;

  mixture_fprint(stderr, mix);

  unsigned int n = 1000;
  double x_min = -20.;
  double x_max =  20.;
  double dx = (x_max - x_min) / n;

  double x = x_min;
  for(int i=0; i < n; i++) {
    printf("%i %f %f %f %f %f\n", i, x,
           mixture_pdf(mix, x),
           mix->weights[0] * mix->ef[0]->pdf(mix->ef[0], x, mix->params[0]),
           mix->weights[1] * mix->ef[2]->pdf(mix->ef[1], x, mix->params[1]),
           mix->weights[2] * mix->ef[1]->pdf(mix->ef[2], x, mix->params[2])
           );
    x += dx;
  }

}

