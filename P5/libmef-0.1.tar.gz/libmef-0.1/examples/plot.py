#! /usr/bin/python

import sys
import numpy
from matplotlib import pyplot

m = numpy.loadtxt(sys.argv[1])

for i in xrange(2, m.shape[1]):
    pyplot.plot(m[:,1], m[:,i])

pyplot.show()

