#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <mef.h>

int main(int argc, char **argv) {
  mixture mix = mixture_create(3);

  Gaussian_family ef = Gaussian();
  mix->ef[0] = (family)ef;
  mix->ef[1] = (family)ef;
  mix->ef[2] = (family)ef;

  param lambda0 = (param)Gaussian_create_source(ef,   0., 1.);
  param lambda1 = (param)Gaussian_create_source(ef, -10., 3.);
  param lambda2 = (param)Gaussian_create_source(ef,   5., 5.);
  mix->params[0] = lambda0;
  mix->params[1] = lambda1;
  mix->params[2] = lambda2;

  mix->weights[0] = 0.2;
  mix->weights[1] = 0.5;
  mix->weights[2] = 0.3;

  mixture_fprint(stderr, mix);

  unsigned int n = 1000;
  double x_min = -20.;
  double x_max =  20.;
  double dx = (x_max - x_min) / n;

  double x = x_min;
  for(int i=0; i < n; i++) {
    printf("%i %f %f %f %f %f\n", i, x,
           mixture_pdf(mix, x),
           mix->weights[0] * ef->pdf(ef, x, mix->params[0]),
           mix->weights[1] * ef->pdf(ef, x, mix->params[1]),
           mix->weights[2] * ef->pdf(ef, x, mix->params[2])
           );
    x += dx;
  }

}

