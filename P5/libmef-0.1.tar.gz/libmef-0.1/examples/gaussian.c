#include <stdio.h>
#include <stdlib.h>
#include <mef.h>

void Gaussian_print(family ef, param param);

int main(int argc, char **argv) {
  Gaussian_family ef = Gaussian();
  fprintf(stderr, "Family: %s\n", ef->name);

  unsigned int n = 1000000;
  double x_min = -10.;
  double x_max =  10.;
  double dx = (x_max - x_min) / n;
  double x = x_min;
  Gaussian_source lambda0 = Gaussian_create_source(ef, 0., 9.);
  Gaussian_source lambda4 = Gaussian_create_source(ef, 0., 3.);
  double *in   = malloc(n * sizeof(double));
  double *out1 = malloc(n * sizeof(double));
  double *out2 = malloc(n * sizeof(double));

  for(int i=0; i < n; i++) {
    in[i] = x;
    x += dx;
  }

  ef->iter_pdf(ef, n, in, (param)lambda0, out1);
  ef->iter_pdf(ef, n, in, (param)lambda4, out2);
  for(int i=0; i < n; i++) {
    printf("%i %f %f %f\n", i, in[i], out1[i], out2[i]);
  }

  Gaussian_source lambda1   = Gaussian_create_source(ef, 1., 9.);
  Gaussian_source lambda2   = ef->new_param(ef, SOURCE);;
  Gaussian_source lambda3   = ef->new_param(ef, SOURCE);;
  Gaussian_natural theta1   = ef->new_param(ef, NATURAL);
  Gaussian_natural theta2   = ef->new_param(ef, NATURAL);
  Gaussian_expectation eta1 = ef->new_param(ef, EXPECTATION);
  Gaussian_expectation eta2 = ef->new_param(ef, EXPECTATION);

  ef->fprint(stderr, ef, (param)lambda1);
  ef->lambda2theta(ef, (param)lambda1, (param)theta1);
  ef->fprint(stderr, ef, (param)theta1);
  ef->theta2lambda(ef, (param)theta1, (param)lambda2);

  ef->lambda2eta(ef, (param)lambda1, (param)eta1);
  ef->fprint(stderr, ef, (param)eta1);
  ef->eta2lambda(ef, (param)eta1, (param)lambda3);
  ef->fprint(stderr, ef, (param)lambda3);

  ef->lambda2theta(ef, (param)lambda1, (param)theta2);
  ef->fprint(stderr, ef, (param)theta2);
  ef->theta2eta(ef, (param)theta2, (param)eta2);
  ef->fprint(stderr, ef, (param)eta2);
  ef->eta2theta(ef, (param)eta2, (param)theta2);
  ef->fprint(stderr, ef, (param)theta2);

  return 0;
}
