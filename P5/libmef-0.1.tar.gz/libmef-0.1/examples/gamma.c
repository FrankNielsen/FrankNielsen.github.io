#include <stdio.h>
#include <stdlib.h>
#include <mef.h>

int main(int argc, char **argv) {
  GammaFixedRate_family ef1 = GammaFixedRate(1.);
  GammaFixedRate_family ef2 = GammaFixedRate(2.);
  GammaFixedRate_family ef3 = GammaFixedRate(3.);

  unsigned int n     = 1000;
  double       x_min = 0.;
  double       x_max = 11.;
  double       dx    = (x_max - x_min) / n;
  double       x     = x_min;
  GammaFixedRate_source lambda1 = GammaFixedRate_create_source(ef1, 3.);
  GammaFixedRate_source lambda2 = GammaFixedRate_create_source(ef2, 3.);
  GammaFixedRate_source lambda3 = GammaFixedRate_create_source(ef3, 3.);

  ef1->fprint(stderr, ef1, (param)lambda1);

  double *in   = malloc(n * sizeof(double));
  double *out1 = malloc(n * sizeof(double));
  double *out2 = malloc(n * sizeof(double));
  double *out3 = malloc(n * sizeof(double));
  for(int i=0; i < n; i++) {
    in[i] = x;
    x += dx;
  }

  ef1->iter_pdf(ef1, n, in, (param)lambda1, out1);
  ef2->iter_pdf(ef2, n, in, (param)lambda2, out2);
  ef3->iter_pdf(ef3, n, in, (param)lambda3, out3);
  for(int i=0; i < n; i++) {
    printf("%i %f %f %f %f\n", i, in[i], out1[i], out2[i], out3[i]);
  }

  return 0;
}
