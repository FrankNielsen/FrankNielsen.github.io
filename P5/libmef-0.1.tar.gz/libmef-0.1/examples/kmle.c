#include <stdio.h>
#include <stdlib.h>
#include <float.h>

#include <mef.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

int main(int argc, char **argv) {
  int k = 3;
  int n = 5000;
  int d = 1;
  double *data = malloc(k * n * sizeof(double));

  const gsl_rng_type *T;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  gsl_rng *rng = gsl_rng_alloc(T);

  for (unsigned int i=0; i<n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 10;
  }
  for (unsigned int i=n; i<2*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 0;
  }
  for (unsigned int i=2*n; i<3*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + -10;
  }

  Gaussian_family ef = Gaussian();
  param lambda = ef->new_param(ef, SOURCE);

  kmle kmle = kmle_create((family)ef, k, data, k*n, d);
  kmle->maxiter1 = 10;
  /* kmle->maxiter2 = 3; */

  double best_error = DBL_MAX;
  kmeans km;
  kmeans km0;
  for (unsigned int i=0; i<10; i++) {
    km0 = kmeans_create(k, data, k*n, d);
    kmeans_initialize_random(km0, rng);
    kmeans_run(km0);

    if (km0->old_error < best_error) {
      km = km0;
      best_error = km0->old_error;
    }
    else {
      kmeans_destroy(km0);
    }
  }

  /* printf("error: %f\n", km->old_error); */
  /* for (unsigned int i=0; i<k*n; i++) { */
  /*   printf("%i %i %f\n", i, km->affectation[i], data[i]); */
  /* } */

  kmle_initialize_from_clustering(kmle, km->weights, km->affectation);
  for (unsigned int i=0; i<k; i++) {
    kmle->ef->theta2lambda(kmle->ef, kmle->components[i], lambda);
    kmle->ef->fprint(stdout, kmle->ef, lambda);
  }
  /* assert(0); */

  kmle_run(kmle);

  kmeans_destroy(km);

  for (unsigned int i=0; i<k; i++) {
    printf("%i %f ", i, kmle->weights[i]);
    kmle->ef->theta2lambda(kmle->ef, kmle->components[i], lambda);
    kmle->ef->fprint(stdout, kmle->ef, lambda);
  }

  kmle_destroy(kmle);
}

