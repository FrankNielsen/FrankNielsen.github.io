#include <stdio.h>
#include <stdlib.h>
#include <mef.h>

int main(int argc, char **argv) {
  GeneralizedGaussian_family ef1 = GeneralizedGaussian(1., 2.);
  fprintf(stderr, "Family 1: %s\n", ef1->name);

  GeneralizedGaussian_family ef2 = GeneralizedGaussian(1., 1.);
  fprintf(stderr, "Family 2: %s\n", ef2->name);

  GeneralizedGaussian_family ef3 = GeneralizedGaussian(1., 0.5);
  fprintf(stderr, "Family 3: %s\n", ef3->name);

  GeneralizedGaussian_family ef4 = GeneralizedGaussian(1., 10.);
  fprintf(stderr, "Family 4: %s\n", ef4->name);

  unsigned int n     = 1000;
  double       x_min = -9.;
  double       x_max = 11.;
  double       dx    = (x_max - x_min) / n;
  double       x     = x_min;
  GeneralizedGaussian_source lambda1 = GeneralizedGaussian_create_source(ef1, 3.);
  GeneralizedGaussian_source lambda2 = GeneralizedGaussian_create_source(ef2, 3.);
  GeneralizedGaussian_source lambda3 = GeneralizedGaussian_create_source(ef3, 3.);
  GeneralizedGaussian_source lambda4 = GeneralizedGaussian_create_source(ef4, 3.);

  ef1->fprint(stderr, ef1, (param)lambda1);

  double *in   = malloc(n * sizeof(double));
  double *out1 = malloc(n * sizeof(double));
  double *out2 = malloc(n * sizeof(double));
  double *out3 = malloc(n * sizeof(double));
  double *out4 = malloc(n * sizeof(double));
  for(int i=0; i < n; i++) {
    in[i] = x;
    x += dx;
  }

  ef1->iter_pdf(ef1, n, in, (param)lambda1, out1);
  ef2->iter_pdf(ef2, n, in, (param)lambda2, out2);
  ef3->iter_pdf(ef3, n, in, (param)lambda3, out3);
  ef4->iter_pdf(ef4, n, in, (param)lambda4, out4);
  for(int i=0; i < n; i++) {
    printf("%i %f %f %f %f %f\n", i, in[i], out1[i], out2[i], out3[i], out4[i]);
  }

  /* GeneralizedGaussian_source lambda1 = malloc(sizeof(GeneralizedGaussian_source)); */
  /* lambda1->type = SOURCE; */
  /* lambda1->ef = ef; */
  /* lambda1->mu = 1.; */
  /* lambda1->sigma2 = 9.; */
  /* GeneralizedGaussian_source lambda2 = malloc(sizeof(GeneralizedGaussian_source)); */
  /* lambda2->type = SOURCE; */
  /* lambda2->ef = ef; */
  /* GeneralizedGaussian_source lambda3 = malloc(sizeof(GeneralizedGaussian_source)); */
  /* lambda3->type = SOURCE; */
  /* lambda3->ef = ef; */

  /* GeneralizedGaussian_natural theta1 = malloc(sizeof(GeneralizedGaussian_natural)); */
  /* theta1->type = NATURAL; */
  /* theta1->ef = ef; */
  /* GeneralizedGaussian_natural theta2 = malloc(sizeof(GeneralizedGaussian_natural)); */
  /* theta2->type = NATURAL; */
  /* theta2->ef = ef; */

  /* GeneralizedGaussian_expectation eta1 = malloc(sizeof(GeneralizedGaussian_expectation)); */
  /* eta1->type = EXPECTATION; */
  /* eta1->ef = ef; */
  /* GeneralizedGaussian_expectation eta2 = malloc(sizeof(GeneralizedGaussian_expectation)); */
  /* eta2->type = EXPECTATION; */
  /* eta2->ef = ef; */

  /* ef->fprint(stderr, ef, (param)lambda1); */
  /* ef->lambda2theta(ef, (param)lambda1, (param)theta1); */
  /* ef->fprint(stderr, ef, (param)theta1); */
  /* ef->theta2lambda(ef, (param)theta1, (param)lambda2); */

  /* ef->lambda2eta(ef, (param)lambda1, (param)eta1); */
  /* ef->fprint(stderr, ef, (param)eta1); */
  /* ef->eta2lambda(ef, (param)eta1, (param)lambda3); */
  /* ef->fprint(stderr, ef, (param)lambda3); */

  /* ef->lambda2theta(ef, (param)lambda1, (param)theta2); */
  /* ef->fprint(stderr, ef, (param)theta2); */
  /* ef->theta2eta(ef, (param)theta2, (param)eta2); */
  /* ef->fprint(stderr, ef, (param)eta2); */
  /* ef->eta2theta(ef, (param)eta2, (param)theta2); */
  /* ef->fprint(stderr, ef, (param)theta2); */

  return 0;
}
