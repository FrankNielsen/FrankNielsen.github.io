#include <stdio.h>
#include <stdlib.h>
#include <float.h>

#include <mef.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

int main(int argc, char **argv) {
  int k = 3;
  int n = 5000;
  int d = 1;
  double *data = malloc(k * n * sizeof(double));

  const gsl_rng_type *T;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  gsl_rng *rng = gsl_rng_alloc(T);

  for (unsigned int i=0; i<n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 1;
  }
  for (unsigned int i=n; i<2*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + 0;
  }
  for (unsigned int i=2*n; i<3*n; i++) {
    data[i] = gsl_ran_gaussian(rng, 1.0) + -10;
  }

  Gaussian_family ef = Gaussian();
  param lambda = ef->new_param(ef, SOURCE);

  em em1 = em_create((family)ef, k, data, k*n, d);
  em1->maxiter  = 100;
  em1->treshold = 1e-5;

  double best_error = DBL_MAX;
  kmeans km;
  kmeans km0;
  for (unsigned int i=0; i<1; i++) {
    km0 = kmeans_create(k, data, k*n, d);
    kmeans_initialize_random(km0, rng);
    kmeans_run(km0);

    if (km0->old_error < best_error) {
      km = km0;
      best_error = km0->old_error;
    }
    else {
      kmeans_destroy(km0);
    }
  }

  printf("Initialization:\n");
  em_initialize_from_clustering(em1, km->weights, km->affectation);
  for (unsigned int i=0; i<k; i++) {
    em1->ef->eta2lambda(em1->ef, em1->components[i], lambda);
    em1->ef->fprint(stdout, em1->ef, lambda);
  }
  mixture_fprint(stdout, em1->mixture);

  printf("\nRunning:\n");
  mixture mix = em_run(em1);

  /* for (unsigned int i=0; i<k; i++) { */
  /*   printf("%i %f ", i, em1->weights[i]); */
  /*   em1->ef->eta2lambda(em1->ef, em1->components[i], lambda); */
  /*   em1->ef->fprint(stdout, em1->ef, lambda); */
  /* } */

  mixture_fprint(stdout, mix);

  em_destroy(em1);

  printf("\nStep by step:\n");
  /* Another version, printing information at each step */
  em em2 = em_create((family)ef, k, data, k*n, d);
  em2->maxiter  = 100;
  em2->treshold = 1e-5;

  em_initialize_from_clustering(em2, km->weights, km->affectation);

  for (unsigned int i=0; i<10; i++) {
    em_step(em2);
    printf("Step %i, ll=%f\n", em2->iter, em2->ll);
  }
  em_destroy(em2);

  kmeans_destroy(km);

  mixture_fprint(stdout, em2->mixture);
}

