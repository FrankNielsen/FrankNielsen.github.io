#! /usr/bin/python

import sys

from matplotlib import pyplot
import numpy

data = numpy.loadtxt(sys.argv[1])
pyplot.hist(data, 1000)

pyplot.show()

