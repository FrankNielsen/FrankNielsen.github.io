#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sf_psi.h>

#include <mef.h>

int fequal(double x, double y, double eps) {
  return fabs( (x - y) / y ) < eps;
}

double eps = 1e-300;

int main(int argc, char **argv) {
  GeneralizedGaussian_family ef = GeneralizedGaussian(3., 10.);

  /* Checking name */

  assert(strcmp(ef->name, "GeneralizedGaussian") == 0);

  /* /\* Checking pdf *\/ */

  /* double x1 = 0.1; */
  /* double x2 = 1.; */
  /* double x3 = 2.; */

  /* GeneralizedGaussian_source lambda = GeneralizedGaussian_create_source(ef, 1.); */
  /* double y1 = ef->pdf(ef, x1, (param)lambda); */
  /* double y2 = ef->pdf(ef, x2, (param)lambda); */
  /* double y3 = ef->pdf(ef, x3, (param)lambda); */

  /* double yy1 = gsl_ran_gamma_pdf(x1, lambda->shape, 1/ef->rate); */
  /* double yy2 = gsl_ran_gamma_pdf(x2, lambda->shape, 1/ef->rate); */
  /* double yy3 = gsl_ran_gamma_pdf(x3, lambda->shape, 1/ef->rate); */

  /* assert(fequal(y1, yy1, eps)); */
  /* assert(fequal(y2, yy2, eps)); */
  /* assert(fequal(y3, yy3, eps)); */

  /* Checking conversion functions */

  GeneralizedGaussian_source      lambda1 = GeneralizedGaussian_create_source(ef, 2.);
  GeneralizedGaussian_source      lambda2 = ef->new_param(ef, SOURCE);
  GeneralizedGaussian_source      lambda3 = ef->new_param(ef, SOURCE);
  GeneralizedGaussian_natural     theta1  = ef->new_param(ef, NATURAL);
  GeneralizedGaussian_natural     theta2  = ef->new_param(ef, NATURAL);
  GeneralizedGaussian_expectation eta1    = ef->new_param(ef, EXPECTATION);
  GeneralizedGaussian_expectation eta2    = ef->new_param(ef, EXPECTATION);

  ef->lambda2theta(ef, (param)lambda1, (param)theta1);
  ef->theta2lambda(ef, (param)theta1 , (param)lambda2);
  assert(fequal(lambda1->alpha, lambda2->alpha, eps));

  ef->lambda2eta(ef, (param)lambda1, (param)eta1);
  ef->eta2lambda(ef, (param)eta1   , (param)lambda3);
  assert(fequal(lambda1->alpha, lambda3->alpha, eps));

  ef->lambda2theta(ef, (param)lambda1, (param)theta2);
  ef->theta2eta   (ef, (param)theta2 , (param)eta2);
  ef->eta2theta   (ef, (param)eta2   , (param)theta2);
  assert(fequal(theta1->theta1, theta2->theta1, eps));

  /* Checking maximum likelihood estimator */
  const gsl_rng_type * T;
  gsl_rng * r;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
  int n2 = 100000;
  Gaussian_family gaussian = Gaussian();
  Gaussian_source lambda4 = Gaussian_create_source(gaussian, 3., 4.);
  double *data = malloc(n2 * sizeof(double));
  char   *mask = malloc(n2 * sizeof(char));
  for (unsigned int i = 0; i < n2; i++) {
    mask[i] = 1;
    data[i] = gaussian->rand(gaussian, (param)lambda4, r);
  }

  GeneralizedGaussian_expectation eta3 = ef->new_param(ef, EXPECTATION);
  GeneralizedGaussian_estimate_mu(ef, n2, data, mask);
  GeneralizedGaussian_estimate_beta(ef, n2, data, mask);
  ef->mle(ef, n2, data, mask, (param)eta3);
  assert(fequal(lambda4->mu, ef->mu, 0.01));
  assert(fequal(2.0, ef->beta, 0.01));
  assert(fequal(2 * lambda4->sigma2, - ef->beta * eta3->eta1, 0.1));

}
