#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <mef.h>

int fequal(double x, double y, double eps) {
  return fabs( (x - y) / y ) < eps;
}

double eps = 1e-300;

int main(int argc, char **argv) {
  Gaussian_family ef = Gaussian();

  /* Checking name */

  assert(strcmp(ef->name, "Gaussian") == 0);

  /* Checking pdf */

  Gaussian_source lambda = Gaussian_create_source(ef, 3., 9.);
  double y1 = ef->pdf(ef, -1., (param)lambda);
  double y2 = ef->pdf(ef,  0., (param)lambda);
  double y3 = ef->pdf(ef,  1., (param)lambda);
  
  double yy1 = gsl_ran_gaussian_pdf(-1 - lambda->mu, sqrt(lambda->sigma2));
  double yy2 = gsl_ran_gaussian_pdf( 0 - lambda->mu, sqrt(lambda->sigma2));
  double yy3 = gsl_ran_gaussian_pdf( 1 - lambda->mu, sqrt(lambda->sigma2));

  assert(fequal(y1, yy1, eps));
  assert(fequal(y2, yy2, eps));
  assert(fequal(y3, yy3, eps));

  /* Checking if iter_pdf behaves the same as pdf */

  unsigned int n = 1000;
  double x_min = -10.;
  double x_max =  10.;
  double dx = (x_max - x_min) / n;
  double x = x_min;
  double *in  = malloc(n * sizeof(double));
  double *out = malloc(n * sizeof(double));
  for(int i=0; i < n; i++) {
    in[i] = x;
    x    += dx;
  }
  ef->iter_pdf(ef, n, in, (param)lambda, out);

  assert(fequal(out[17] , ef->pdf(ef, in[17] , (param)lambda), eps));
  assert(fequal(out[42] , ef->pdf(ef, in[42] , (param)lambda), eps));
  assert(fequal(out[320], ef->pdf(ef, in[320], (param)lambda), eps));
  assert(fequal(out[520], ef->pdf(ef, in[520], (param)lambda), eps));

  /* Checking conversion functions */

  Gaussian_source      lambda1 = Gaussian_create_source(ef, 1., 9.);
  Gaussian_source      lambda2 = ef->new_param(ef, SOURCE);
  Gaussian_source      lambda3 = ef->new_param(ef, SOURCE);
  Gaussian_natural     theta1  = ef->new_param(ef, NATURAL);
  Gaussian_natural     theta2  = ef->new_param(ef, NATURAL);
  Gaussian_expectation eta1    = ef->new_param(ef, EXPECTATION);
  Gaussian_expectation eta2    = ef->new_param(ef, EXPECTATION);

  ef->lambda2theta(ef, (param)lambda1, (param)theta1);
  ef->theta2lambda(ef, (param)theta1 , (param)lambda2);
  assert(fequal(lambda1->mu    , lambda2->mu    , eps));
  assert(fequal(lambda1->sigma2, lambda2->sigma2, eps));

  ef->lambda2eta(ef, (param)lambda1, (param)eta1);
  ef->eta2lambda(ef, (param)eta1   , (param)lambda3);
  assert(fequal(lambda1->mu    , lambda3->mu    , eps));
  assert(fequal(lambda1->sigma2, lambda3->sigma2, eps));

  ef->lambda2theta(ef, (param)lambda1, (param)theta2);
  ef->theta2eta   (ef, (param)theta2 , (param)eta2);
  ef->eta2theta   (ef, (param)eta2   , (param)theta2);
  assert(fequal(theta1->theta1, theta2->theta1, eps));
  assert(fequal(theta1->theta2, theta2->theta2, eps));

  /* Checking maximum likelihood estimator */
  const gsl_rng_type * T;
  gsl_rng * r;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
  
  int n2 = 1000000;
  Gaussian_source lambda4 = Gaussian_create_source(ef, 2., 9.);
  
  double *data = malloc(n2 * sizeof(double));
  char   *mask = malloc(n2 * sizeof(char));
  
  for (unsigned int i = 0; i < n2; i++) {
    mask[i] = 1;
    data[i] = ef->rand(ef, (param)lambda4, r);
  }

  Gaussian_expectation eta3    = ef->new_param(ef, EXPECTATION);
  Gaussian_source      lambda5 = ef->new_param(ef, SOURCE);
  ef->mle(ef, n2, data, mask, (param)eta3);
  ef->eta2lambda(ef, (param)eta3, (param)lambda5);

  assert(fequal(lambda4->mu     , lambda5->mu    , 0.01));
  assert(fequal(lambda4->sigma2 , lambda5->sigma2, 0.01));
}

