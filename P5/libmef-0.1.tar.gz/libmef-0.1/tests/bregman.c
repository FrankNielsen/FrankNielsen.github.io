#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <mef.h>

int fequal(double x, double y, double eps) {
  return fabs(x - y) / fabs(x) < eps;
}

/* Good precision for comparison with double printed with %f */
double eps = 0.000001;

int main(int argc, char **argv) {
  Gaussian_family ef1 = Gaussian();
  param theta1 = (param)Gaussian_create_natural(ef1, 1. , -23.);
  param theta2 = (param)Gaussian_create_natural(ef1, 1. , -23.);
  param theta3 = (param)Gaussian_create_natural(ef1, 12., -14.);

  double d1 = bregman_div((family)ef1, theta1, theta1);
  printf("d(theta1, theta1) = %f\n", d1);
  assert(d1 == 0.); /* exactly equals to 0*/

  double d2 = bregman_div((family)ef1, theta1, theta2);
  printf("d(theta1, theta2) = %f\n", d2);
  assert(d2 == 0.); /* exactly equals to 0*/

  double d3 = bregman_div((family)ef1, theta1, theta3);
  printf("d(theta1, theta3) = %f\n", d3);
  assert(fequal(d3, 3.87, 0.1)); /* just for non-regression */

  mixture mix1 = mixture_create(1);
  mix1->ef[0] = (family)ef1;
  mix1->params[0] = theta1;
  mix1->weights[0] = 1.0;

  mixture mix3 = mixture_create(1);
  mix3->ef[0] = (family)ef1;
  mix3->params[0] = theta3;
  mix3->weights[0] = 1.0;

  const gsl_rng_type * T;
  gsl_rng * r;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);

  double d4 = kl_mc(mix3, mix1, 100000, r);
  printf("kl_mc(theta3, theta1) = %f\n", d4);
  assert(fequal(d3, d4, 0.1));

  /* double d2 = kl_mc(mix1, mix3, 100000, r); */
  /* printf("kl_mc(mix1, mix3)) = %f\n", d2); */
  /* assert(d2 == 0.); /\* exactly equals to 0*\/ */

  /* double d3 = kl_mc(mix1, mix4, 100000, r); */
  /* printf("kl_mc(mix1, mix4)) = %f\n", d3); */
  /* assert(fequal(d3, 0.031, 0.1)); /\* just for non-regression *\/ */

  /* double d4 = kl_mc(mix1, mix4, 100000, r); */
  /* printf("kl_mc(mix1, mix4)) = %f\n", d4); */
  /* assert(fequal(d4, d3, 0.1)); */

  /* double d5 = kl_mc(mix1, mix5, 100000, r); */
  /* printf("kl_mc(mix1, mix5)) = %f\n", d5); */
  /* assert(fequal(d5, 1.09, 0.1)); /\* just for non-regression *\/} */

}
