#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <mef.h>

int fequal(double x, double y, double eps) {
  return fabs(x - y) / fabs(x) < eps;
}

/* Good precision for comparison with double printed with %f */
double eps = 0.000001;

int main(int argc, char **argv) {
  unsigned int n = 3;
  mixture mix = mixture_create(n);

  Gaussian_family ef = Gaussian();
  mix->ef[0] = (family)ef;
  mix->ef[1] = (family)ef;
  mix->ef[2] = (family)ef;

  param lambda0 = (param)Gaussian_create_source(ef,   0., 9.);
  param lambda1 = (param)Gaussian_create_source(ef, -10., 3.);
  param lambda2 = (param)Gaussian_create_source(ef,   5., 5.);
  mix->params[0] = lambda0;
  mix->params[1] = lambda1;
  mix->params[2] = lambda2;

  mix->weights[0] = 0.2;
  mix->weights[1] = 0.5;
  mix->weights[2] = 0.3;

  printf("%f\n", mixture_pdf(mix, 0));

}

