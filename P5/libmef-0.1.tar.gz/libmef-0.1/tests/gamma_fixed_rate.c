#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sf_psi.h>

#include <mef.h>

double inv_psi(double psi);

int fequal(double x, double y, double eps) {
  return fabs( (x - y) / y ) < eps;
}

double eps = 1e-300;

int main(int argc, char **argv) {
  GammaFixedRate_family ef = GammaFixedRate(2.);

  /* Checking name */

  assert(strcmp(ef->name, "GammaFixedRate") == 0);

  /* Checking pdf */

  double x1 = 0.1;
  double x2 = 1.;
  double x3 = 2.;

  GammaFixedRate_source lambda = GammaFixedRate_create_source(ef, 1.);
  double y1 = ef->pdf(ef, x1, (param)lambda);
  double y2 = ef->pdf(ef, x2, (param)lambda);
  double y3 = ef->pdf(ef, x3, (param)lambda);

  double yy1 = gsl_ran_gamma_pdf(x1, lambda->shape, 1/ef->rate);
  double yy2 = gsl_ran_gamma_pdf(x2, lambda->shape, 1/ef->rate);
  double yy3 = gsl_ran_gamma_pdf(x3, lambda->shape, 1/ef->rate);

  assert(fequal(y1, yy1, eps));
  assert(fequal(y2, yy2, eps));
  assert(fequal(y3, yy3, eps));

  /* Checking psi inverse */

  double x4   = 17.;
  double psi1 = gsl_sf_psi(x4);
  double xx4  = GammaFixedRate_inv_psi(psi1);
  assert(fequal(x4, xx4, 1e-10));

  /* Checking conversion functions */

  GammaFixedRate_source      lambda1 = GammaFixedRate_create_source(ef, 2.);
  GammaFixedRate_source      lambda2 = ef->new_param(ef, SOURCE);
  GammaFixedRate_source      lambda3 = ef->new_param(ef, SOURCE);
  GammaFixedRate_natural     theta1  = ef->new_param(ef, NATURAL);
  GammaFixedRate_natural     theta2  = ef->new_param(ef, NATURAL);
  GammaFixedRate_expectation eta1    = ef->new_param(ef, EXPECTATION);
  GammaFixedRate_expectation eta2    = ef->new_param(ef, EXPECTATION);

  ef->lambda2theta(ef, (param)lambda1, (param)theta1);
  ef->theta2lambda(ef, (param)theta1 , (param)lambda2);
  assert(fequal(lambda1->shape, lambda2->shape, eps));

  ef->lambda2eta(ef, (param)lambda1, (param)eta1);
  ef->eta2lambda(ef, (param)eta1   , (param)lambda3);
  /* Lesser precision due to inv_psi */
  assert(fequal(lambda1->shape, lambda3->shape, 1e10));

  ef->lambda2theta(ef, (param)lambda1, (param)theta2);
  ef->theta2eta   (ef, (param)theta2 , (param)eta2);
  ef->eta2theta   (ef, (param)eta2   , (param)theta2);
  /* Lesser precision due to inv_psi */
  assert(fequal(theta1->theta1, theta2->theta1, 1e10));

  /* Checking maximum likelihood estimator */
  const gsl_rng_type * T;
  gsl_rng * r;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);
  int n2 = 10000000;
  GammaFixedRate_source lambda4 = GammaFixedRate_create_source(ef, 2.);
  double *data = malloc(n2 * sizeof(double));
  char   *mask = malloc(n2 * sizeof(char));
  for (unsigned int i = 0; i < n2; i++) {
    mask[i] = 1;
    data[i] = ef->rand(ef, (param)lambda4, r);
  }

  GammaFixedRate_family      ef2     = GammaFixedRate(2.);
  GammaFixedRate_expectation eta3    = ef2->new_param(ef2, EXPECTATION);
  GammaFixedRate_source      lambda5 = ef2->new_param(ef2, SOURCE);
  ef2->mle(ef2, n2, data, mask, (param)eta3);
  GammaFixedRate_estimate_beta(ef2, (param)eta3, n2, data, mask);
  ef2->eta2lambda(ef2, (param)eta3, (param)lambda5);
  assert(fequal(ef->rate      , ef2->rate     , 0.001));
  assert(fequal(lambda4->shape, lambda5->shape, 0.001));

  GammaFixedRate_family ef3     = GammaFixedRate(4.);
  GammaFixedRate_source lambda6 = GammaFixedRate_create_source(ef2, 2.);
  GammaFixedRate_estimate_beta(ef3, (param)lambda6, n2, data, mask);
  assert(fequal(ef->rate, ef3->rate, 0.001));
}
