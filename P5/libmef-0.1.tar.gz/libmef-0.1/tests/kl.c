#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#include <mef.h>

int fequal(double x, double y, double eps) {
  return fabs(x - y) / fabs(x) < eps;
}

/* Good precision for comparison with double printed with %f */
double eps = 0.000001;

int main(int argc, char **argv) {
  const gsl_rng_type * T;
  gsl_rng * r;
  gsl_rng_env_setup();
  T = gsl_rng_default;
  r = gsl_rng_alloc(T);

  unsigned int n = 3;

  mixture mix1 = mixture_create(n);
  Gaussian_family ef1 = Gaussian();
  mix1->ef[0] = (family)ef1;
  mix1->ef[1] = (family)ef1;
  mix1->ef[2] = (family)ef1;
  param lambda10 = (param)Gaussian_create_source(ef1,   0., 9.);
  param lambda11 = (param)Gaussian_create_source(ef1, -10., 3.);
  param lambda12 = (param)Gaussian_create_source(ef1,   5., 5.);
  mix1->params[0] = lambda10;
  mix1->params[1] = lambda11;
  mix1->params[2] = lambda12;
  mix1->weights[0] = 0.2;
  mix1->weights[1] = 0.5;
  mix1->weights[2] = 0.3;

  mixture mix2 = mixture_create(n);
  Gaussian_family ef2 = Gaussian();
  mix2->ef[0] = (family)ef2;
  mix2->ef[1] = (family)ef2;
  mix2->ef[2] = (family)ef2;
  param lambda20 = (param)Gaussian_create_source(ef2,   0., 9.);
  param lambda21 = (param)Gaussian_create_source(ef2, -10., 3.);
  param lambda22 = (param)Gaussian_create_source(ef2,   5., 5.);
  mix2->params[0] = lambda20;
  mix2->params[1] = lambda21;
  mix2->params[2] = lambda22;
  mix2->weights[0] = 0.2;
  mix2->weights[1] = 0.5;
  mix2->weights[2] = 0.3;

  mixture mix3 = mixture_create(n);
  Gaussian_family ef3 = Gaussian();
  mix3->ef[0] = (family)ef3;
  mix3->ef[1] = (family)ef3;
  mix3->ef[2] = (family)ef3;
  param lambda30 = (param)Gaussian_create_source(ef3,   5., 5.);
  param lambda31 = (param)Gaussian_create_source(ef3,   0., 9.);
  param lambda32 = (param)Gaussian_create_source(ef3, -10., 3.);
  mix3->params[0] = lambda30;
  mix3->params[1] = lambda31;
  mix3->params[2] = lambda32;
  mix3->weights[0] = 0.3;
  mix3->weights[1] = 0.2;
  mix3->weights[2] = 0.5;

  mixture mix4 = mixture_create(n);
  Gaussian_family ef4 = Gaussian();
  mix4->ef[0] = (family)ef4;
  mix4->ef[1] = (family)ef4;
  mix4->ef[2] = (family)ef4;
  param lambda40 = (param)Gaussian_create_source(ef4,   0., 9.);
  param lambda41 = (param)Gaussian_create_source(ef4, -10., 3.);
  param lambda42 = (param)Gaussian_create_source(ef4,   5., 5.);
  mix4->params[0] = lambda40;
  mix4->params[1] = lambda41;
  mix4->params[2] = lambda42;
  mix4->weights[0] = 0.1;
  mix4->weights[1] = 0.6;
  mix4->weights[2] = 0.3;

  mixture mix5 = mixture_create(n);
  Gaussian_family ef5 = Gaussian();
  mix5->ef[0] = (family)ef5;
  mix5->ef[1] = (family)ef5;
  mix5->ef[2] = (family)ef5;
  param lambda50 = (param)Gaussian_create_source(ef5, -10., 4.);
  param lambda51 = (param)Gaussian_create_source(ef5,  10., 1.);
  param lambda52 = (param)Gaussian_create_source(ef5,   5., 10.);
  mix5->params[0] = lambda50;
  mix5->params[1] = lambda51;
  mix5->params[2] = lambda52;
  mix5->weights[0] = 0.1;
  mix5->weights[1] = 0.6;
  mix5->weights[2] = 0.3;

  mixture mix6 = mixture_create(n);
  mix6->ef[0] = (family)ef1;
  mix6->ef[1] = (family)ef1;
  mix6->ef[2] = (family)ef1;
  param lambda60 = (param)Gaussian_create_source(ef1,   0., 9.);
  param lambda61 = (param)Gaussian_create_source(ef1, -10., 3.);
  param lambda62 = (param)Gaussian_create_source(ef1,   5., 5.);
  mix6->params[0] = lambda60;
  mix6->params[1] = lambda61;
  mix6->params[2] = lambda62;
  mix6->weights[0] = 0.2;
  mix6->weights[1] = 0.5;
  mix6->weights[2] = 0.3;

  mixture mix7 = mixture_create(n);
  mix7->ef[0] = (family)ef1;
  mix7->ef[1] = (family)ef1;
  mix7->ef[2] = (family)ef1;
  param lambda70 = (param)Gaussian_create_source(ef1,   5., 5.);
  param lambda71 = (param)Gaussian_create_source(ef1,   0., 9.);
  param lambda72 = (param)Gaussian_create_source(ef1, -10., 3.);
  mix7->params[0] = lambda70;
  mix7->params[1] = lambda71;
  mix7->params[2] = lambda72;
  mix7->weights[0] = 0.3;
  mix7->weights[1] = 0.2;
  mix7->weights[2] = 0.5;

  mixture mix8 = mixture_create(n);
  mix8->ef[0] = (family)ef1;
  mix8->ef[1] = (family)ef1;
  mix8->ef[2] = (family)ef1;
  param lambda80 = (param)Gaussian_create_source(ef1,   0., 9.);
  param lambda81 = (param)Gaussian_create_source(ef1, -10., 3.);
  param lambda82 = (param)Gaussian_create_source(ef1,   5., 5.);
  mix8->params[0] = lambda80;
  mix8->params[1] = lambda81;
  mix8->params[2] = lambda82;
  mix8->weights[0] = 0.1;
  mix8->weights[1] = 0.6;
  mix8->weights[2] = 0.3;

  mixture mix9 = mixture_create(n);
  mix9->ef[0] = (family)ef1;
  mix9->ef[1] = (family)ef1;
  mix9->ef[2] = (family)ef1;
  param lambda90 = (param)Gaussian_create_source(ef1, -10., 4.);
  param lambda91 = (param)Gaussian_create_source(ef1,  10., 1.);
  param lambda92 = (param)Gaussian_create_source(ef1,   5., 10.);
  mix9->params[0] = lambda90;
  mix9->params[1] = lambda91;
  mix9->params[2] = lambda92;
  mix9->weights[0] = 0.1;
  mix9->weights[1] = 0.6;
  mix9->weights[2] = 0.3;

  double d1 = kl_mc(mix1, mix2, 100000, r);
  printf("kl_mc(mix1, mix2) = %f\n", d1);
  assert(d1 == 0.); /* exactly equals to 0*/

  double d2 = kl_mc(mix1, mix3, 100000, r);
  printf("kl_mc(mix1, mix3) = %f\n", d2);
  assert(d2 == 0.); /* exactly equals to 0*/

  double d3 = kl_mc(mix1, mix4, 100000, r);
  printf("kl_mc(mix1, mix4) = %f\n", d3);
  assert(fequal(d3, 0.031, 0.1)); /* just for non-regression */

  double d4 = kl_mc(mix1, mix4, 100000, r);
  printf("kl_mc(mix1, mix4) = %f\n", d4);
  assert(fequal(d4, d3, 0.1));

  double d5 = kl_mc(mix1, mix5, 100000, r);
  printf("kl_mc(mix1, mix5) = %f\n", d5);
  assert(fequal(d5, 1.09, 0.1)); /* just for non-regression */

  double d6 = kl_var(mix1, mix6);
  printf("kl_var(mix1, mix6) = %f\n", d6);
  assert(d6 == 0.); /* exactly equals to 0*/

  double d7 = kl_var(mix1, mix7);
  printf("kl_var(mix1, mix7) = %f\n", d7);
  assert(d6 == 0.); /* exactly equals to 0*/

  double d8 = kl_var(mix1, mix8);
  printf("kl_var(mix1, mix8) = %f\n", d8);
  assert(fequal(d8, 0.049, 0.1)); /* just for non-regression */

  double d9 = kl_var(mix1, mix9);
  printf("kl_var(mix1, mix9) = %f\n", d9);
  assert(fequal(d9, 1.08, 0.1)); /* just for non-regression */

}
