#ifndef MIXTURE_H
#define MIXTURE_H

#include <gsl/gsl_rng.h>

struct mixture {
  unsigned int size;
  double      *weights;
  family      *ef;
  param       *params;
};
typedef struct mixture* mixture;

mixture mixture_create(unsigned int size);
double  mixture_loglikelihood(mixture mixture, unsigned int n, double *data);
double  mixture_complete_loglikelihood(mixture mixture, unsigned int n, double *data, char *origin);
double  mixture_pdf(mixture mixture, double x);
double  mixture_rand(mixture mixture, gsl_rng *rng);
void    mixture_fprint(FILE* stream, mixture mixture);

#endif

