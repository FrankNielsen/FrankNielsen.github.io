#ifndef KMEANS_H
#define KMEANS_H

#include <gsl/gsl_rng.h>
#include <gsl/gsl_matrix.h>

struct kmeans {
  unsigned int    maxiter;
  double          treshold;
  double          error;
  unsigned int    iter;
  double        (*dist    )(gsl_vector *x, gsl_vector *y);
  void          (*centroid)(gsl_matrix *data, char *mask, gsl_vector *target);
  char            verbose;

  unsigned int   *affectation;
  unsigned int   *counts;
  char           *mask;
  double         *weights;
  gsl_matrix     *centroids;

  unsigned int    k;
  double         *data;
  unsigned int    n;
  unsigned int    dim;
  double          old_error;
  int             has_changed;
};
typedef struct kmeans* kmeans;

kmeans kmeans_create(unsigned int  k,
                     double       *data,
                     unsigned int  n,
                     unsigned int  dim
                     );

void kmeans_initialize_random(kmeans kmeans, gsl_rng *rng);

void kmeans_run(kmeans kmeans);

void kmeans_destroy(kmeans kmeans);

#endif
