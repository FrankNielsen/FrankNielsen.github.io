#ifndef MEF_H
#define MEF_H

char* version();

#include "param.h"
#include "family.h"

/* Stringification of a #define symbol */
#define __S2(s) #s
#define __S(s)  __S2(s)

/* Concatenation of two identifiers, even if one of them have been
   #defined */
#define __C2(a,b) a##b
#define __C(a,b)  __C2(a,b)

#define U(name)   __C(NAME, __C(_, name))

#undef NAME
#include "families/gaussian.h"
#undef NAME
#include "families/generalized_gaussian.h"
#undef NAME
#include "families/gamma_fixed_rate.h"
#undef NAME

#undef family

#include "bregman.h"
#include "mixture.h"
#include "kl.h"
#include "kmeans.h"
#include "kmle.h"
#include "em.h"
#include "kmlegg.h"
#include "kmlegamma.h"
#include "emgamma.h"

#endif

