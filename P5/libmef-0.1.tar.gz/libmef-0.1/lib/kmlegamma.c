#include <stdlib.h>
#include <assert.h>

#include "param.h"
#include "family.h"
#include "mixture.h"

#include "families/gamma_fixed_rate.h"
#undef family

#include "kmlegamma.h"

#include <math.h>
#include <gsl/gsl_matrix.h>

kmlegamma kmlegamma_create(unsigned int k,
                 double      *data,
                 unsigned int n,
                 unsigned int dim
                 ) {
  assert(k < n);

  kmlegamma kmlegamma = malloc(sizeof(struct kmlegamma));
  kmlegamma->k           = k;
  kmlegamma->data        = data;
  kmlegamma->n           = n;
  kmlegamma->dim         = dim;
  kmlegamma->has_changed = 1;

  kmlegamma->affectation = malloc(n * sizeof(unsigned int));
  kmlegamma->counts      = malloc(k * sizeof(unsigned int));
  kmlegamma->mask        = malloc(n * sizeof(char));

  kmlegamma->mixture     = mixture_create(k);
  kmlegamma->weights     = kmlegamma->mixture->weights;
  kmlegamma->components  = kmlegamma->mixture->params;
  kmlegamma->ef          = kmlegamma->mixture->ef;

  kmlegamma->treshold    = 1e-4;
  kmlegamma->maxiter1    = 100;
  kmlegamma->maxiter2    = 0;
  kmlegamma->iter1       = 0;
  kmlegamma->iter2       = 0;

  return kmlegamma;
}

void kmlegamma_initialize_from_clustering(kmlegamma kmlegamma, double *weights, unsigned int *affectation) {
  for (unsigned int i=0; i<kmlegamma->k; i++) {
    for (unsigned int j=0; j<kmlegamma->n; j++) {
      if (affectation[j] == i)
        kmlegamma->mask[j] = 1;
      else
        kmlegamma->mask[j] = 0;
    }

    family ef = (family)GammaFixedRate(1.);

    kmlegamma->mixture->ef[i] = ef;
    kmlegamma->components[i]  = ef->new_param(ef, NATURAL);

    param eta = ef->new_param(ef, EXPECTATION);
    ef->mle(ef, kmlegamma->n, kmlegamma->data, kmlegamma->mask, eta);
    ef->eta2theta(ef, eta, kmlegamma->components[i]);

    kmlegamma->weights[i] = weights[i];

    GammaFixedRate_estimate_beta((GammaFixedRate_family)ef, kmlegamma->components[i], kmlegamma->n, kmlegamma->data, kmlegamma->mask);
  }
}

void kmlegamma_assignment(kmlegamma kmlegamma) {
  gsl_matrix_view data = gsl_matrix_view_array(kmlegamma->data,
                                                kmlegamma->n, kmlegamma->dim);
  for (unsigned int i=0; i<kmlegamma->n; i++) {
    double x = data.matrix.data[i * data.matrix.tda + 0];
    param c = kmlegamma->components[0];

    unsigned int best_index = 0;
    double       best_dist  = - log(kmlegamma->weights[0] * kmlegamma->ef[0]->pdf(kmlegamma->ef[0], x, c));
    double       dist;

    for (unsigned int j=0; j<kmlegamma->k; j++) {
      if (! kmlegamma->weights[j]) {
        continue;
      }

      c    = kmlegamma->components[j];
      dist = - log(kmlegamma->weights[j] * kmlegamma->ef[j]->pdf(kmlegamma->ef[j], x, c));

      if (dist < best_dist) {
        best_index = j;
        best_dist  = dist;
      }
    }

    unsigned int current_index = kmlegamma->affectation[i];
    if (best_index != current_index) {
      kmlegamma->has_changed    = 1;
      kmlegamma->affectation[i] = best_index;
    }
  }

  for(unsigned int i=0; i<kmlegamma->k; i++) {
    kmlegamma->counts[i] = 0;
  }

  for(unsigned int i=0; i<kmlegamma->n; i++) {
    kmlegamma->counts[kmlegamma->affectation[i]]++;
  }
}

void kmlegamma_update_parameters(kmlegamma kmlegamma) {
  for (unsigned int i=0; i<kmlegamma->k; i++) {
    if (! kmlegamma->counts[i]) {
      continue;
    }

    for (unsigned int j=0; j<kmlegamma->n; j++) {
      if (kmlegamma->affectation[j] == i)
        kmlegamma->mask[j] = 1;
      else
        kmlegamma->mask[j] = 0;
    }

    param eta = kmlegamma->ef[i]->new_param(kmlegamma->ef[i], EXPECTATION);
    kmlegamma->ef[i]->mle(kmlegamma->ef[i], kmlegamma->n, kmlegamma->data, kmlegamma->mask, eta);
    kmlegamma->ef[i]->eta2theta(kmlegamma->ef[i], eta, kmlegamma->components[i]);

    param lambda = kmlegamma->ef[i]->new_param(kmlegamma->ef[i], SOURCE);
    kmlegamma->ef[i]->theta2lambda(kmlegamma->ef[i], kmlegamma->components[i], lambda);
  }
}

void kmlegamma_update_weights(kmlegamma kmlegamma) {
  for(unsigned int i=0; i<kmlegamma->k; i++) {
    if (! kmlegamma->counts[i]) {
      kmlegamma->weights[i] = 0;
      continue;
    }
    double w = (double)kmlegamma->counts[i] / (double)kmlegamma->n;
    kmlegamma->weights[i] = w;
  }
}

void kmlegamma_choose_families(kmlegamma kmlegamma) {
  for(unsigned int i=0; i<kmlegamma->k; i++) {
    if (! kmlegamma->counts[i]) {
      continue;
    }

    family ef = kmlegamma->ef[i];

    for (unsigned int j=0; j<kmlegamma->n; j++) {
      if (kmlegamma->affectation[j] == i)
        kmlegamma->mask[j] = 1;
      else
        kmlegamma->mask[j] = 0;
    }

    GammaFixedRate_estimate_beta((GammaFixedRate_family)ef, kmlegamma->components[i], kmlegamma->n, kmlegamma->data, kmlegamma->mask);
  }
}

void kmlegamma_run(kmlegamma kmlegamma) {
  double old_ll = 0;
  kmlegamma->ll = mixture_loglikelihood(kmlegamma->mixture, kmlegamma->n, kmlegamma->data);

  while (1) {
    if (kmlegamma->maxiter1 > 0 && kmlegamma->iter1 >= kmlegamma->maxiter1)
      break;

    if (kmlegamma->treshold > 0 && fabs((old_ll - kmlegamma->ll) / old_ll) < kmlegamma->treshold)
      break;

    old_ll = kmlegamma->ll;
    kmlegamma_step(kmlegamma);
  }

  free(kmlegamma->counts);
  free(kmlegamma->mask);
}

void kmlegamma_step(kmlegamma kmlegamma) {
  kmlegamma->has_changed = 1;
  kmlegamma->iter2 = 0;
  while (kmlegamma->has_changed) {
    if (kmlegamma->maxiter2 > 0 && kmlegamma->iter2 >= kmlegamma->maxiter2)
      break;

    kmlegamma->has_changed = 0;

    kmlegamma_assignment(kmlegamma);
    kmlegamma_update_parameters(kmlegamma);

    kmlegamma->iter2++;
  }
  kmlegamma_choose_families(kmlegamma);
  kmlegamma_update_weights(kmlegamma);

  kmlegamma->ll = mixture_loglikelihood(kmlegamma->mixture, kmlegamma->n, kmlegamma->data);

  kmlegamma->iter1++;
}

void kmlegamma_destroy(kmlegamma kmlegamma) {
}

