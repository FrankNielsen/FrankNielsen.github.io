#ifndef KL_H
#define KL_H

#include <gsl/gsl_randist.h>

#include "mixture.h"

double kl_mc(mixture mix1, mixture mix2, unsigned int count, gsl_rng *rng);
double kl_var(mixture mix1, mixture mix2);

#endif
