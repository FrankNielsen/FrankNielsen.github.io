#ifndef KMLEGG_H
#define KMLEGG_H

struct kmlegg {
  unsigned int    maxiter1;
  unsigned int    maxiter2;
  double          treshold;
  double          error;
  unsigned int    iter1;
  unsigned int    iter2;

  unsigned int   *affectation;
  unsigned int   *counts;
  char           *mask;
  mixture         mixture;
  double         *weights;
  family         *ef;
  param          *components;

  unsigned int    k;
  double         *data;
  unsigned int    n;
  unsigned int    dim;
  double          old_error;
  int             has_changed;
};
typedef struct kmlegg* kmlegg;

kmlegg kmlegg_create(unsigned int k,
                 double      *data,
                 unsigned int n,
                 unsigned int dim
                 );

void kmlegg_initialize_from_clustering(kmlegg kmlegg, double *weights, unsigned int *affectation);

void kmlegg_run(kmlegg kmlegg);
void kmlegg_step(kmlegg kmlegg);

void kmlegg_destroy(kmlegg kmlegg);
              
#endif
