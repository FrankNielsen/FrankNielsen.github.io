#ifndef FAMILY_H
#define FAMILY_H

#include <stdio.h>
#include <gsl/gsl_rng.h>

#define CHECK_EF(fam, var) assert((void*)var->ef == (void*)fam)
#define CHECK_TYPE(var, t) assert(var->type == t)

typedef struct family* family;

struct family {
  char*    name;
  double  (*pdf         )(family ef, double x, param param);
  double* (*iter_pdf    )(family ef, unsigned int n, double *in, param lambda, double *out);
  void    (*lambda2theta)(family ef, param lambda, param theta );
  void    (*theta2lambda)(family ef, param theta , param lambda);
  void    (*lambda2eta  )(family ef, param lambda, param eta   );
  void    (*eta2lambda  )(family ef, param eta   , param lambda);
  void    (*theta2eta   )(family ef, param theta , param eta);
  void    (*eta2theta   )(family ef, param eta   , param theta);
  void    (*fprint      )(FILE* stream, family ef, param param); 
  double  (*F           )(family ef, param theta0);
  void    (*gradF       )(family ef, param theta0, param eta0);
  double  (*G           )(family ef, param theta0);
  void    (*gradG       )(family ef, param theta0, param eta0);
  param   (*mle         )(family ef, unsigned int n, double *data, char *mask, param eta0);
  void*   (*new_param   )(family ef, enum type type);
  void    (*t           )(family ef, double x, param param);
  param   (*add         )(family ef, param p, param q, param dest);
  double  (*scalar      )(family ef, param p, param q);
  param   (*minus       )(family ef, param p, param q, param dest);
  param   (*scale       )(family ef, param p, double a, param dest);
  param   (*zero        )(family ef, param p);
  double  (*rand        )(family ef, param p, gsl_rng *rng);
  param   (*as_source)(family ef, param in);                  \
  param   (*as_natural)(family ef, param in);                 \
  param   (*as_expectation)(family ef, param in);

};

#endif

