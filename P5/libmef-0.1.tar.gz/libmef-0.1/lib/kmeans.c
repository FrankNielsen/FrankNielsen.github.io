#include <stdlib.h>
#include <assert.h>

#include "kmeans.h"

#include <gsl/gsl_randist.h>
#include <gsl/gsl_permutation.h>

/* Inspired from */
/* http://lists.gnu.org/archive/html/pspp-dev/2011-03/msg00004.html */

void print_vector(gsl_vector *v) {
  for (unsigned int i=0; i<v->size; i++)
    printf("%f ", gsl_vector_get(v, i));
  printf("\n");
}

void print_matrix(gsl_matrix *m) {
  for (unsigned int i=0; i<m->size1; i++)
    for (unsigned int j=0; j<m->size2; j++) {
      printf("%f ", gsl_matrix_get(m, i, j));
      printf("\n");
    }
}

double l2(gsl_vector *x, gsl_vector *y) {
  assert(x->size == y->size);

  double dist = 0;
  for(unsigned int i=0; i<x->size; i++) {
    double tmp = gsl_vector_get(x, i) - gsl_vector_get(y, i);
    dist += tmp * tmp;
  }

  return dist;
}

void l2_centroid(gsl_matrix *data, char *mask, gsl_vector *target) {
  unsigned int count = 0;

  for (unsigned int i=0; i<target->size; i++)
    gsl_vector_set(target, i, 0.);

  for (unsigned int i=0; i<data->size1; i++) {
    if (mask[i]) {
      gsl_vector_view x = gsl_matrix_row(data, i);
      gsl_vector_add(target, &x.vector);
      count++;
    }
  }

  gsl_vector_scale(target, 1./count);
}

kmeans kmeans_create(unsigned int  k,
                     double       *data,
                     unsigned int  n,
                     unsigned int  dim
                     ) {

  assert(k < n);

  kmeans kmeans = malloc(sizeof(struct kmeans));
  kmeans->k           = k;
  kmeans->data        = data;
  kmeans->n           = n;
  kmeans->dim         = dim;
  kmeans->has_changed = 1;

  kmeans->affectation = malloc(n * sizeof(unsigned int));
  kmeans->counts      = malloc(k * sizeof(unsigned int));
  kmeans->mask        = malloc(n * sizeof(char));
  kmeans->weights     = malloc(k * sizeof(double));
  kmeans->centroids   = gsl_matrix_alloc(k, dim);

  kmeans->treshold    = 0;
  kmeans->maxiter     = 0;
  kmeans->iter        = 0;
  kmeans->dist        = &l2;
  kmeans->centroid    = &l2_centroid;
  kmeans->verbose     = 0;

  return kmeans;
}

void kmeans_initialize_random(kmeans kmeans, gsl_rng *rng) {
  gsl_matrix_view  mview     = gsl_matrix_view_array(kmeans->data,
                                                     kmeans->n, kmeans->dim);
  gsl_matrix      *data      = &mview.matrix;
  gsl_matrix      *centroids = kmeans->centroids;

  gsl_permutation * p = gsl_permutation_alloc(kmeans->n);

  gsl_permutation_init(p);
  gsl_ran_shuffle(rng, p->data, kmeans->n, sizeof(size_t));

  for(unsigned int i=0; i<kmeans->k; i++) {
    unsigned int u = gsl_permutation_get(p, i);
    for(unsigned int j=0; j<kmeans->dim; j++) {
      gsl_matrix_set(centroids, i, j, gsl_matrix_get(data, u, j));
    }
  }

  gsl_permutation_free(p);
}

void kmeans_assignment(kmeans kmeans) {
  if (kmeans->verbose)
    printf("assignemnent\n");

  kmeans->old_error = kmeans->error;
  kmeans->error     = 0;

  for (unsigned int i=0; i<kmeans->n; i++) {
    gsl_matrix_view  data = gsl_matrix_view_array(kmeans->data,
                                                  kmeans->n, kmeans->dim);
    gsl_vector_view x = gsl_matrix_row(&data.matrix,      i);
    gsl_vector_view c = gsl_matrix_row(kmeans->centroids, 0);

    unsigned int best_index = 0;
    double       best_dist  = kmeans->dist(&x.vector, &c.vector);
    double       dist;

    for (unsigned int j=1; j<kmeans->k; j++) {
      c    = gsl_matrix_row(kmeans->centroids, j);
      dist = kmeans->dist(&x.vector, &c.vector);

      if (dist < best_dist) {
        best_index = j;
        best_dist  = dist;
      }
    }

    unsigned int current_index = kmeans->affectation[i];
    if (best_index != current_index) {
      kmeans->has_changed    = 1;
      kmeans->affectation[i] = best_index;
      kmeans->error         =+ best_dist;
    }
  }

  for(unsigned int i=0; i<kmeans->k; i++) {
    kmeans->counts[i] = 0;
  }

  for(unsigned int i=0; i<kmeans->n; i++) {
    kmeans->counts[kmeans->affectation[i]]++;
  }

}

void kmeans_update(kmeans kmeans) {
  if (kmeans->verbose)
    printf("update\n");
  gsl_matrix_view data = gsl_matrix_view_array(kmeans->data,
                                               kmeans->n, kmeans->dim);

  for (unsigned int i=0; i<kmeans->k; i++) {
    for (unsigned int j=0; j<kmeans->n; j++) {
      if (kmeans->affectation[j] == i)
        kmeans->mask[j] = 1;
      else
        kmeans->mask[j] = 0;
    }

    gsl_vector_view c = gsl_matrix_row(kmeans->centroids, i);
    kmeans->centroid(&data.matrix, kmeans->mask, &c.vector);
  }
}

void kmeans_run(kmeans kmeans) {
  while (kmeans->has_changed) {
    if (kmeans->maxiter > 0 && kmeans->iter >= kmeans->maxiter)
      break;

    if (kmeans->treshold > 0 && abs(kmeans->error - kmeans->old_error) < kmeans->treshold)
      break;

    kmeans->has_changed = 0;

    kmeans_assignment(kmeans);
    kmeans_update    (kmeans);

    kmeans->iter++;
  }

  for(unsigned int i=0; i<kmeans->k; i++) {
    double w = (double)kmeans->counts[i] / (double)kmeans->n;
    kmeans->weights[i] = w;
  }

  free(kmeans->counts);
  free(kmeans->mask);
}

void kmeans_destroy(kmeans kmeans) {
  free(kmeans->affectation);
  free(kmeans->weights);
  gsl_matrix_free(kmeans->centroids);
  free(kmeans);
}

