#include <stdlib.h>
#include <assert.h>

#include "param.h"
#include "family.h"
#include "kmle.h"

#include <math.h>
#include <gsl/gsl_matrix.h>

kmle kmle_create(family ef,
                 unsigned int k,
                 double      *data,
                 unsigned int n,
                 unsigned int dim
                 ) {
  assert(k < n);

  kmle kmle = malloc(sizeof(struct kmle));
  kmle->ef          = ef;
  kmle->k           = k;
  kmle->data        = data;
  kmle->n           = n;
  kmle->dim         = dim;
  kmle->has_changed = 1;

  kmle->affectation = malloc(n * sizeof(unsigned int));
  kmle->counts      = malloc(k * sizeof(unsigned int));
  kmle->mask        = malloc(n * sizeof(char));
  kmle->weights     = malloc(k * sizeof(double));
  kmle->components  = malloc(k * sizeof(param));

  kmle->treshold    = 0;
  kmle->maxiter1    = 0;
  kmle->maxiter2    = 0;
  kmle->iter1       = 0;
  kmle->iter2       = 0;

  for (unsigned int i=0; i<k; i++) {
    kmle->components[i] = (param)ef->new_param(ef, NATURAL);
  }

  return kmle;
}

void kmle_initialize_from_clustering(kmle kmle, double *weights, unsigned int *affectation) {
  for (unsigned int i=0; i<kmle->k; i++) {
    for (unsigned int j=0; j<kmle->n; j++) {
      if (affectation[j] == i)
        kmle->mask[j] = 1;
      else
        kmle->mask[j] = 0;
    }

    param eta = kmle->ef->new_param(kmle->ef, EXPECTATION);
    kmle->ef->mle(kmle->ef, kmle->n, kmle->data, kmle->mask, eta);
    kmle->ef->eta2theta(kmle->ef, eta, kmle->components[i]);

    kmle->weights[i] = weights[i];
  }
}

void kmle_assignment(kmle kmle) {
  gsl_matrix_view data = gsl_matrix_view_array(kmle->data,
                                                kmle->n, kmle->dim);
  for (unsigned int i=0; i<kmle->n; i++) {
    double x = data.matrix.data[i * data.matrix.tda + 0];
    param c = kmle->components[0];

    unsigned int best_index = 0;
    double       best_dist  = - log(kmle->weights[0] * kmle->ef->pdf(kmle->ef, x, c));
    double       dist;

    /* printf("  %i %f\n", best_index, best_dist); */
    for (unsigned int j=0; j<kmle->k; j++) {
      c    = kmle->components[j];
      dist = - log(kmle->weights[j] * kmle->ef->pdf(kmle->ef, x, c));

      /* kmle->ef->fprint(stdout, kmle->ef, c); */
      /* printf("= %i %i %f %f %f\n", i, j, x, dist, kmle->weights[j]); */
      if (dist < best_dist) {
        best_index = j;
        best_dist  = dist;
        /* printf("  %i %f\n", best_index, best_dist); */
      }
    }

    unsigned int current_index = kmle->affectation[i];
    if (best_index != current_index) {
      kmle->has_changed    = 1;
      kmle->affectation[i] = best_index;
    }
  }

  for(unsigned int i=0; i<kmle->k; i++) {
    kmle->counts[i] = 0;
  }

  for(unsigned int i=0; i<kmle->n; i++) {
    kmle->counts[kmle->affectation[i]]++;
  }

  /* for (unsigned int i=0; i<kmle->n; i++) { */
  /*   printf("%i %i %f\n", i, kmle->affectation[i], kmle->data[i]); */
  /* } */


  /* for(unsigned int i=0; i<kmle->k; i++) { */
  /*   printf("count[%i] = %i\n", i, kmle->counts[i]); */
  /* } */


}

void kmle_update_parameters(kmle kmle) {
  for (unsigned int i=0; i<kmle->k; i++) {
    for (unsigned int j=0; j<kmle->n; j++) {
      if (kmle->affectation[j] == i)
        kmle->mask[j] = 1;
      else
        kmle->mask[j] = 0;
    }

    param eta = kmle->ef->new_param(kmle->ef, EXPECTATION);
    kmle->ef->mle(kmle->ef, kmle->n, kmle->data, kmle->mask, eta);
    kmle->ef->eta2theta(kmle->ef, eta, kmle->components[i]);

    param lambda = kmle->ef->new_param(kmle->ef, SOURCE);
    kmle->ef->theta2lambda(kmle->ef, kmle->components[i], lambda);
    /* printf("%i ", i); */
    /* kmle->ef->fprint(stdout, kmle->ef, lambda); */
  }
}

void kmle_update_weights(kmle kmle) {
  for(unsigned int i=0; i<kmle->k; i++) {
    double w = (double)kmle->counts[i] / (double)kmle->n;
    kmle->weights[i] = w;
    /* printf("weights[%i] %f\n", i, w); */
  }

}

void kmle_run(kmle kmle) {
  while (1) {
    /* printf("========================= iter1 ===========================\n"); */

    if (kmle->maxiter1 > 0 && kmle->iter1 >= kmle->maxiter1)
      break;

    kmle->has_changed = 1;
    kmle->iter2 = 0;
    while (kmle->has_changed) {
      /* printf("------------------------- iter2 ---------------------------\n"); */

      /* printf("%i %i\n", kmle->iter1, kmle->iter2); */
      if (kmle->maxiter2 > 0 && kmle->iter2 >= kmle->maxiter2)
        break;

      kmle->has_changed = 0;

      kmle_assignment(kmle);
      kmle_update_parameters(kmle);

      kmle->iter2++;
    }
    kmle_update_weights(kmle);

    kmle->iter1++;
  }

  free(kmle->counts);
  free(kmle->mask);
}

void kmle_step(kmle kmle) {
  kmle->has_changed = 1;
  kmle->iter2 = 0;
  while (kmle->has_changed) {
    if (kmle->maxiter2 > 0 && kmle->iter2 >= kmle->maxiter2)
      break;

    kmle->has_changed = 0;

    kmle_assignment(kmle);
    kmle_update_parameters(kmle);

    kmle->iter2++;
  }
  kmle_update_weights(kmle);

  kmle->iter1++;
}

void kmle_destroy(kmle kmle) {
}

