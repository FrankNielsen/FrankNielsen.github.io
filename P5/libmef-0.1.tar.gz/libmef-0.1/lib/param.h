#ifndef PARAM_H
#define PARAM_H

enum type {
  SOURCE,
  NATURAL,
  EXPECTATION,
};

struct param {
  enum type type;
  struct family *ef;
};
typedef struct param* param;

#endif
