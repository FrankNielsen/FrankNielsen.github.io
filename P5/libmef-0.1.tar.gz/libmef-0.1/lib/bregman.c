#include "param.h"
#include "family.h"
#include "bregman.h"

#include <assert.h>

double bregman_div(family ef, param p, param q) {
  CHECK_EF(ef, p);
  CHECK_EF(ef, q);
  CHECK_TYPE(p, NATURAL);
  CHECK_TYPE(q, NATURAL);

  double dist = 0;
  dist += ef->F(ef, p);
  dist -= ef->F(ef, q);

  param diff = ef->new_param(ef, NATURAL);
  ef->minus(ef, p, q, diff);

  param tmp = ef->new_param(ef, EXPECTATION);
  ef->gradF(ef, q, tmp);

  dist -= ef->scalar(ef, diff, tmp);
  
  return dist;
}

