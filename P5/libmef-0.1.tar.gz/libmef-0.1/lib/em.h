#ifndef EM_H
#define EM_H

#include <gsl/gsl_matrix.h>

#include "mixture.h"

struct em {
  unsigned int    maxiter;
  double          treshold;
  double          error;
  unsigned int    iter;
  double          ll;

  char           *mask;
  mixture         mixture;
  double         *weights;
  param          *components;
  gsl_matrix     *posterior;

  family          ef;
  unsigned int    k;
  double         *data;
  unsigned int    n;
  unsigned int    dim;
  double          old_error;
  int             has_changed;
};
typedef struct em* em;

em em_create(family ef,
             unsigned int k,
             double      *data,
             unsigned int n,
             unsigned int dim
             );

void em_initialize_from_clustering(em em, double *weights, unsigned int *affectation);

void em_step(em em);

mixture em_run(em em);

void em_destroy(em em);

#endif
