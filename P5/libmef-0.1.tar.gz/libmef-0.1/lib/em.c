#include <stdlib.h>
#include <assert.h>

#include "param.h"
#include "family.h"
#include "em.h"

#include <math.h>
#include <gsl/gsl_matrix.h>

em em_create(family ef,
             unsigned int k,
             double      *data,
             unsigned int n,
             unsigned int dim
             ) {
  assert(k < n);

  em em = malloc(sizeof(struct em));
  em->ef         = ef;
  em->k          = k;
  em->data       = data;
  em->n          = n;
  em->dim        = dim;

  em->mask       = malloc(n * sizeof(char));

  em->mixture    = mixture_create(k);
  em->weights    = em->mixture->weights;
  em->components = em->mixture->params;

  em->posterior  = gsl_matrix_alloc(n, k);

  em->treshold   = 1e-5;
  em->maxiter    = 100;
  em->iter       = 0;

  for (int i=0; i<k; i++) {
    em->mixture->ef[i]     = ef;
    em->mixture->params[i] = (param)ef->new_param(ef, EXPECTATION);
  }

  return em;
}

void em_initialize_from_clustering(em em, double *weights, unsigned int *affectation) {
  for (unsigned int i=0; i<em->k; i++) {
    for (unsigned int j=0; j<em->n; j++) {
      if (affectation[j] == i)
        em->mask[j] = 1;
      else
        em->mask[j] = 0;
    }

    em->ef->mle(em->ef, em->n, em->data, em->mask, em->components[i]);

    em->weights[i] = weights[i];
  }
}

void em_expectation(em em) {
  double     *data       = em->data;
  family      ef         = em->ef;
  double     *weights    = em->weights;
  gsl_matrix *posterior  = em->posterior;
  param      *components = em->components;

  /* for each observation */
  for(unsigned int i=0; i<em->n; i++) {
    double sum = 0;

    /* for each cluster */
    for(unsigned int j=0; j<em->k; j++) {
      double tmp;
      tmp = weights[j] * ef->pdf(ef, data[i], components[j]);
      sum += tmp;
      gsl_matrix_set(posterior, i, j, tmp);
    }

    /* for each cluster */
    for(unsigned int j=0; j<em->k; j++) {
      double tmp;
      tmp = gsl_matrix_get(posterior, i, j);
      gsl_matrix_set(posterior, i, j, tmp / sum);
    }
  }
}

void em_maximization(em em) {
  double     *data       = em->data;
  family      ef         = em->ef;
  double     *weights    = em->weights;
  gsl_matrix *posterior  = em->posterior;
  param      *components = em->components;

  param eta = (param)ef->new_param(ef, EXPECTATION);

  /* for each cluster */
  for(unsigned int i=0; i<em->k; i++) {

    double sum = 0;
    ef->zero(ef, eta);

    /* for each observation */
    for(unsigned int j=0; j<em->n; j++) {
      double tmp = gsl_matrix_get(posterior, j, i);
      sum += tmp;

      ef->t(ef, data[j], eta);
      ef->scale(ef, eta, tmp, eta);
      ef->add(ef, components[i], eta, components[i]);
    }
    weights[i] = sum / em->n;
    ef->scale(ef, components[i], 1 / sum, components[i]);
  }
}

mixture em_run(em em) {
  double old_ll = 0;
  em->ll        = mixture_loglikelihood(em->mixture, em->n, em->data);

  while (1) {
    if (em->maxiter > 0 && em->iter >= em->maxiter)
      break;

    if (em->treshold > 0 && fabs((old_ll - em->ll) / old_ll) < em->treshold)
      break;

    old_ll = em->ll;
    em_step(em);
  }

  return em->mixture;
}

void em_step(em em) {
  em_expectation(em);
  em_maximization(em);

  em->ll = mixture_loglikelihood(em->mixture, em->n, em->data);

  em->iter++;
}

void em_destroy(em em) {
  free(em->mask);
  gsl_matrix_free(em->posterior);
  free(em);
}

