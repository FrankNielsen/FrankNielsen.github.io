#ifndef BREGMAN_H
#define BREGMAN_H

#include "family.h"

double bregman_div(family ef, param p, param q);

#endif
