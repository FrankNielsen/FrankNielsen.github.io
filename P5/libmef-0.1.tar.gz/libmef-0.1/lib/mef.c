#include <stdio.h>
#include "mef.h"

char* version() {
  return "toto";
}

