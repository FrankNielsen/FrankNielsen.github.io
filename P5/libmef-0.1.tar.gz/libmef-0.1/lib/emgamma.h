#ifndef EMGAMMA_H
#define EMGAMMA_H

#include <gsl/gsl_matrix.h>

#include "mixture.h"

struct emgamma {
  unsigned int    maxiter;
  double          treshold;
  double          error;
  unsigned int    iter;
  double          ll;

  char           *mask;
  mixture         mixture;
  double         *weights;
  family         *ef;
  param          *components;

  gsl_matrix     *posterior;

  unsigned int    k;
  double         *data;
  unsigned int    n;
  unsigned int    dim;
  double          old_error;
  int             has_changed;
};
typedef struct emgamma* emgamma;

emgamma emgamma_create(unsigned int k,
             double      *data,
             unsigned int n,
             unsigned int dim
             );

void emgamma_initialize_from_clustering(emgamma emgamma, double *weights, unsigned int *affectation);

void emgamma_step(emgamma emgamma);

mixture emgamma_run(emgamma emgamma);

void emgamma_destroy(emgamma emgamma);

#endif
