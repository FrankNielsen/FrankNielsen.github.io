#include "param.h"
#include "family.h"
#include "mixture.h"

#include <float.h>
#include <math.h>
#include <stdlib.h>

#include <gsl/gsl_randist.h>
#include <gsl/gsl_permutation.h>

mixture mixture_create(unsigned int size) {
  mixture mixture = malloc(sizeof(struct mixture));

  mixture->size    = size;
  mixture->weights = malloc(size * sizeof(double));
  mixture->ef      = malloc(size * sizeof(struct family));
  mixture->params  = malloc(size * sizeof(struct param));

  return mixture;
}

double mixture_loglikelihood(mixture mixture, unsigned int n, double *data) {
  double ll = 0;

  for(unsigned int i=0; i<n; i++) {
    ll += log(mixture_pdf(mixture, data[i]));
  }

  return ll / n;
}

double mixture_complete_loglikelihood(mixture mixture, unsigned int n, double *data, char *origin) {
  double best_ll = -DBL_MAX;
  /* printf("dbl_min %f\n", best_ll); */
  gsl_permutation * p = gsl_permutation_alloc(mixture->size);

  gsl_permutation_init(p);
  do {
    double ll = 0;
    /* printf("= %f %f\n", ll, best_ll); */
    for(unsigned int i=0; i<n; i++) {
      for(unsigned int j=0; j<mixture->size; j++) {
        if (gsl_permutation_get(p, origin[i]) == j) {
          family ef = mixture->ef[j];
          double w  = mixture->weights[j];
          param  p  = mixture->params[j];

          ll += log(w * ef->pdf(ef, data[i], p));
        }
      }
    }

    /* printf("- %f %f\n", ll, best_ll); */
    if (ll > best_ll) {
      best_ll = ll;
    }
  } while (gsl_permutation_next(p) == GSL_SUCCESS);

  return best_ll / n;
}

double mixture_pdf(mixture mixture, double x) {
  double pdf = 0;

  for(unsigned int i=0; i<mixture->size; i++) {
    family ef = mixture->ef[i];
    double w  = mixture->weights[i];
    param  p  = mixture->params[i];
    
    pdf += w * ef->pdf(ef, x, p);
  }

  return pdf;
}

double mixture_rand(mixture mixture, gsl_rng *rng) {
  double rand   = gsl_rng_uniform(rng);
  double cumsum = mixture->weights[0];

  unsigned int i = 0;
  while (rand >= cumsum && i < mixture->size) {
    i++;
    cumsum += mixture->weights[i];
  }

  family ef = mixture->ef[i];
  param  p  = mixture->params[i];

  return ef->rand(ef, p, rng);
}

void mixture_fprint(FILE* stream, mixture mixture) {
  for (unsigned int i=0; i<mixture->size; i++) {
    family ef = mixture->ef[i];
    fprintf(stream, "%f ", mixture->weights[i]);
    ef->fprint(stream, ef, mixture->params[i]);
  }
}

