#ifndef KMLEGAMMA_H
#define KMLEGAMMA_H

struct kmlegamma {
  unsigned int    maxiter1;
  unsigned int    maxiter2;
  double          treshold;
  double          error;
  unsigned int    iter1;
  unsigned int    iter2;

  unsigned int   *affectation;
  unsigned int   *counts;
  char           *mask;
  mixture         mixture;
  double         *weights;
  family         *ef;
  param          *components;

  unsigned int    k;
  double         *data;
  unsigned int    n;
  unsigned int    dim;
  double          old_error;
  int             has_changed;
  double          ll;
};
typedef struct kmlegamma* kmlegamma;

kmlegamma kmlegamma_create(unsigned int k,
                 double      *data,
                 unsigned int n,
                 unsigned int dim
                 );

void kmlegamma_initialize_from_clustering(kmlegamma kmlegamma, double *weights, unsigned int *affectation);

void kmlegamma_run(kmlegamma kmlegamma);
void kmlegamma_step(kmlegamma kmlegamma);

void kmlegamma_destroy(kmlegamma kmlegamma);
              
#endif
