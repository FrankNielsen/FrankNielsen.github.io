#include <stdlib.h>
#include <assert.h>

#include "param.h"
#include "family.h"

#include "families/gamma_fixed_rate.h"
#undef family

#include "emgamma.h"

#include <math.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_sf_psi.h>

emgamma emgamma_create(unsigned int k,
                       double      *data,
                       unsigned int n,
                       unsigned int dim
                       ) {
  assert(k < n);

  emgamma emgamma = malloc(sizeof(struct emgamma));
  emgamma->k          = k;
  emgamma->data       = data;
  emgamma->n          = n;
  emgamma->dim        = dim;

  emgamma->mask       = malloc(n * sizeof(char));

  emgamma->mixture     = mixture_create(k);
  emgamma->weights     = emgamma->mixture->weights;
  emgamma->components  = emgamma->mixture->params;
  emgamma->ef          = emgamma->mixture->ef;

  emgamma->posterior  = gsl_matrix_alloc(n, k);

  emgamma->treshold   = 1e-5;
  emgamma->maxiter    = 100;
  emgamma->iter       = 0;

  return emgamma;
}

void emgamma_initialize_from_clustering(emgamma emgamma, double *weights, unsigned int *affectation) {
  for (unsigned int i=0; i<emgamma->k; i++) {
    for (unsigned int j=0; j<emgamma->n; j++) {
      if (affectation[j] == i)
        emgamma->mask[j] = 1;
      else
        emgamma->mask[j] = 0;
    }

    family ef = (family)GammaFixedRate(1.);

    emgamma->mixture->ef[i] = ef;
    emgamma->components[i]  = ef->new_param(ef, SOURCE);

    param eta = ef->new_param(ef, EXPECTATION);
    ef->mle(ef, emgamma->n, emgamma->data, emgamma->mask, eta);
    ef->eta2lambda(ef, eta, emgamma->components[i]);

    emgamma->weights[i] = weights[i];

    GammaFixedRate_estimate_beta((GammaFixedRate_family)ef, emgamma->components[i], emgamma->n, emgamma->data, emgamma->mask);
  }
}

void emgamma_expectation(emgamma emgamma) {
  double     *data       = emgamma->data;
  double     *weights    = emgamma->weights;
  gsl_matrix *posterior  = emgamma->posterior;
  param      *components = emgamma->components;

  /* for each observation */
  for(unsigned int i=0; i<emgamma->n; i++) {
    double sum = 0;

    /* for each cluster */
    for(unsigned int j=0; j<emgamma->k; j++) {
      family ef = emgamma->ef[j];

      double tmp;
      tmp = weights[j] * ef->pdf(ef, data[i], components[j]);
      sum += tmp;
      gsl_matrix_set(posterior, i, j, tmp);
    }

    /* for each cluster */
    for(unsigned int j=0; j<emgamma->k; j++) {
      double tmp;
      tmp = gsl_matrix_get(posterior, i, j);
      gsl_matrix_set(posterior, i, j, tmp / sum);
    }
  }
}

void emgamma_maximization(emgamma emgamma) {
  double     *data       = emgamma->data;
  double     *weights    = emgamma->weights;
  gsl_matrix *posterior  = emgamma->posterior;
  param      *components = emgamma->components;

  /* for each cluster */
  for(unsigned int i=0; i<emgamma->k; i++) {
    GammaFixedRate_family ef     = (GammaFixedRate_family)emgamma->ef[i];
    GammaFixedRate_source lambda = (GammaFixedRate_source)components[i];

    double alpha = lambda->shape;
    double beta  = ef->rate;

    double psi_alpha = gsl_sf_psi(alpha);
    double log_beta  = log(beta);

    double sum_p   = 0;
    double sum_p_x = 0;
    double G       = 0;

    /* for each observation */
    for(unsigned int j=0; j<emgamma->n; j++) {
      double p = gsl_matrix_get(posterior, j, i);
      double x = data[j];
      sum_p   += p;
      sum_p_x += x * p;
      G       += (log(x) + log_beta - psi_alpha) * p;
    }
    G /= emgamma->n;

    weights[i]    = sum_p / emgamma->n;
    ef->rate      = alpha * sum_p / sum_p_x;
    lambda->shape = alpha + G / (emgamma->iter + 1);
  }
}

mixture emgamma_run(emgamma emgamma) {
  double old_ll = 0;
  emgamma->ll        = mixture_loglikelihood(emgamma->mixture, emgamma->n, emgamma->data);

  while (1) {
    if (emgamma->maxiter > 0 && emgamma->iter >= emgamma->maxiter)
      break;

    if (emgamma->treshold > 0 && fabs((old_ll - emgamma->ll) / old_ll) < emgamma->treshold)
      break;

    old_ll = emgamma->ll;
    emgamma_step(emgamma);
  }

  return emgamma->mixture;
}

void emgamma_step(emgamma emgamma) {
  emgamma_expectation(emgamma);
  emgamma_maximization(emgamma);

  emgamma->ll = mixture_loglikelihood(emgamma->mixture, emgamma->n, emgamma->data);

  emgamma->iter++;
}

void emgamma_destroy(emgamma emgamma) {
  free(emgamma->mask);
  gsl_matrix_free(emgamma->posterior);
  free(emgamma);
}

