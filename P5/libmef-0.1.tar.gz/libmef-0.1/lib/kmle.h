#ifndef KMLE_H
#define KMLE_H

struct kmle {
  unsigned int    maxiter1;
  unsigned int    maxiter2;
  double          treshold;
  double          error;
  unsigned int    iter1;
  unsigned int    iter2;

  unsigned int   *affectation;
  unsigned int   *counts;
  char           *mask;
  double         *weights;
  param          *components;

  family          ef;
  unsigned int    k;
  double         *data;
  unsigned int    n;
  unsigned int    dim;
  double          old_error;
  int             has_changed;
};
typedef struct kmle* kmle;

kmle kmle_create(family ef,
                 unsigned int k,
                 double      *data,
                 unsigned int n,
                 unsigned int dim
                 );

void kmle_initialize_from_clustering(kmle kmle, double *weights, unsigned int *affectation);

void kmle_run(kmle kmle);
void kmle_step(kmle kmle);

void kmle_destroy(kmle kmle);
              
#endif
