#include "dynamic.c"

/* Iterator over the pdf function */
/* Keeping it in the header allows to inline pdf calls if necessary */
double *U(iter_pdf)(family ef, unsigned int n, double *in, struct param *lambda, double *out) {
  unsigned int i;
  for(i=0; i<n; i++) {
    out[i] = U(pdf)(ef, in[i], lambda);
  }
  return out;
}

void U(theta2eta)(family ef, param theta, param eta) {
  U(gradF)(ef, theta, eta);
}
void U(eta2theta)(family ef, param eta, param theta) {
  U(gradG)(ef, eta, theta);
}

param U(mle)(family ef, unsigned int n, double *data, char *mask, param eta) {
  CHECK_EF(ef, eta);
  CHECK_TYPE(eta, EXPECTATION);

  unsigned int count = 0;

  for (unsigned int i=0; i<n; i++) {
    if (mask[i]) {
      param t = U(new_param)(ef, EXPECTATION);
      U(t)(ef, data[i], t);
      U(add)(ef, eta, t, eta);
      count++;
    }
  }

  U(scale)(ef, eta, 1./count, eta);

  return eta;
}

void* U(new_param)(family ef, enum type type) {
  param p = NULL;
  switch (type) {
  case SOURCE:
    p = malloc(sizeof(struct source));
    break;
  case NATURAL:
    p = malloc(sizeof(struct natural));
    break;
  case EXPECTATION:
    p = malloc(sizeof(struct expectation));
    break;
  }
  
  p->type = type;
  p->ef   = (void*)ef; /* type param only accepts real family, not
                          XXX_family (in which the family in the
                          prototype is translated */

  return p;
}

param U(add)(family ef, param p, param q, param dest) {
  CHECK_EF(ef, p);
  CHECK_EF(ef, q);
  assert(p->type == q->type);

  switch (p->type) {
  case SOURCE:
    U(dynamic_add)(U(source_descr), U(source_len), p, q, dest);
    break;
  case NATURAL:
    U(dynamic_add)(U(natural_descr), U(natural_len), p, q, dest);
    break;
  case EXPECTATION:
    U(dynamic_add)(U(expectation_descr), U(expectation_len), p, q, dest);
    break;
  }

  return dest;
}

double U(scalar)(family ef, param p, param q) {
  CHECK_EF(ef, p);
  CHECK_EF(ef, q);

  return U(dynamic_scalar)(U(natural_descr), U(natural_len), p, q);
}

param U(minus)(family ef, param p, param q, param dest) {
  CHECK_EF(ef, p);
  CHECK_EF(ef, q);
  assert(p->type == q->type);

  switch (p->type) {
  case SOURCE:
    U(dynamic_minus)(U(source_descr), U(source_len), p, q, dest);
    break;
  case NATURAL:
    U(dynamic_minus)(U(natural_descr), U(natural_len), p, q, dest);
    break;
  case EXPECTATION:
    U(dynamic_minus)(U(expectation_descr), U(expectation_len), p, q, dest);
    break;
  }

  return dest;
}

param U(scale)(family ef, param p, double a, param dest) {
  CHECK_EF(ef, p);

  switch (p->type) {
  case SOURCE:
    U(dynamic_scale)(U(source_descr), U(source_len), p, a, dest);
    break;
  case NATURAL:
    U(dynamic_scale)(U(natural_descr), U(natural_len), p, a, dest);
    break;
  case EXPECTATION:
    U(dynamic_scale)(U(expectation_descr), U(expectation_len), p, a, dest);
    break;
  }

  return dest;
}

param U(zero)(family ef, param p) {
  CHECK_EF(ef, p);

  switch (p->type) {
  case SOURCE:
    U(dynamic_zero)(U(source_descr), U(source_len), p);
    break;
  case NATURAL:
    U(dynamic_zero)(U(natural_descr), U(natural_len), p);
    break;
  case EXPECTATION:
    U(dynamic_zero)(U(expectation_descr), U(expectation_len), p);
    break;
  }

  return p;
}

param U(as_source)(family ef, param in) {
  source lambda;

  switch (in->type) {
  case SOURCE:
    lambda = (source)in;
    break;
  case NATURAL:
    lambda = U(new_param)(ef, SOURCE);
    ef->theta2lambda(ef, in, (param)lambda);
    break;
  case EXPECTATION:
    lambda = U(new_param)(ef, SOURCE);
    ef->eta2lambda(ef, in, (param)lambda);
    break;
  default:
    assert(0);
  }

  return (param)lambda;
}

param U(as_natural)(family ef, param in) {
  natural theta;

  switch (in->type) {
  case SOURCE:
    theta = U(new_param)(ef, NATURAL);
    ef->lambda2theta(ef, in, (param)theta);
    break;
  case NATURAL:
    theta = (natural)in;
    break;
  case EXPECTATION:
    theta = U(new_param)(ef, NATURAL);
    ef->eta2theta(ef, in, (param)theta);
    break;
  default:
    assert(0);
  }

  return (param)theta;
}

param U(as_expectation)(family ef, param in) {
  expectation eta;

  switch (in->type) {
  case SOURCE:
    eta = U(new_param)(ef, EXPECTATION);
    ef->lambda2eta(ef, in, (param)eta);
    break;
  case NATURAL:
    eta = U(new_param)(ef, EXPECTATION);
    ef->theta2eta(ef, in, (param)eta);
    break;
  case EXPECTATION:
    eta = (expectation)in;
    break;
  default:
    assert(0);
  }

  return (param)eta;
}

#ifndef CONSTRUCTOR
family NAME() {
  family ef = malloc(sizeof(struct family));

  ef->name           = __S(NAME)       ;
  ef->pdf            = &U(pdf           );
  ef->iter_pdf       = &U(iter_pdf      );
  ef->lambda2theta   = &U(lambda2theta  );
  ef->theta2lambda   = &U(theta2lambda  );
  ef->lambda2eta     = &U(lambda2eta    );
  ef->eta2lambda     = &U(eta2lambda    );
  ef->theta2eta      = &U(theta2eta     );
  ef->eta2theta      = &U(eta2theta     );
  ef->fprint         = &U(fprint        );
  ef->F              = &U(F             );
  ef->gradF          = &U(gradF         );
  ef->G              = &U(G             );
  ef->gradG          = &U(gradG         );
  ef->mle            = &U(mle           );
  ef->new_param      = &U(new_param     );
  ef->t              = &U(t             );
  ef->add            = &U(add           );
  ef->minus          = &U(minus         );
  ef->scale          = &U(scale         );
  ef->scalar         = &U(scalar        );
  ef->zero           = &U(zero          );
  ef->rand           = &U(rand          );
  ef->as_source      = &U(as_source     );
  ef->as_natural     = &U(as_natural    );
  ef->as_expectation = &U(as_expectation);

  return ef;
}
#endif


