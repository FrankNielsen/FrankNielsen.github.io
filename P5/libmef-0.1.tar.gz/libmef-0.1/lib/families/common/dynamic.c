#include "dynamic.h"

void U(fprint_dynamic)(FILE *stream, struct dynamic_type *descr, void *dynamic, unsigned int i) {
  switch (descr[i].type) {
  case DOUBLE:
    fprintf(stream, "%s: %f", descr[i].name, *(double*)((char*)(dynamic) + descr[i].offset));
    break;
  default:
    assert(0);
  }
}

void U(fprint_dynamics)(FILE *stream, struct dynamic_type *descr, unsigned int len, void *dynamic) {
  if (len > 0) {
    for(unsigned int i=0; i<len - 1; i++) {
      U(fprint_dynamic)(stream, descr, dynamic, i);
      fprintf(stream, ", ");
    }
    U(fprint_dynamic)(stream, descr, dynamic, len - 1);
  }
}

void U(fprint)(FILE *stream, family ef, param param) {
  switch (param->type) {
  case SOURCE:
    fprintf(stream, "%s(", ef->name);
    U(fprint_dynamics)(stderr, U(source_descr), U(source_len), param);
    if (U(arguments_len) > 0)
      fprintf(stream, "; ");
    U(fprint_dynamics)(stream, U(arguments_descr), U(arguments_len), ef);
    fprintf(stream, ")\n");
    break;

  case NATURAL:
    fprintf(stream, "%s(", ef->name);
    U(fprint_dynamics)(stderr, U(natural_descr), U(natural_len), param);
    if (U(arguments_len) > 0)
      fprintf(stream, "; ");
    U(fprint_dynamics)(stream, U(arguments_descr), U(arguments_len), ef);
    fprintf(stream, ")\n");
    break;

  case EXPECTATION:
    fprintf(stream, "%s(", ef->name);
    U(fprint_dynamics)(stderr, U(expectation_descr), U(expectation_len), param);
    if (U(arguments_len) > 0)
      fprintf(stream, "; ");
    U(fprint_dynamics)(stream, U(arguments_descr), U(arguments_len), ef);
    fprintf(stream, ")\n");
    break;

  default:
    assert(0);
  }
}

param U(dynamic_add)(struct dynamic_type *descr, unsigned int len, param p, param q, param dest) {
  for(unsigned int i=0; i<len; i++) {
    switch (descr[i].type) {
    case DOUBLE:
      *(double*)((char*)(dest) + descr[i].offset) = *(double*)((char*)(p) + descr[i].offset) + *(double*)((char*)(q) + descr[i].offset);
      break;
    default:
      assert(0);
    }
  }
  return dest;
}

param U(dynamic_minus)(struct dynamic_type *descr, unsigned int len, param p, param q, param dest) {
  for(unsigned int i=0; i<len; i++) {
    switch (descr[i].type) {
    case DOUBLE:
      *(double*)((char*)(dest) + descr[i].offset) = *(double*)((char*)(p) + descr[i].offset) - *(double*)((char*)(q) + descr[i].offset);
      break;
    default:
      assert(0);
    }
  }
  return dest;
}

param U(dynamic_zero)(struct dynamic_type *descr, unsigned int len, param p) {
  for(unsigned int i=0; i<len; i++) {
    switch (descr[i].type) {
    case DOUBLE:
      *(double*)((char*)(p) + descr[i].offset) = 0;
      break;
    default:
      assert(0);
    }
  }
  return p;
}

param U(dynamic_scale)(struct dynamic_type *descr, unsigned int len, param p, double scale, param dest) {
  for(unsigned int i=0; i<len; i++) {
    switch (descr[i].type) {
    case DOUBLE:
      *(double*)((char*)(dest) + descr[i].offset) = *(double*)((char*)(p) + descr[i].offset) * scale;
      break;
    default:
      assert(0);
    }
  }
  return dest;
}

double U(dynamic_scalar)(struct dynamic_type *descr, unsigned int len, param p, param q) {
  double scalar = 0;

  for(unsigned int i=0; i<len; i++) {
    switch (descr[i].type) {
    case DOUBLE:
      scalar += *(double*)((char*)(p) + descr[i].offset) * *(double*)((char*)(q) + descr[i].offset);
      break;
    default:
      assert(0);
    }
  }
  return scalar;
}

