#ifndef DYNAMIC_H
#define DYNAMIC_H

struct dynamic_type {
  char *name;
  size_t offset;
  int type;
};

#define DOUBLE 0

#endif
