#include <math.h>
#include <assert.h>
#include <stdio.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

#define debug(...)
/* #define debug(...) fprintf(stderr, __VA_ARGS__) */

/* Stringification of a #define symbol */
#define __S2(s) #s
#define __S(s)  __S2(s)

/* Concatenation of two identifiers, even if one of them have been
   #defined */
#define __C2(a,b) a##b
#define __C(a,b)  __C2(a,b)

#define U(name)   __C(NAME, __C(_, name))

#define CHECK_EF(fam, var) assert((void*)var->ef == (void*)fam)
#define CHECK_TYPE(var, t) assert(var->type == t)

#define family      U(family)
#define source      U(source)
#define natural     U(natural)
#define expectation U(expectation)

typedef struct family*      family;
typedef struct source*      source;
typedef struct natural*     natural;
typedef struct expectation* expectation;

/* Common part for the struct param */
#define PARAM enum type type; struct family *ef

/* Common part for the struct family */
#define FAMILY \
  char*     name;\
  double  (*pdf         )(family ef, double, param);\
  double* (*iter_pdf    )(family ef, unsigned int n, double *in, param lambda, double *out);\
  void    (*lambda2theta  )(family ef, param lambda, param theta );\
  void    (*theta2lambda  )(family ef, param theta , param lambda);\
  void    (*lambda2eta    )(family ef, param lambda, param eta   );\
  void    (*eta2lambda    )(family ef, param eta   , param lambda);\
  void    (*theta2eta     )(family ef, param theta , param eta);\
  void    (*eta2theta     )(family ef, param eta   , param theta);\
  void    (*fprint        )(FILE* stream, family ef, param param); \
  double  (*F             )(family ef, param theta0);\
  void    (*gradF         )(family ef, param theta0, param eta0);\
  double  (*G             )(family ef, param theta0);\
  void    (*gradG         )(family ef, param theta0, param eta0);\
  param   (*mle           )(family ef, unsigned int n, double *data, char *mask, param eta0);\
  void*   (*new_param     )(family ef, enum type type);\
  void    (*t             )(family ef, double x, param eta);\
  param   (*add           )(family ef, param p, param q, param dest);  \
  double  (*scalar        )(family ef, param p, param q);  \
  param   (*minus         )(family ef, param p, param q, param dest);\
  param   (*scale         )(family ef, param p, double a, param dest);\
  param   (*zero          )(family ef, param p);\
  double  (*rand          )(family ef, param p, gsl_rng *rng);\
  param   (*as_source)(family ef, param in);                  \
  param   (*as_natural)(family ef, param in);                 \
  param   (*as_expectation)(family ef, param in)\

#include "../param.h"

double *U(iter_pdf)(family ef, unsigned int n, double *in, struct param *lambda, double *out);
void U(theta2eta)(family ef, param theta, param eta);
void U(eta2theta)(family ef, param eta, param theta);
param U(mle)(family ef, unsigned int n, double *data, char *mask, param eta0);
void* U(new_param)(family ef, enum type type);
param U(add)(family ef, param p, param q, param dest);
param U(minus)(family ef, param p, param q, param dest);
param U(scale)(family ef, param p, double a, param dest);
double U(scalar)(family ef, param p, param q);
param U(zero)(family ef, param p);
param U(as_source)(family ef, param in);
param U(as_natural)(family ef, param in);
param U(as_expectation)(family ef, param in);

