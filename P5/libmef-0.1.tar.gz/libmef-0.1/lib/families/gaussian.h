#define NAME Gaussian
#include "family.h"

struct family {
  FAMILY;
};

struct source {
  PARAM;
  double mu;
  double sigma2;
};

struct natural {
  PARAM;
  double theta1;
  double theta2;
};

struct expectation {
  PARAM;
  double eta1;
  double eta2;
};

family NAME();
source      U(create_source)     (family ef, double mu    , double sigma2);
natural     U(create_natural)    (family ef, double theta1, double theta2);
expectation U(create_expectation)(family ef, double eta1  , double eta2);

