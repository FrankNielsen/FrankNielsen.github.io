#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>

#include "gaussian.h"
#include "common/dynamic.h"

unsigned int U(arguments_len) = 0;
/* ugly but avoid a warning */
struct dynamic_type U(arguments_descr)[1] = {{NULL}};

unsigned int U(source_len) = 2;
struct dynamic_type U(source_descr)[2] = {
  {"mu", offsetof(struct source, mu), DOUBLE},
  {"sigma2", offsetof(struct source, sigma2), DOUBLE},
};

unsigned int U(natural_len) = 2;
struct dynamic_type U(natural_descr)[2] = {
  {"theta1", offsetof(struct natural, theta1), DOUBLE},
  {"theta2", offsetof(struct natural, theta2), DOUBLE},
};

unsigned int U(expectation_len) = 2;
struct dynamic_type U(expectation_descr)[2] = {
  {"eta1", offsetof(struct expectation, eta1), DOUBLE},
  {"eta2", offsetof(struct expectation, eta2), DOUBLE},
};

source U(create_source)(family ef, double mu, double sigma2) {
  source param = U(new_param)(ef, SOURCE);
  param->mu     = mu;
  param->sigma2 = sigma2;

  return param;
}

natural U(create_natural)(family ef, double theta1, double theta2) {
  natural param = U(new_param)(ef, NATURAL);
  param->theta1 = theta1;
  param->theta2 = theta2;

  return param;
}

expectation U(create_expectation)(family ef, double eta1, double eta2) {
  expectation param = U(new_param)(ef, EXPECTATION);
  param->eta1 = eta1;
  param->eta2 = eta2;

  return param;
}

/* Inlining does not seem to bring any significative improvement for iter_pdf
   (roughly less than 2%). */
/* static inline */
double U(pdf)(family ef, double x, param param0) {
  CHECK_EF(ef, param0);

  source lambda = (source)U(as_source)(ef, param0);

  double mu     = lambda->mu;
  double sigma2 = lambda->sigma2;

  return gsl_ran_gaussian_pdf(x - mu, sqrt(sigma2));
}

void U(lambda2theta)(family ef, param lambda0, param theta0) {
  debug("lambda2theta\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(theta0, NATURAL);
  source lambda = (source)lambda0;
  natural theta = (natural)theta0;

  theta->theta1 = lambda->mu / lambda->sigma2;
  theta->theta2 =        - 1 / (2 * lambda->sigma2);
}

void U(theta2lambda)(family ef, param theta0, param lambda0) {
  debug("theta2lambda\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(theta0, NATURAL);
  source lambda = (source)lambda0;
  natural theta = (natural)theta0;

  lambda->mu     = - theta->theta1 / (2 * theta->theta2);
  lambda->sigma2 =             - 1 / (2 * theta->theta2);

  assert(lambda->sigma2 > 0);
}

void U(lambda2eta)(family ef, param lambda0, param eta0) {
  debug("lambda2eta\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(eta0, EXPECTATION);
  source lambda = (source)lambda0;
  expectation eta = (expectation)eta0;

  eta->eta1 = lambda->mu;
  eta->eta2 = lambda->sigma2 + lambda->mu * lambda->mu;
}

void U(eta2lambda)(family ef, param eta0, param lambda0) {
  debug("eta2lambda\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(eta0, EXPECTATION);
  source lambda = (source)lambda0;
  expectation eta = (expectation)eta0;

  lambda->mu     = eta->eta1;
  lambda->sigma2 = eta->eta2 - eta->eta1 * eta->eta1;

  assert(lambda->sigma2 > 0);
}

double U(F)(family ef, param theta0) {
  CHECK_EF(ef, theta0);
  CHECK_TYPE(theta0, NATURAL);
  natural theta = (natural)theta0;
  double theta1 = theta->theta1;
  double theta2 = theta->theta2;

  return (- theta1 * theta1) / (4 * theta2) + log(- M_PI / theta2) / 2;
}

void U(gradF)(family ef, param theta0, param eta0) {
  CHECK_EF(ef, theta0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(theta0, NATURAL);
  CHECK_TYPE(eta0,   EXPECTATION);
  natural     theta = (natural)theta0;
  expectation eta   = (expectation)eta0;

  double theta1 = theta->theta1;
  double theta2 = theta->theta2;
  eta->eta1 = - theta1 / (2 * theta2);
  eta->eta2 = - 1 / (2 * theta2) + theta1 * theta1 / (4 * theta2 * theta2);
}

double U(G)(family ef, param eta0) {
  CHECK_EF(ef, eta0);
  CHECK_TYPE(eta0, EXPECTATION);
  expectation eta = (expectation)eta0;
  double eta1 = eta->eta1;
  double eta2 = eta->eta2;

  return - log(eta1 * eta1 - eta2) / 2;
}

void U(gradG)(family ef, param eta0, param theta0) {
  CHECK_EF(ef, eta0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(eta0,   EXPECTATION);
  CHECK_TYPE(theta0, NATURAL);
  expectation eta   = (expectation)eta0;
  natural     theta = (natural)theta0;

  double eta1 = eta->eta1;
  double eta2 = eta->eta2;
  double tmp  = eta1 * eta1 - eta2;
  theta->theta1 = - eta1 / tmp;
  theta->theta2 = 1 / (2 * tmp);
}

void U(t)(family ef, double x, param eta0) {
  CHECK_EF(ef, eta0);
  CHECK_TYPE(eta0, EXPECTATION);
  expectation eta = (expectation)eta0;

  eta->eta1 = x;
  eta->eta2 = x*x;
}

double U(k)(family ef, double x) {
  return 0;
}

double U(rand)(family ef, param param0, gsl_rng *rng) {
  CHECK_EF(ef, param0);

  source lambda = (source)U(as_source)(ef, param0);

  double mu     = lambda->mu;
  double sigma2 = lambda->sigma2;

  return gsl_ran_gaussian(rng, sqrt(sigma2)) + mu;
}

#include "common/all.c"

