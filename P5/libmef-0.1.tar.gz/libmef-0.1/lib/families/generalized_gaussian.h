#define NAME GeneralizedGaussian
#include "family.h"

struct family {
  FAMILY;
  double mu;
  double beta;
};

struct source {
  PARAM;
  double alpha;
};

struct natural {
  PARAM;
  double theta1;
};

struct expectation {
  PARAM;
  double eta1;
};

family NAME(double mu, double beta);
source      U(create_source     )(family ef, double alpha );
natural     U(create_natural    )(family ef, double theta1);
expectation U(create_expectation)(family ef, double eta1  );

void GeneralizedGaussian_estimate_mu  (family ef, unsigned int n, double *data, char *mask);
void GeneralizedGaussian_estimate_beta(family ef, unsigned int n, double *data, char *mask);
