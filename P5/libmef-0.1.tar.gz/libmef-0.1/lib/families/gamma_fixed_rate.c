#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>

#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_sf_psi.h>

#include "../param.h"
#include "gamma_fixed_rate.h"
#include "common/dynamic.h"

unsigned int U(arguments_len) = 1;
struct dynamic_type U(arguments_descr)[1] = {
  {"rate"  , offsetof(struct family, rate), DOUBLE},
};

unsigned int U(source_len) = 1;
struct dynamic_type U(source_descr)[1] = {
  {"shape", offsetof(struct source, shape), DOUBLE},
};

unsigned int U(natural_len) = 1;
struct dynamic_type U(natural_descr)[1] = {
  {"theta1", offsetof(struct natural, theta1), DOUBLE},
};

unsigned int U(expectation_len) = 1;
struct dynamic_type U(expectation_descr)[1] = {
  {"eta1", offsetof(struct expectation, eta1), DOUBLE},
};

source U(create_source)(family ef, double shape) {
  source param = U(new_param)(ef, SOURCE);
  param->shape = shape;

  return param;
}

natural U(create_natural)(family ef, double theta1) {
  natural param = U(new_param)(ef, NATURAL);
  param->theta1 = theta1;

  return param;
}

expectation U(create_expectation)(family ef, double eta1) {
  expectation param = U(new_param)(ef, EXPECTATION);
  param->eta1 = eta1;

  return param;
}

void U(estimate_beta)(family ef, param param0, unsigned int n, double *data, char *mask) {
  source param = (source)ef->as_source(ef, param0);
  double alpha = param->shape;

  double       sum   = 0;
  unsigned int count = 0;
  for (unsigned int i=0; i<n; i++) {
    if (mask[i]) {
      count++;

      sum += data[i];
    }
  }

  double beta = count * alpha / sum;

  ef->rate = beta;
}

/* http://hips.seas.harvard.edu/files/invpsi.m */
double U(inv_psi)(double psi) {
  double precision = 10e-10;
  double L = 1;
  double Y = exp(psi);
  while (L > precision) {
    if ( (psi-gsl_sf_psi(Y)) > 0)
      Y = Y + L;
    else
      Y = Y - L;

    L = L / 2;
  }

  return Y;
}

double U(pdf)(family ef, double x, param p) {
  CHECK_EF(ef, p);
  source lambda = (source)ef->as_source(ef, p);
  double alpha  = lambda->shape;
  double beta   = ef->rate;

  return pow(beta, alpha) * pow(x, alpha-1) * exp(-beta * x) / gsl_sf_gamma(alpha);
}

void U(lambda2theta)(family ef, param lambda0, param theta0) {
  debug("lambda2theta\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(theta0, NATURAL);
  source lambda = (source)lambda0;
  natural theta = (natural)theta0;

  double alpha  = lambda->shape;

  theta->theta1 = alpha - 1;
}

void U(theta2lambda)(family ef, param theta0, param lambda0) {
  debug("theta2lambda\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(theta0, NATURAL);
  source lambda = (source)lambda0;
  natural theta = (natural)theta0;

  double theta1 = theta->theta1;

  lambda->shape = theta1 + 1;
}

void U(lambda2eta)(family ef, param lambda0, param eta0) {
  debug("lambda2eta\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(eta0, EXPECTATION);

  double      beta  = ef->rate;
  double      alpha = ((source)lambda0)->shape;
  expectation eta   = (expectation)eta0;

  eta->eta1 = -log(beta) + gsl_sf_psi(alpha);
}

void U(eta2lambda)(family ef, param eta0, param lambda0) {
  debug("eta2lambda\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(eta0, EXPECTATION);

  double beta   = ef->rate;
  double eta    = ((expectation)eta0)->eta1;
  source lambda = (source)lambda0;

  lambda->shape = U(inv_psi)(eta + log(beta));
}

double U(F)(family ef, param theta0) {
  CHECK_EF(ef, theta0);
  CHECK_TYPE(theta0, NATURAL);

  double beta  = ef->rate;
  double theta = ((natural)theta0)->theta1;

  return -(theta + 1) * log(beta) + log(gsl_sf_gamma(theta + 1));
}

void U(gradF)(family ef, param theta0, param eta0) {
  CHECK_EF(ef, theta0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(theta0, NATURAL);
  CHECK_TYPE(eta0,   EXPECTATION);

  double beta     = ef->rate;
  expectation eta = (expectation)eta0;
  double    theta = ((natural)theta0)->theta1;

  eta->eta1 = -log(beta) + gsl_sf_psi(theta + 1);
}

double U(G)(family ef, param eta0) {
  CHECK_EF(ef, eta0);
  CHECK_TYPE(eta0, EXPECTATION);

  double beta = ef->rate;
  double eta  = ((expectation)eta0)->eta1;

  double tmp = U(inv_psi)(eta + log(beta));

  return eta * (tmp - 1) + tmp * log(beta) + log(gsl_sf_gamma(tmp));
}

void U(gradG)(family ef, param eta0, param theta0) {
  CHECK_EF(ef, eta0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(eta0,   EXPECTATION);
  CHECK_TYPE(theta0, NATURAL);

  double  beta  = ef->rate;
  natural theta = (natural)theta0;
  double  eta   = ((expectation)eta0)->eta1;

  double tmp = U(inv_psi)(eta + log(beta));

  theta->theta1 = tmp - 1;
}

void U(t)(family ef, double x, param eta0) {
  CHECK_EF(ef, eta0);
  CHECK_TYPE(eta0, EXPECTATION);
  expectation eta = (expectation)eta0;

  eta->eta1 = log(x);
}

double U(k)(family ef, double x) {
  double beta = ef->rate;

  return -beta * x;
}

double U(rand)(family ef, param param, gsl_rng *rng) {
  source lambda = (source)ef->as_source(ef, param);

  return gsl_ran_gamma(rng, lambda->shape, 1/ef->rate);
}

#define CONSTRUCTOR
#include "common/all.c"

family NAME(double rate) {
  family ef = malloc(sizeof(struct family));

  ef->name         = __S(NAME)     ;
  ef->pdf          = &U(pdf         );
  ef->iter_pdf     = &U(iter_pdf    );
  ef->lambda2theta = &U(lambda2theta);
  ef->theta2lambda = &U(theta2lambda);
  ef->lambda2eta   = &U(lambda2eta  );
  ef->eta2lambda   = &U(eta2lambda  );
  ef->theta2eta    = &U(theta2eta   );
  ef->eta2theta    = &U(eta2theta   );
  ef->fprint       = &U(fprint      );
  ef->F            = &U(F           );
  ef->gradF        = &U(gradF       );
  ef->G            = &U(G           );
  ef->gradG        = &U(gradG       );
  ef->mle          = &U(mle         );
  ef->new_param    = &U(new_param   );
  ef->t            = &U(t           );
  ef->add          = &U(add         );
  ef->scale        = &U(scale       );
  ef->scalar       = &U(scalar      );
  ef->zero         = &U(zero        );
  ef->rand         = &U(rand        );
  ef->as_source      = &U(as_source     );
  ef->as_natural     = &U(as_natural    );
  ef->as_expectation = &U(as_expectation);

  ef->rate = rate;

  return ef;
}

