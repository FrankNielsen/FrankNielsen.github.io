#define NAME GammaFixedRate
#include "family.h"

struct family {
  FAMILY;
  double rate;
};

struct source {
  PARAM;
  double shape;
};

struct natural {
  PARAM;
  double theta1;
};

struct expectation {
  PARAM;
  double eta1;
};

family        NAME               (double rate);
source      U(create_source     )(family ef, double alpha );
natural     U(create_natural    )(family ef, double theta1);
expectation U(create_expectation)(family ef, double eta1  );
double      U(inv_psi           )(double psi);
void        U(estimate_beta     )(family ef, param param0, unsigned int n, double *data, char *mask);

