#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>

#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_sf_psi.h>

#include "../param.h"
#include "generalized_gaussian.h"
#include "common/dynamic.h"

unsigned int U(arguments_len) = 2;
struct dynamic_type U(arguments_descr)[2] = {
  {"mu"  , offsetof(struct family, mu  ), DOUBLE},
  {"beta", offsetof(struct family, beta), DOUBLE},
};

unsigned int U(source_len) = 1;
struct dynamic_type U(source_descr)[1] = {
  {"alpha", offsetof(struct source, alpha), DOUBLE},
};

unsigned int U(natural_len) = 1;
struct dynamic_type U(natural_descr)[1] = {
  {"theta1", offsetof(struct natural, theta1), DOUBLE},
};

unsigned int U(expectation_len) = 1;
struct dynamic_type U(expectation_descr)[1] = {
  {"eta1", offsetof(struct expectation, eta1), DOUBLE},
};

void U(estimate_mu)(family ef, unsigned int n, double *data, char *mask) {
  double mu = 0.;

  unsigned int count = 0;
  for (unsigned int j=0; j<n; j++) {
    if (mask[j]) {
      count++;

      mu += data[j];
    }
  }

  ef->mu = mu / count;
}

double U(f_beta)(double beta, double mu, unsigned int n, double *data, char *mask) {
  double sum_x_beta_log_x = 0;
  double sum_x_beta       = 0;

  unsigned int count = 0;
  for (unsigned int i=0; i<n; i++) {
    if (mask[i]) {
      count++;

      double x      = fabs(data[i] - mu);
      double x_beta = pow(x, beta);

      sum_x_beta_log_x += x_beta * log(x);
      sum_x_beta       += x_beta;
    }
  }
  return 1 + gsl_sf_psi(1 / beta) / beta \
    - sum_x_beta_log_x / sum_x_beta + log(beta * sum_x_beta / count) / beta;
}

void U(estimate_beta)(family ef, unsigned int n, double *data, char *mask) {
  unsigned int count = 30;

  double mu   = ef->mu;

  double beta1 = 0.01;
  double beta2 =  20;
  double beta  = (beta1 + beta2) / 2;

  double y;
  double y1;

  for (unsigned int i=0; i<count; i++) {
    y1 = GeneralizedGaussian_f_beta(beta1, mu, n, data, mask);
    y  = GeneralizedGaussian_f_beta(beta , mu, n, data, mask);

    if (y * y1 >= 0)
      beta1 = beta;
    else
      beta2 = beta;

    beta = (beta1 + beta2) / 2;
  }

  ef->beta = beta;
}

source U(create_source)(family ef, double alpha) {
  source param = U(new_param)(ef, SOURCE);
  param->alpha = alpha;

  return param;
}

natural U(create_natural)(family ef, double theta1) {
  natural param = U(new_param)(ef, NATURAL);
  param->theta1 = theta1;

  return param;
}

expectation U(create_expectation)(family ef, double eta1) {
  expectation param = U(new_param)(ef, EXPECTATION);
  param->eta1 = eta1;

  return param;
}

double U(pdf)(family ef, double x, param p) {
  CHECK_EF(ef, p);
  source lambda = (source)ef->as_source(ef, p);
  double alpha  = lambda->alpha;
  double mu     = ef->mu;
  double beta   = ef->beta;

  return beta / (2 * alpha * gsl_sf_gamma(1 / beta)) * \
    exp(- pow(fabs(x - mu) / alpha, beta));
}

void U(lambda2theta)(family ef, param lambda0, param theta0) {
  debug("lambda2theta\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(theta0, NATURAL);
  source lambda = (source)lambda0;
  natural theta = (natural)theta0;

  double alpha  = lambda->alpha;
  double beta   = ef->beta;

  theta->theta1 = pow(alpha, -beta);
}

void U(theta2lambda)(family ef, param theta0, param lambda0) {
  debug("theta2lambda\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(theta0, NATURAL);
  source lambda = (source)lambda0;
  natural theta = (natural)theta0;

  double theta1 = theta->theta1;
  double beta   = ef->beta;

  lambda->alpha  = pow(theta1, -1/beta);
}

void U(lambda2eta)(family ef, param lambda0, param eta0) {
  debug("lambda2eta\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(eta0, EXPECTATION);

  double      beta  = ef->beta;
  double      alpha = ((source)lambda0)->alpha;
  expectation eta   = (expectation)eta0;

  eta->eta1 = - pow(alpha, beta) / beta;
}

void U(eta2lambda)(family ef, param eta0, param lambda0) {
  debug("eta2lambda\n");
  CHECK_EF(ef, lambda0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(lambda0, SOURCE);
  CHECK_TYPE(eta0, EXPECTATION);

  double  beta  = ef->beta;
  double  eta   = ((expectation)eta0)->eta1;
  source lambda = (source)lambda0;

  lambda->alpha = pow(- beta * eta, 1/beta);
}

double U(F)(family ef, param theta0) {
  CHECK_EF(ef, theta0);
  CHECK_TYPE(theta0, NATURAL);

  double beta  = ef->beta;
  double theta = ((natural)theta0)->theta1;

  return -log(theta) / beta - log(beta / (2 * gsl_sf_gamma(1/beta)));
}

void U(gradF)(family ef, param theta0, param eta0) {
  CHECK_EF(ef, theta0);
  CHECK_EF(ef, eta0);
  CHECK_TYPE(theta0, NATURAL);
  CHECK_TYPE(eta0,   EXPECTATION);

  double     beta = ef->beta;
  expectation eta = (expectation)eta0;
  double    theta = ((natural)theta0)->theta1;

  eta->eta1 = - 1 / (beta * theta);
}

double U(G)(family ef, param eta0) {
  CHECK_EF(ef, eta0);
  CHECK_TYPE(eta0, EXPECTATION);

  double beta = ef->beta;
  double eta  = ((expectation)eta0)->eta1;

  return - 1 / beta - log(- beta * eta) / beta + log(beta / (2 * gsl_sf_gamma(1/beta)));
}

void U(gradG)(family ef, param eta0, param theta0) {
  CHECK_EF(ef, eta0);
  CHECK_EF(ef, theta0);
  CHECK_TYPE(eta0,   EXPECTATION);
  CHECK_TYPE(theta0, NATURAL);

  double   beta = ef->beta;
  natural theta = (natural)theta0;
  double  eta   = ((expectation)eta0)->eta1;

  theta->theta1 = - 1 / (beta * eta);
}

void U(t)(family ef, double x, param eta0) {
  CHECK_EF(ef, eta0);
  CHECK_TYPE(eta0, EXPECTATION);
  expectation eta = (expectation)eta0;
  double mu       = ef->mu;
  double beta     = ef->beta;

  eta->eta1 = - pow(fabs(x - mu), beta);
}

double U(k)(family ef, double x) {
  return 0;
}

double U(rand)(family ef, param param0, gsl_rng *rng) {
  return 0.;
}

#define CONSTRUCTOR
#include "common/all.c"

family NAME(double mu, double beta) {
  family ef = malloc(sizeof(struct family));

  ef->name         = __S(NAME)     ;
  ef->pdf          = &U(pdf         );
  ef->iter_pdf     = &U(iter_pdf    );
  ef->lambda2theta = &U(lambda2theta);
  ef->theta2lambda = &U(theta2lambda);
  ef->lambda2eta   = &U(lambda2eta  );
  ef->eta2lambda   = &U(eta2lambda  );
  ef->theta2eta    = &U(theta2eta   );
  ef->eta2theta    = &U(eta2theta   );
  ef->fprint       = &U(fprint      );
  ef->F            = &U(F           );
  ef->gradF        = &U(gradF       );
  ef->G            = &U(G           );
  ef->gradG        = &U(gradG       );
  ef->mle          = &U(mle         );
  ef->new_param    = &U(new_param   );
  ef->t            = &U(t           );
  ef->add          = &U(add         );
  ef->scale        = &U(scale       );
  ef->scalar       = &U(scalar      );
  ef->zero         = &U(zero        );
  ef->rand         = &U(rand        );
  ef->as_source      = &U(as_source     );
  ef->as_natural     = &U(as_natural    );
  ef->as_expectation = &U(as_expectation);

  ef->mu   = mu;
  ef->beta = beta;

  return ef;
}

