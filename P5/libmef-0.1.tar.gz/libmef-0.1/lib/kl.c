#include "param.h"
#include "family.h"
#include "kl.h"
#include "bregman.h"

#include <math.h>

double kl_mc(mixture mix1, mixture mix2, unsigned int count, gsl_rng *rng) {
  double eps = 1e-100;

  double dist = 0;
  for (unsigned int i=0; i<count; i++) {
    double x  = mixture_rand(mix1, rng);
    double y1 = mixture_pdf(mix1, x);
    double y2 = mixture_pdf(mix2, x);
    dist += log(fmax(eps, y1)) - log(fmax(eps, y2));
  }

  return fmax(0., dist / count);
}

double kl_var(mixture mix1, mixture mix2) {
  unsigned int n1 = mix1->size;
  unsigned int n2 = mix2->size;
  family ef = mix1->ef[0]; /* we need to have the same family everywhere */

  param *theta1 = malloc(n1 * sizeof(param));
  for (unsigned int i=0; i<n1; i++) {
    theta1[i] = ef->as_natural(ef, mix1->params[i]);
  }

  param *theta2 = malloc(n2 * sizeof(param));
  for (unsigned int i=0; i<n2; i++) {
    theta2[i] = ef->as_natural(ef, mix2->params[i]);
  }

  double dist = 0;
  for (unsigned int i=0; i<n1; i++) {
    double sum1 = 0;
    for (unsigned int j=0; j<n1; j++) {
      sum1 += mix1->weights[j] * exp(-bregman_div(ef, theta1[j], theta1[i]));
    }

    double sum2 = 0;
    for (unsigned int j=0; j<n2; j++) {
      sum2 += mix2->weights[j] * exp(-bregman_div(ef, theta2[j], theta1[i]));
    }

    dist += mix1->weights[i] * log(sum1 / sum2);
  }

  return dist;
}

