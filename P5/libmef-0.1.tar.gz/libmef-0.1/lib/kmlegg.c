#include <stdlib.h>
#include <assert.h>

#include "param.h"
#include "family.h"
#include "mixture.h"

#include "families/generalized_gaussian.h"
#undef family

#include "kmlegg.h"

#include <math.h>
#include <gsl/gsl_matrix.h>

kmlegg kmlegg_create(unsigned int k,
                 double      *data,
                 unsigned int n,
                 unsigned int dim
                 ) {
  assert(k < n);

  kmlegg kmlegg = malloc(sizeof(struct kmlegg));
  kmlegg->k           = k;
  kmlegg->data        = data;
  kmlegg->n           = n;
  kmlegg->dim         = dim;
  kmlegg->has_changed = 1;

  kmlegg->affectation = malloc(n * sizeof(unsigned int));
  kmlegg->counts      = malloc(k * sizeof(unsigned int));
  kmlegg->mask        = malloc(n * sizeof(char));

  kmlegg->mixture     = mixture_create(k);
  kmlegg->weights     = kmlegg->mixture->weights;
  kmlegg->components  = kmlegg->mixture->params;
  kmlegg->ef          = kmlegg->mixture->ef;

  kmlegg->treshold    = 0;
  kmlegg->maxiter1    = 0;
  kmlegg->maxiter2    = 0;
  kmlegg->iter1       = 0;
  kmlegg->iter2       = 0;

  return kmlegg;
}

void kmlegg_initialize_from_clustering(kmlegg kmlegg, double *weights, unsigned int *affectation) {
  for (unsigned int i=0; i<kmlegg->k; i++) {
    for (unsigned int j=0; j<kmlegg->n; j++) {
      if (affectation[j] == i)
        kmlegg->mask[j] = 1;
      else
        kmlegg->mask[j] = 0;
    }

    family ef = (family)GeneralizedGaussian(1., 2.);

    kmlegg->mixture->ef[i] = ef;
    kmlegg->components[i]  = ef->new_param(ef, NATURAL);

    param eta = ef->new_param(ef, EXPECTATION);
    ef->mle(ef, kmlegg->n, kmlegg->data, kmlegg->mask, eta);
    ef->eta2theta(ef, eta, kmlegg->components[i]);

    kmlegg->weights[i] = weights[i];

    GeneralizedGaussian_estimate_mu  ((GeneralizedGaussian_family)ef, kmlegg->n, kmlegg->data, kmlegg->mask);
    GeneralizedGaussian_estimate_beta((GeneralizedGaussian_family)ef, kmlegg->n, kmlegg->data, kmlegg->mask);
  }
}

void kmlegg_assignment(kmlegg kmlegg) {
  gsl_matrix_view data = gsl_matrix_view_array(kmlegg->data,
                                                kmlegg->n, kmlegg->dim);
  for (unsigned int i=0; i<kmlegg->n; i++) {
    double x = data.matrix.data[i * data.matrix.tda + 0];
    param c = kmlegg->components[0];

    unsigned int best_index = 0;
    double       best_dist  = - log(kmlegg->weights[0] * kmlegg->ef[0]->pdf(kmlegg->ef[0], x, c));
    double       dist;

    for (unsigned int j=0; j<kmlegg->k; j++) {
      c    = kmlegg->components[j];
      dist = - log(kmlegg->weights[j] * kmlegg->ef[j]->pdf(kmlegg->ef[j], x, c));

      if (dist < best_dist) {
        best_index = j;
        best_dist  = dist;
      }
    }

    unsigned int current_index = kmlegg->affectation[i];
    if (best_index != current_index) {
      kmlegg->has_changed    = 1;
      kmlegg->affectation[i] = best_index;
    }
  }

  for(unsigned int i=0; i<kmlegg->k; i++) {
    kmlegg->counts[i] = 0;
  }

  for(unsigned int i=0; i<kmlegg->n; i++) {
    kmlegg->counts[kmlegg->affectation[i]]++;
  }
  for(unsigned int i=0; i<kmlegg->k; i++) {
    assert(kmlegg->counts[i] > 0);
  }
}

void kmlegg_update_parameters(kmlegg kmlegg) {
  for (unsigned int i=0; i<kmlegg->k; i++) {
    for (unsigned int j=0; j<kmlegg->n; j++) {
      if (kmlegg->affectation[j] == i)
        kmlegg->mask[j] = 1;
      else
        kmlegg->mask[j] = 0;
    }

    param eta = kmlegg->ef[i]->new_param(kmlegg->ef[i], EXPECTATION);
    kmlegg->ef[i]->mle(kmlegg->ef[i], kmlegg->n, kmlegg->data, kmlegg->mask, eta);
    kmlegg->ef[i]->eta2theta(kmlegg->ef[i], eta, kmlegg->components[i]);

    param lambda = kmlegg->ef[i]->new_param(kmlegg->ef[i], SOURCE);
    kmlegg->ef[i]->theta2lambda(kmlegg->ef[i], kmlegg->components[i], lambda);
  }
}

void kmlegg_update_weights(kmlegg kmlegg) {
  for(unsigned int i=0; i<kmlegg->k; i++) {
    double w = (double)kmlegg->counts[i] / (double)kmlegg->n;
    kmlegg->weights[i] = w;
  }
}

void kmlegg_choose_families(kmlegg kmlegg) {
  for(unsigned int i=0; i<kmlegg->k; i++) {
    family ef = kmlegg->ef[i];

    for (unsigned int j=0; j<kmlegg->n; j++) {
      if (kmlegg->affectation[j] == i)
        kmlegg->mask[j] = 1;
      else
        kmlegg->mask[j] = 0;
    }

    GeneralizedGaussian_estimate_mu  ((GeneralizedGaussian_family)ef, kmlegg->n, kmlegg->data, kmlegg->mask);
    GeneralizedGaussian_estimate_beta((GeneralizedGaussian_family)ef, kmlegg->n, kmlegg->data, kmlegg->mask);
  }
}

void kmlegg_run(kmlegg kmlegg) {
  while (1) {
    if (kmlegg->maxiter1 > 0 && kmlegg->iter1 >= kmlegg->maxiter1)
      break;

    kmlegg->has_changed = 1;
    kmlegg->iter2 = 0;
    while (kmlegg->has_changed) {
      if (kmlegg->maxiter2 > 0 && kmlegg->iter2 >= kmlegg->maxiter2)
        break;

      kmlegg->has_changed = 0;

      kmlegg_assignment(kmlegg);
      kmlegg_update_parameters(kmlegg);

      kmlegg->iter2++;
    }
    kmlegg_choose_families(kmlegg);
    kmlegg_update_weights(kmlegg);

    kmlegg->iter1++;
  }

  free(kmlegg->counts);
  free(kmlegg->mask);
}

void kmlegg_step(kmlegg kmlegg) {
  kmlegg->has_changed = 1;
  kmlegg->iter2 = 0;
  while (kmlegg->has_changed) {
    if (kmlegg->maxiter2 > 0 && kmlegg->iter2 >= kmlegg->maxiter2)
      break;

    kmlegg->has_changed = 0;

    kmlegg_assignment(kmlegg);
    kmlegg_update_parameters(kmlegg);

    kmlegg->iter2++;
  }
  kmlegg_choose_families(kmlegg);
  kmlegg_update_weights(kmlegg);

  kmlegg->iter1++;
}

void kmlegg_destroy(kmlegg kmlegg) {
}

