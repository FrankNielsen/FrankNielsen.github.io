#ifndef DIVERGENCE_H
#define DIVERGENCE_H

double divergence( double*,double*,int );
void grad( double*,double*,int );
void invGrad( double*,double*,int );
void divMat( double**,double**,double**,int,int,int );
void hessian(double*,double*,int );
void findCentroid( double*,double**,int*,int,int );

double multinomialF( double*,int );
void multinomialGradF( double*,double*,int );
double multinomialDivergence( double*,double*,int );
void multinomialInvGradF( double*,double*,int );
void rightCentroid( double*,double**,int,int );
void multinomialLeftCentroid( double*,double**,int,int );
double approximateDiv( double*,double*,int );
void multinomialGeodesicPoint( double*,double*,double*,int,double );
void geodesicPoint( double*,double*,double*,int, double );

#endif
