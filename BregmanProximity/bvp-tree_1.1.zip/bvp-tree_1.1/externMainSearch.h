#ifndef EXTERN_MAIN_SEARCH_H
#define EXTERN_MAIN_SEARCH_H

extern double avgDistCount;


#endif