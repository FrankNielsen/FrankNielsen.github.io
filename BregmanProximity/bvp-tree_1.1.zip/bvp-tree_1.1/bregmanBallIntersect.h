#ifndef BB_INTERSECT_H
#define BB_INTERSECT_H

int bregmanBallIntersect( double,double,double*,double*,int,double,double,long* );

#endif BB_INTERSECT_H
