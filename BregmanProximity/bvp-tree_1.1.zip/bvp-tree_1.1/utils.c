#define UTILS_C

#include<stdarg.h>
#define _CRT_RAND_S
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include "Windows.h"
#include "utils.h"

// generates a random integer in [0,n-1] 
// note: assumes that rand has already been seeded 
int randomInt(int n){
	unsigned int val;
	errno_t err;
	err = rand_s( &val );
	if (err != 0){
            printf_s("The rand_s function failed!\n");
        }
	return (unsigned int) ( (double)val/(double)UINT_MAX*(double)n );
}

// generate a uniformly distributed random double in [0,x) 
// always allume that rand has been already seeded 
double randomDouble(double x){
	unsigned int val;
	errno_t err;
	err = rand_s( &val );
	if (err != 0){
            printf_s("The rand_s function failed!\n");
        }
	return (double) val / (double) UINT_MAX * x;
}

// measures the elapsed time using the high-resolution windows counter
double timediff( LARGE_INTEGER start, LARGE_INTEGER end, LARGE_INTEGER freq ){
       
    double val;       
    val = (double)(end.QuadPart - start.QuadPart) / (double)(freq.QuadPart);
    return val;
}

// keep sorted the actual k nearest neighbors
void insert(int* NNs, double* dtoNNs, int newNN, double dNNnew, int k){
  
	int i=0;
	while (i < (k-1) && dtoNNs[i+1]>dNNnew){
		NNs[i]=NNs[i+1];
		dtoNNs[i]=dtoNNs[i+1];
		i++;
	}
	if ( dtoNNs[i]>dNNnew ) {
		NNs[i]=newNN;
		dtoNNs[i]=dNNnew;
	}
}

/* compare function for performing qsort*/
int compareDoubles( double* A, double *B ){
	if( *A<*B )
	    return -1;
    else if( *A==*B )
        return 0;
    else
        return 1;
}

