#ifndef BVPTREE_H
#define BVPTREE_H

typedef struct treenode *TREENODE;

typedef struct treenode{
	double *v;	// vantage point
	double *gradV;	// gradient of vantage point
	double R;	// radius of the ball
	int *inds;	// indices of data stored at this node
	int n;		// number of stored points
	int isLeaf;	//1 if this is a leaf, 0 otherwise
	int depth;	// depth of this node (the tree root has depth = 0)
	double divToV;	//used only when searching
	TREENODE leftChild;	// pointers to children
	TREENODE rightChild;	// *	*	*	*
} treenode;

TREENODE buildBvpTree( double**,int,int,int );

TREENODE recBvpSubtreeBuild( double**,int*,int,int,int,int );

TREENODE setupNode(int n, int d, int flag);

void deleteBvpTree( TREENODE );


#endif