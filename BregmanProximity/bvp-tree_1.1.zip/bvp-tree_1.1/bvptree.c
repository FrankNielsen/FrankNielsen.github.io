#define BVPTREE_C

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "Windows.h"
#include "bvptree.h"
#include "utils.h"
#include "divergence.h"

//this header file contains only declarations of global variables used when performing experiments with the mainBvptBuild function (comment it when not defining that global variables in the main function)
//#include "externMainBuild.h"

TREENODE buildBvpTree( double **data, int n, int d, int bucketSize ){
	int* inds, i;
	TREENODE root;
	int depth = 0;	// the root depth is zero
	
	/* seed the random number generator : only for compilation under windows */
	LARGE_INTEGER tNow;
	if( QueryPerformanceCounter(&tNow) )
		srand( (unsigned)tNow.LowPart );
		
	/* allocates the array for data indexes*/
	inds = calloc(n,sizeof(int));  
	if(inds==NULL)
		printf("error with allocation");
	/* all indexes are stored at the root node*/	
	for(i=0;i<n;i++)
		inds[i]=i;	

	/* calls the recursive building function for the root*/
	root = recBvpSubtreeBuild( data,inds,n,d,bucketSize,depth );
	free(inds);
	
	return root;
}

TREENODE recBvpSubtreeBuild( double **data, int *inds, int n, int d, int bucketSize, int depth ){
	int i, vpInd, medInd;
	TREENODE node;
	double *divToVp, *sortDiv;
	int *indsL, *indsR, lLength, rLength;
	
	//update global variable that stores the tree depth
	#ifdef EXTERN_MAIN_BUILD_H
		if( depth>maxDepth )
			maxDepth = depth;
	#endif
	
	// the actual node is not to be splitted
	if( n<=bucketSize ){
		// inizializes a new leaf treenode
		node = setupNode(n,d,1);
		// sets the node fields
		node->n = n;
		for( i=0;i<n;i++ )
			node->inds[i] = inds[i];	
		node->depth = depth;
		node->isLeaf = 1;
		
		#ifdef EXTERN_MAIN_BUILD_H
			numLeafNodes++;				//update the global variable that counts the number of leaves
			sumLeafDepth += n*depth;	//update the global variable used to compute the average tree depth
		#endif
		
		return node;		
	}
	
	//update the global variable that counts the number of non-leaves and the constuction costgkkjj
	#ifdef EXTERN_MAIN_BUILD_H
		numNonLeafNodes++;
		constructionCost+=n;
	#endif
	
	// the actual node is to be splitted
	// inizializes a new interior treenode
	node = setupNode(n,d,0);
	// sets the node fields
	node->n = n;
	for( i=0;i<n;i++ )
		node->inds[i] = inds[i];
	node->depth = depth;
	node->isLeaf = 0;
		
	// computes a random vantage point
	vpInd = randomInt(n); 					
	for( i=0;i<d;i++ )
		node->v[i] = data[inds[vpInd]][i]; 	// computes coordinates of the vantage point
	grad(node->gradV,node->v,d);
	
	// compute the ball radius as the median of divergences to the vantage point
	divToVp = calloc(n,sizeof(double));
	sortDiv = calloc(n,sizeof(double));
	for( i=0;i<n;i++ ){
		divToVp[i] = divergence( data[inds[i]],node->v,d );
		sortDiv[i] = divToVp[i];
	}
	qsort( sortDiv,n,sizeof(double),(compfn)compareDoubles );
	medInd = (int)ceil((double)n/2.0);
	node->R = sortDiv[medInd];
		
	// split the node into inner and outer subset
	indsL = calloc(n,sizeof(int));
	indsR = calloc(n,sizeof(int));
	
	lLength = 0;
	rLength = 0;
	for( i=0;i<n;i++ ){
		if( divToVp[i]<node->R )
			indsL[lLength++] = inds[i];
		else
			indsR[rLength++] = inds[i];
	}
	
	if(!lLength || !rLength)
		printf("zero samples\n");

	node->leftChild = recBvpSubtreeBuild( data,indsL,lLength,d,bucketSize,depth+1 );
	node->rightChild = recBvpSubtreeBuild( data,indsR,rLength,d,bucketSize,depth+1 );
	
	free(divToVp);
	free(sortDiv);
	free(indsL);
	free(indsR);
	
	return node;	

}


// allocates memory for all necessary fields of the treenode struct (if the node is to be a leaf flag=1, otherwise flag=0)
TREENODE setupNode(int n, int d, int flag){
	TREENODE node;
	node = (TREENODE)calloc(1,sizeof(treenode));
	if( flag==0 ){
		node->v = calloc(d,sizeof(double));
		node->gradV = calloc(d,sizeof(double));
	}
	node->inds = calloc(n,sizeof(int));
	
	return node;
}

// free memory for the bvptree
void deleteBvpTree( TREENODE root ){
	if( !(root->isLeaf) ){
		free(root->v);
		free(root->gradV);
		deleteBvpTree(root->leftChild);
		deleteBvpTree(root->rightChild);
	}
	else{
		free(root->inds);
	}
	free(root);	
}