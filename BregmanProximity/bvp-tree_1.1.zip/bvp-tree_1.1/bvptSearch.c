#define BVPT_SEARCH_C

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "bvptree.h"
#include "divergence.h"
#include "bvptree.h"
#include "utils.h"
#include "bregmanBallIntersect.h"
#include "bvptSearch.h"

#define USE_EXTERN_VARIABLES

#ifdef USE_EXTERN_VARIABLES
	#include "externMainSearch.h"
#endif

//double *x;  //temp variables used throughout
long distCount;
double *dToNNs;
int *NNs;

//Performs nearest neighbor search for m queries.
void multiBvptSearch(TREENODE root, double **Q, double **data, int n, int d, int m, int k, int *kthInd, double *kthDist){
	int i,j;
	//x = calloc(d,sizeof(double));
	dToNNs = calloc(k,sizeof(double));
	NNs = calloc(k,sizeof(int));

	for(i=0;i<m;i++){
		// inizialize arrays of the k nearest neighbors 
		distCount=0;
		for(j=0;j<k;j++){
			dToNNs[j]=HUGE_VAL;
			NNs[j]=-1;
		}
 
		// call the iterative version of the bvptree search algorithm 
		iterBvptSearch(root,Q[i],data,d,k);
	
		//printf("number of computed distances %d \n",distCount);
    
		/*printf("query %d nns are \n",i);
		for(j=0;j<k;j++)
		printf("%d ",NNs[j]);
		printf("\n"); */
	
		kthInd[i] = NNs[0];
		kthDist[i] = dToNNs[0];
		//printf("number of computed distances = %d\n",distCount);
		#ifdef USE_EXTERN_VARIABLES
			avgDistCount+=(double)distCount;
		#endif
	}
	#ifdef USE_EXTERN_VARIABLES
		avgDistCount/=(double)m;
	#endif
	
  //free(x);
  free(NNs);
  free(dToNNs);

}

void iterBvptSearch( TREENODE root, double *q, double **data, int d, int k ){
	int i;
	double divTemp;
	// use a stack to store unexplored nodes
	TREENODE *stack, node;	
	int sLength = 1;
	int stop = 0;

	stack = calloc( root->n,sizeof(node) );	// allocates memory for the stack
	// add the root to the stack
	stack[0] = root;
	
	while( !stop  && stack[0]!=NULL ){
		// pop the next node to be visited
		node = stack[sLength-1];
		stack[--sLength] = NULL;
		// the actual node is to be visited (intersect the query ball) and it is not a leaf
		while( !node->isLeaf ){
			if( needToExploreBoth(node,q,d,dToNNs[0]) ){
				if( !node->leftChild->isLeaf ){	// the children of the current node are not leaves (i.e. they have a well-defined vantage point)
					distCount+=2;
					node->leftChild->divToV = divergence(node->leftChild->v,q,d);
					node->rightChild->divToV = divergence(node->rightChild->v,q,d);
					// add both children to the stack sorted by their distance to the query and update node
					if(node->leftChild->divToV < node->rightChild->divToV){ 	//search left
						stack[sLength++] = node->rightChild;
						node = node->leftChild;							
					}
					else{
						stack[sLength++] = node->leftChild;
						node = node->rightChild;
					}
				}
				else{	// the children of the current node are leaves (explore first left, then right)
					stack[sLength++] = node->rightChild;
					node = node->leftChild;
				}
			}
			else{	// the query ball and the vantage point ball do not intersect
					// explore only the right subtree
				node->divToV = divergence(node->v,q,d);
				distCount++;
				/*if( node->divToV < node->R )
					node = node->leftChild;
				else*/
				node = node->rightChild;
			}
		}	
		// node is a leaf, therefore search it
		distCount+=node->n;							// update the overall number of divergence computations
		for(i=0;i<(node->n);i++){
			divTemp = divergence(data[node->inds[i]],q,d);
				if (NNs[0]==-1 || divTemp < dToNNs[0]){
					//put the new point on the "heap"
					insert(NNs,dToNNs,node->inds[i],divTemp,k);  			
				} 
		}
		//stop = checkStopCondition(distCount);	
	}
	free(stack);
}
// decides if both children of a Bregman ball are to be explored (by verifiying ball intersection)
int needToExploreBoth( TREENODE node, double *q, int d, double rSearch ){
	return bregmanBallIntersect( 0.0,1.0,node->v,q,d,node->R,rSearch,&distCount );
}
	