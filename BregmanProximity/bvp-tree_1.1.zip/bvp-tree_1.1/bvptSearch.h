#ifndef BVPT_SEARCH_H
#define BVPT_SEARCH_H

#include "bvptree.h"

void multiBvptSearch( TREENODE,double**,double**,int,int,int,int,int*,double* );

void iterBvptSearch( TREENODE,double*,double**,int,int );

int needToExploreBoth( TREENODE,double*,int,double );

#endif