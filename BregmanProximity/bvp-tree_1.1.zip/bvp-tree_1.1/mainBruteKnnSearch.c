#define MAIN_BRUTE_KNN_SEARCH_C

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "windows.h"
#include "utils.h"
#include "bvtIO.h"
#include "divergence.h"

#define NUM_SAVED_KNN 100

void processArgs(int,char**);

//global variables
char *datafile, *queryfile; 
char *knnfile;
int isKnnFile=0;
int n=-1, m=-1;
int d=-1;
int k=1;

// saves distances of each query to the first NUM_SAVED_KNN
int main(int argc, char** argv){ 
	int i,j;
	double **x, **q;
	double brutetime;
	double *dToNNs, **trueDToNNs;
	
	LARGE_INTEGER startCount, endCount, freqCount;
	BOOL isHrCounter, isStart, isEnd;
	isHrCounter = QueryPerformanceFrequency(&freqCount);

	printf("**** processing input arguments **** \n");
	processArgs(argc,argv);
	x = calloc(n,sizeof(double*));
	q = calloc(m,sizeof(double*));
  
	for(i=0;i<n;i++)
		x[i]=calloc(d,sizeof(double));                    
	for(i=0;i<m;i++)
		q[i]=calloc(d,sizeof(double));
	
	dToNNs = calloc(n,sizeof(double));
	trueDToNNs = calloc(m,sizeof(double*));
	for(i=0;i<m;i++)
		trueDToNNs[i]=calloc(NUM_SAVED_KNN,sizeof(double));
	
	printf("**** loading database points **** \n");
	readData(x,n,d,datafile);
	printf("**** loading query points **** \n");
	readData(q,m,d,queryfile);
       
	/* **************** COMPUTE BRUTE-FORCE KNN ***********/
	printf("**** brute-force search **** \n");
	if (isHrCounter)
		isStart = QueryPerformanceCounter(&startCount);
	for( i=0;i<m;i++ ){
		for( j=0;j<n;j++ )
			dToNNs[j] = divergence(x[j],q[i],d);
		qsort( dToNNs,n,sizeof(double),(compfn)compareDoubles );	// sort divergences
		for( j=0;j<NUM_SAVED_KNN;j++ )
			trueDToNNs[i][j] = dToNNs[j];
	}
	if (isHrCounter)
		isEnd = QueryPerformanceCounter(&endCount);
	if (isStart && isEnd){
		brutetime = timediff(startCount,endCount,freqCount);
		printf("**** brute search time elapsed = %6.6f s **** \n",brutetime);
	}
	
	// saves knn to file
	printf("**** saving ground truth to file **** \n");
	writeKnnDist( trueDToNNs,knnfile,m,NUM_SAVED_KNN );
	
	for( i=0;i<n;i++ )
		free(x[i]);
	free(x);
	for( i=0;i<m;i++ )
		free(q[i]);
	free(q);
	free(dToNNs);
	for(i=0;i<m;i++)
		free(trueDToNNs[i]);
	free(trueDToNNs);

	system("pause");
}

void processArgs(int argc, char**argv){
  int i=1;
  if(argc <= 1){
    printf("usage:\n bruteKnnSearch -f dataFile -q queryFile -n numPts -m numQueries -d dim -o outKnnFile [-k numNeighbors]\n");
    exit(0);
  }
  
  while(i<argc){
    if(!strcmp(argv[i], "-d"))
      d = atoi(argv[++i]);
    else if(!strcmp(argv[i], "-n"))
      n=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-m"))
      m=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-f"))
      datafile = argv[++i];
    else if(!strcmp(argv[i], "-q"))
      queryfile= argv[++i];
    else if(!strcmp(argv[i], "-o")){
      knnfile= argv[++i];
      isKnnFile=1;
    }
    else if(!strcmp(argv[i], "-k"))
      k=atoi(argv[++i]);
    else{
      fprintf(stderr,"unrecognized option.. exiting \n");
      exit(1);
    }
    i++;
  }
  
  if( n==-1 || m==-1 || d==-1 || datafile==NULL || queryfile==NULL || knnfile==NULL || knnfile==NULL ){
    fprintf(stderr,"more arguments needed.. exiting \n");
    exit(1);
  }

}  