#define MAIN_BVPT_SEARCH_C

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "math.h"
#include "windows.h"
#include "utils.h"
#include "bvptSearch.h"
#include "bvtIO.h"
#include "bvptree.h"
#include "divergence.h"

#ifndef NUM_SAVED_KNN 
	#define NUM_SAVED_KNN 100
#endif

void processArgs(int,char**);

//global variables
char *treefile, *datafile, *queryfile, *truthfile; 
char *resultsFile;
int isOutfile=0;
int isTruthFile=0;
int isResFile = 0;
int n=-1, m=-1;
int d=-1;
int k=1;
double avgDistCount = 0.0;
//double avgNumCloserPerError = 0.0;
//double avgDistCloserPerError = 0.0;
//double avgDistCount = 0.0;
//double avgExploredLeaf;
//double avgNumExploredNodes = 0.0;

int main(int argc, char** argv){ 
	int i,j;
	double **x, **q;
	double *kthDist;
	int *kthInd;
	double bvptime;
	int *NNs;
	int errCount = 0;	
	double brutetime;
	double **trueDToNNs;

	TREENODE root;
	LARGE_INTEGER startCount, endCount, freqCount;
	BOOL isHrCounter, isStart, isEnd;
	isHrCounter = QueryPerformanceFrequency(&freqCount);

	printf("**** processing input arguments **** \n");
	processArgs(argc,argv);
	x = calloc(n,sizeof(double*));
	q = calloc(m,sizeof(double*));
  
	for(i=0;i<n;i++)
		x[i]=calloc(d,sizeof(double));                    
	for(i=0;i<m;i++)
		q[i]=calloc(d,sizeof(double));
	kthDist = calloc(m,sizeof(double));
	kthInd = calloc(m,sizeof(int));
	NNs = calloc(n,sizeof(int));
	trueDToNNs = calloc(m,sizeof(double*));
	for(i=0;i<m;i++)
		trueDToNNs[i] = calloc(NUM_SAVED_KNN,sizeof(double));
	
	printf("**** loading database points **** \n");
	readData(x,n,d,datafile);
	printf("**** loading query points **** \n");
	readData(q,m,d,queryfile);
       
	/* ************** VISIT THE BBTREE *************************/  
	printf("**** loading vantage point tree **** \n");
	root = readTree(treefile);	//Retrieve the bbtree
	
	printf("**** searching vantage point tree **** \n");
	if (isHrCounter)
		isStart = QueryPerformanceCounter(&startCount);
	multiBvptSearch( root,q,x,n,d,m,k,kthInd,kthDist);
	if (isHrCounter)
		isEnd = QueryPerformanceCounter(&endCount);
	if (isStart && isEnd){
		bvptime = timediff(startCount,endCount,freqCount);
		printf("**** bvp tree search time elapsed = %6.6f s **** \n",bvptime);
	}
	
	/* **************** VERIFY CORRECTNESS OF RESULTS ***********/
	printf("**** loading ground-truth data **** \n");
	readKnnDist( trueDToNNs,m,NUM_SAVED_KNN,truthfile );
	for( i=0;i<m;i++ ){
		if( !( kthDist[i]==trueDToNNs[i][0]) )
			errCount++;
	}
	printf("%d queries performed, %d errors\n",m,errCount);

	/* **************** WRITE RESULTS OF THE EXPERIMENT TO FILE *****/
	//saves results of the experiment
	if(isResFile)
		writeResults ( resultsFile,3,avgDistCount,(double)errCount,bvptime );	// add construction cost and time

	
	for( i=0;i<n;i++ )
		free(x[i]);
	free(x);
	for( i=0;i<m;i++ )
		free(q[i]);
	free(q);
	free(kthDist);
	free(kthInd);
	free(NNs);
	for(i=0;i<m;i++)
		free(trueDToNNs[i]);
	free(trueDToNNs);

	system("pause");
}

void processArgs(int argc, char**argv){
  int i=1;
  if(argc <= 1){
    printf("usage:\n bvptSearch -f dataFile -t treeFile -q queryFile -n numPts -m numQueries -d dim -h truthfile -r resultStatsFile [-k numNeighbors]\n");
    exit(0);
  }
  
  while(i<argc){
    if(!strcmp(argv[i], "-d"))
      d = atoi(argv[++i]);
    else if(!strcmp(argv[i], "-n"))
      n=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-m"))
      m=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-f"))
      datafile = argv[++i];
    else if(!strcmp(argv[i], "-t"))
      treefile = argv[++i];
    else if(!strcmp(argv[i], "-q"))
      queryfile= argv[++i];
	else if(!strcmp(argv[i], "-h")){
      truthfile= argv[++i];
      isTruthFile=1;
    }
	else if(!strcmp(argv[i], "-r")){
      resultsFile= argv[++i];
      isResFile=1;
    }
    else if(!strcmp(argv[i], "-k"))
      k=atoi(argv[++i]);
    else{
      fprintf(stderr,"unrecognized option.. exiting \n");
      exit(1);
    }
    i++;
  }
  
  if(m==-1 || d==-1 || treefile==NULL || queryfile==NULL || truthfile==NULL || resultsFile==NULL){
    fprintf(stderr,"more arguments needed.. exiting \n");
    exit(1);
  }

}  