#define BB_INTERSECT_C

#include "divergence.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// verifies if two Bregman balls intersect or not by dichotomic search
int bregmanBallIntersect( double lambdaMin, double lambdaMax, double *v, double *q, int d, double Rv, double Rq, long *nDiv ){
	double lambda;
	double *x;
	double xToQ, xToV, qToV, vToQ;
	int nIter = 0;
	//nDiv = 0;
	
	x = calloc( d,sizeof(double) );
		
	// verifies if the two balls are concentric
	qToV = divergence( q,v,d );
	//printf("dF(q,v) = %f\n",qToV);
	vToQ = divergence( v,q,d );	
	//printf("dF(v,q) = %f\n",vToQ);
	*nDiv+=2;
	if( vToQ < Rq || qToV < Rv ){
		free(x);
		//printf("iterations = %d\t divergences = %ld\n",nIter,*nDiv);
		return 1;
	}
	
	while(1){
		lambda = 0.5*( lambdaMin + lambdaMax );
		geodesicPoint( x,q,v,d,lambda );
		xToQ = divergence( x,q,d );
		//printf("%d dF(x,q) = %f\n",nIter,xToQ);
		xToV = divergence( x,v,d );
		//printf("%d dF(x,v) = %f\n",nIter,xToV);
		*nDiv+=2;
		
		if( xToQ < Rq && xToV > Rv )	// the left point of the interval is not in Bv
			lambdaMin = lambda;	
		if( xToQ > Rq && xToV < Rv )	// the right point of the interval is not in Bq
			lambdaMax = lambda;
		if( xToQ > Rq && xToV > Rv ){	// the actual point is outside the two balls
			free(x);
			//printf("iterations = %d\t divergences = %ld\n",nIter,*nDiv);
			return 0;
		}
		if( xToQ < Rq && xToV < Rv ){	// the actual point is into both balls
			free(x);
			//printf("iterations = %d\t divergences = %ld\n",nIter,*nDiv);
			return 1;
		}
		nIter++;
	}
}
