#ifndef BVT_IO_H
#define BVT_IO_H

#include "stdio.h"
#include "bvptree.h"

void readData( double**,int,int,char* );

void writeTree( TREENODE,int,char* );

void writeNode( TREENODE,int,FILE* );

TREENODE readTree(char*);

TREENODE readNode( int,FILE* );

void writeResults ( char*,int,... );

void writeKnnDist( double**,char*,int,int );

void readKnnDist( double**,int,int,char* );

#endif