#define BVT_IO_C

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "bvtIO.h"
#include "bvptree.h"

// read a matrix of data from file
void readData( double** x, int n, int d, char* file ){
	int i,j;
	float t;
	FILE *fp = fopen(file,"r");
  
	if(fp==NULL){
		fprintf(stderr,"error opening data file.. exiting\n");
		exit(1);
	}

	for(i=0;i<n;i++){
		for(j=0;j<d;j++){
			if(fscanf(fp,"%f ", &t)==EOF){
				fprintf(stderr,"error reading data file.. exiting \n");
				exit(1);
			}
			x[i][j]=(double)t;
		}
	}
	fclose(fp);
}

// saves a BVPtree to file
void writeTree( TREENODE root, int d, char* file ){
	FILE *fp = fopen( file,"w" );		// opens the file in only write mode
	if( fp==NULL ){
		fprintf(stderr,"unable to open output tree file \n");
		return;
	}
	fprintf(fp,"%d \n",d);	/* writes the dimension of data*/
	writeNode(root,d,fp);
	fclose(fp);
}

// saves a single treenode to tree file
void writeNode( TREENODE node, int d, FILE* fp ){
	int i;
	
	fprintf( fp,"%d %d %d\n", node->n, node->depth, node->isLeaf );
	if(!(node->isLeaf)){
		fprintf( fp,"%e\n",node->R );
		for ( i=0;i<d;i++ )
			fprintf( fp,"%e ",node->v[i] );	/* writes the vantage point*/
		fprintf( fp,"\n" );
		for ( i=0;i<d;i++ )
			fprintf( fp,"%e ",node->gradV[i] );	/* writes the gradient of vantage point*/
		fprintf( fp,"\n" );
		writeNode( node->leftChild,d,fp );
		writeNode( node->rightChild,d,fp );
	}
	else{
		for( i=0;i<node->n;i++ )
			fprintf( fp,"%d ",node->inds[i]);
		fprintf( fp,"\n" );
	}
	
}

// reads a BVPtree from file
TREENODE readTree(char* file){
	int d;
  
	FILE *fp = fopen( file,"r" );		// opens the file in only read mode
	if(fp==NULL){
		fprintf(stderr,"unable to open input tree file... exiting \n");
		exit(1);
	}
	fscanf(fp,"%d \n",&d);		/* read the dimension of data*/
	return readNode(d,fp);
	fclose(fp);
}

// reads fields of a single node from file
TREENODE readNode( int d, FILE* fp ){
	//declarations
	int i;
	float temp;
	int t;
	TREENODE node;

	// allocations
	node = (TREENODE)calloc( 1,sizeof(treenode) );		/* allocates memory for the node*/

	// reads values that are common to leaves and non-leaves
	fscanf( fp,"%d %d %d\n", &(node->n), &(node->depth), &(node->isLeaf) );
	if( !(node->isLeaf) ){
		fscanf( fp,"%f\n",&temp );
		node->R = (double)temp;
		node->v = calloc(d,sizeof(double));
		node->gradV = calloc(d,sizeof(double));
		
		for( i=0;i<d;i++ ){
			fscanf( fp,"%f ",&temp );			/* reads the center*/
			node->v[i] = (double)temp;
		}
		fscanf(fp,"\n");
		for( i=0;i<d;i++ ){
			fscanf( fp,"%f ",&temp );			/* reads the center*/
			node->gradV[i] = (double)temp;
		}
		fscanf(fp,"\n");
		node->leftChild = readNode(d,fp);
		node->rightChild = readNode(d,fp);
	}
	else{
		node->inds = calloc(node->n,sizeof(double));
		for( i=0;i<node->n;i++ ){
			fscanf( fp,"%d ",&t );			/* reads the center*/
			node->inds[i] = t;
		}
		fscanf(fp,"\n");	
	}
	return node;
}

//saves experiment results (as doubles) to file
void writeResults ( char* file, int nArgs, ...){
	int i;
	double actual;
	va_list vl;
	FILE *fp = fopen( file,"w" );		// opens the file in only write mode
	if(fp==NULL){
		fprintf(stderr,"unable to open input results file... exiting \n");
		exit(1);
	}
	va_start(vl,nArgs);
	for ( i=0;i<nArgs;i++){
		actual = va_arg(vl,double);
		fprintf( fp,"%e ",actual );
	}
	fprintf( fp,"\n" );
	va_end(vl);
	fclose(fp);
}

//saves distances to the first k knn to file (for m queries)
void writeKnnDist( double **knnDist, char* file, int m, int k ){
	int i, j;
	FILE *fp = fopen( file,"w" );		// opens the file in only write mode
	if( fp==NULL ){
		fprintf(stderr,"unable to open ground truth file \n");
		return;
	}
	for( i=0;i<m;i++ ){
		for( j=0;j<k;j++ )
			fprintf( fp,"%e ",knnDist[i][j] );
		fprintf( fp,"\n" );
	}
	fclose(fp);
}

// read a matrix of data from file
void readKnnDist( double** knnDist, int m, int k, char* file ){
	int i,j;
	float t;
	FILE *fp = fopen(file,"r");
  
	if(fp==NULL){
		fprintf(stderr,"error opening ground truth file.. exiting\n");
		exit(1);
	}

	for(i=0;i<m;i++){
		for(j=0;j<k;j++){
			if(fscanf(fp,"%e ", &t)==EOF){
				fprintf(stderr,"error reading ground truth file.. exiting \n");
				exit(1);
			}
			knnDist[i][j]=(double)t;
		}
	}
	fclose(fp);
}