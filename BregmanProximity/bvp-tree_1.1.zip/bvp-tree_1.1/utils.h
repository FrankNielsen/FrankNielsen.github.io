#ifndef UTILS_H
#define UTILS_H

#define _CRT_RAND_S

int randomInt(int);

double randomDouble(double);

double timediff( LARGE_INTEGER,LARGE_INTEGER,LARGE_INTEGER );

void insert( int*,double*,int,double,int );

typedef int (*compfn)(const void*, const void*);

int compareDoubles( double*, double* );

#endif