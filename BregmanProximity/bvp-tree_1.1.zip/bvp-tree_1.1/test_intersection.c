#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "bregmanBallIntersect.h"

int main(){
	int res,d,i;
	double *v, *q, Rv, Rq;
	float t;
	
	printf("dimension:\n");
	scanf("%d",&d);
	
	v = calloc(d,sizeof(double));
	q = calloc(d,sizeof(double));
	
	printf("v:\n");
	for( i=0;i<d;i++ ){
		scanf("%f",&t);
		v[i] = (double)t;
	}
		
	printf("q:\n");
	for( i=0;i<d;i++ ){
		scanf("%f",&t);
		q[i] = (double)t;
	}
	
	printf("Rv:\n");
	scanf("%f",&t);
	Rv = (double)t;
	printf("Rq:\n");
	scanf("%f",&t);
	Rq = (double)t;
	
	res = bregmanBallIntersect( 0.0,1.0,v,q,d,Rv,Rq );
	printf("Intersection = %d\n",res);
	
	free(q);
	free(v);
	
	system("pause");
	return 0;

}