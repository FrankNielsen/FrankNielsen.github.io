#ifndef EXTERN_MAIN_BUILD_H
#define EXTERN_MAIN_BUILD_H

extern int maxDepth;	// used for evaluating the maximum depth of the tree
extern double sumLeafDepth;	// each node gives as a contribution the number of data stored in it times its depth
//extern double NumChildrenOfNonLeaves;
extern int numNonLeafNodes;
extern int numLeafNodes;
extern int constructionCost;

#endif