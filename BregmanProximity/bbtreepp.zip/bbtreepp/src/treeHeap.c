/* min-priority queue used in iterative binary bbtree++ search
temporarily unexplored nodes are added to the heap so that the nearest node to the actual query is always the first element in the min-heap*/

// the min-heap is implemented by an array of structures, each containing a pointer to a node and the query-to-node center distance as a key

#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include "tree.h"
#include "treeHeap.h"

// declare an array of struct for storing the heap
// HEAPTREENODE heap[MAX_DIM_HEAP];	// replace with allocation by pointer

// returns the index of the parent of the heap element ind
int heapParent( int ind ){
	return (int)floor( (ind-1)/2 );
}

// returns the index of the left child of the heap element ind
int heapLeftChild( int ind ){
	return 2*ind+1;
}

// returns the index of the right child of the heap element ind
int heapRightChild( int ind ){
	return 2*ind+2;
}

/* lets the value at index ind float down in the min-heap so that the subtree rooted at index ind becomes a max-heap
(it assumes that both LEFT(ind) and RIGHT(ind) are max-heaps)*/
void minHeapify( HEAPTREENODE *heap, int heapSize, int ind ){
	int l,r,smallest;
	
	l = heapLeftChild(ind);
	r = heapRightChild(ind);
	if( l <= heapSize && heap[l].key < heap[ind].key )
		smallest = l;
	else
		smallest = ind;
	if( r <= heapSize && heap[r].key < heap[smallest].key )
		smallest = r;
	if( smallest!=ind ){
		heapNodeExchange( heap,ind,smallest );
		minHeapify( heap,heapSize,smallest );
	}
}

/* exchange position of heap elements at indices ind1 and ind2*/
void heapNodeExchange( HEAPTREENODE* heap, int ind1, int ind2 ){
	TREENODE* n;	// temporary variables
	double k;
	
	n = heap[ind1].node;
	k = heap[ind1].key;
	heap[ind1].node = heap[ind2].node;
	heap[ind1].key = heap[ind2].key;
	heap[ind2].node = n;
	heap[ind2].key = k;
}

/* Removes and returns the element of the heap with the minimum key value*/
TREENODE* heapExtractMin( HEAPTREENODE* heap, int *heapSize){
	TREENODE* min;
	
	if(*heapSize<1)
		printf("error: heap underflow!\n");
	min = heap[0].node;
	
	(*heapSize)--;
	heap[0].node = heap[*heapSize].node;
	heap[0].key = heap[*heapSize].key;
	minHeapify( heap,*heapSize,0 );
	return min;
}

/* Removes and returns the last element of the queue (the heap is used as a non-priority queue)*/
TREENODE* heapExtractLastElement( HEAPTREENODE* heap, int *heapSize){
	TREENODE* last;
	
	if(*heapSize<1)
		printf("error: heap underflow!\n");
	(*heapSize)--;
	last = heap[*heapSize-1].node;
	
	return last;
}

/* decreases the key of the heap element at index ind by assigning to it the value key 
(it is assumed that it is not larger than its actual value)*/
void heapDecreaseKey( HEAPTREENODE* heap, int ind, double key ){
	int parent;
	if( key > heap[ind].key )
		printf("error: new key is larger than the actual key\n");
	heap[ind].key = key;
	parent = heapParent(ind);
	while( ind > 0 && heap[parent].key > heap[ind].key ){
		heapNodeExchange( heap,ind,parent );
		ind = parent;
		parent = heapParent(ind);
	}
}
/* inserts a new element into the min-priority queue*/
void minHeapInsert( HEAPTREENODE* heap, int *heapSize, TREENODE* node, double key ){
	heap[*heapSize].node = node;
	heap[*heapSize].key = HUGE_VAL;
	(*heapSize)++;
	heapDecreaseKey( heap,(*heapSize)-1,key );
}

/* following functions are not yet used */
/* inserts a new element at the end of the queue without updating the min-heap property (the heap is used for a non-priority queue)*//*
void endHeapInsert( HEAPTREENODE* heap, int *heapSize, TREENODE* node, double key ){
	(*heapSize)++;
	heap[*heapSize].node = node;
	heap[*heapSize].key = key;
}*/
