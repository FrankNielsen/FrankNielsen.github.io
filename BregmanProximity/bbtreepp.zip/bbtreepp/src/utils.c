//#include<stdarg.h>
//#define _CRT_RAND_S
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<time.h>
#include "utils.h"
//#include "tree.h"
#include "listUtils.h"

/* measures the elapsed time*/
double timediff(struct timeval start, struct timeval end){
	return (double)(end.tv_sec+end.tv_usec/1e6 - start.tv_sec - start.tv_usec/1e6); 
}

void insert(int* NNs, double* dtoNNs, int newNN, double dNNnew, int k){
  
  int i=0;
  while (i < (k-1) && dtoNNs[i+1]>dNNnew){
    NNs[i]=NNs[i+1];
    dtoNNs[i]=dtoNNs[i+1];
    i++;
  }
  if ( dtoNNs[i]>dNNnew ) {
  NNs[i]=newNN;
  dtoNNs[i]=dNNnew;
  }
}
