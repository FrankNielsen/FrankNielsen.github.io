#include <stdlib.h>
#include <stdio.h>
#include "bbtreeIO.h"

/* saves results of the experiment in a text file*/
void writeResults(char* file, int a, int b, double c, double d, int e, int f, double g){
	FILE *fp = fopen( file,"a" );		/* opens the file in only write mode*/
	if( fp==NULL ){
		fprintf(stderr,"unable to open output file \n");
		return;
	}
	fprintf(fp,"%d %d %f %f %d %d %f\n",a,b,c,d,e,f,g);	/* writes results*/
	fclose(fp);
}

/* reads input dataset from a file*/
void readData(double **x, int n, int d, char* file){
	int i,j;
	float t;
	FILE *fp = fopen(file,"r");
  
	if(fp==NULL){
		fprintf(stderr,"error opening file.. exiting\n");
		exit(1);
	}

	for(i=0;i<n;i++){
		for(j=0;j<d;j++){
			if(fscanf(fp,"%f ", &t)==EOF){
				fprintf(stderr,"error reading file.. exiting \n");
				exit(1);
			}
			x[i][j]=(double)t;
		}
	}
	fclose(fp);
}

/* saves a bbtree++ in a text file*/
void writeTree(TREENODE* root,int d, char* file){
	FILE *fp = fopen( file,"w" );		/* opens the file in only write mode*/
	if( fp==NULL ){
		fprintf(stderr,"unable to open output file \n");
		return;
	}
	fprintf(fp,"%d \n",d);	/* writes the dimension of data*/
	writeNode(root,d,fp);
	fclose(fp);
}

/* writes fields of a single node structure*/
void writeNode(TREENODE* node, int d, FILE* fp){
	int i;
	TREENODE_LIST_PT list;		/* list is used to point to the elements of the children list*/
	treeNodeStartList(&list);	/* it is inizialized to the NULL pointer*/
	
	/* writes the number of points, the radius, isLeaf, the depth of the actual node*/
	fprintf( fp,"%d %f %d %d %d\n", node->n, node->R, node->isLeaf, node->depth, node->nChildren );  
	for (i=0;i<d;i++)
		fprintf( fp,"%f ",node->mu[i] );	/* writes the centroid*/
	fprintf(fp,"\n");
	for (i=0;i<d;i++)
		fprintf( fp,"%f ",node->gradMu[i] );	/* writes the gradient at the centroid*/
	fprintf(fp,"\n");
	if(!(node->isLeaf)){
		list = node->children;
		while( list!= NULL ){
			writeNode( list->treeNodePt,d,fp );
			list = list->next;
		}  
	}
	for (i=0;i<node->n;i++){
		fprintf(fp,"%d ",node->inds[i]);	/* writes indices of data stored in the actual node*/
	}
	fprintf(fp,"\n");
}

/* read a bbtree++ from a file*/
TREENODE* readTree(char*file){
	int d;
  
	FILE *fp = fopen( file,"r" );		/* opens the file in only read mode*/
	if(fp==NULL){
		fprintf(stderr,"unable to open input file... exiting \n");
		exit(1);
	}
	fscanf(fp,"%d \n",&d);		/* read the dimension of data*/
	return readNode(d,fp);
	fclose(fp);
}

/* read fields of a single node structure*/
TREENODE* readNode( int d,FILE* fp ){
	//declarations
	int i;
	float temp;
	TREENODE_QUEUE queue;			/* queue is used to enqueue the childrens of the actual node (the first read must be the first written) */
	TREENODE *nodept = NULL;		/* it is used as an alias to push a node pointer from the queue to the children list*/
	TREENODE* node;

	// allocations
	treeNodeStartQueue(&queue);		/* it is inizialized to the empty queue*/
	node = (TREENODE*)calloc( 1,sizeof(TREENODE) );		/* allocates memory for the node*/

	/* reads number of points, radius, isLeaf, depth and number of children of the actual node*/
	fscanf( fp,"%d %f %d %d %d\n", &(node->n), &temp, &(node->isLeaf), &(node->depth), &(node->nChildren) );
	node->mu = calloc(d,sizeof(double));	
	node->gradMu = calloc(d,sizeof(double));
	node->R = (double)temp;

	for(i=0;i<d;i++){
		fscanf( fp,"%f ",&temp );			/* reads the center*/
		node->mu[i]=(double)temp;
	}
	fscanf(fp,"\n");
	for(i=0;i<d;i++){
		fscanf(fp,"%f ",&temp);				/* reads the gradient at the center*/
		node->gradMu[i]=(double)temp;
	}
	fscanf(fp,"\n");
  
	treeNodeStartList( &(node->children) );		/* the list of children is inizialized to the empty list also for leaf nodes*/
	if (!(node->isLeaf)){
		for( i=0;i<node->nChildren;i++ )
			treeNodeEnQueue( &queue,readNode(d,fp) );	/* adds the i-th child at the end of the queue*/
		while( queue.first!=NULL ){
			treeNodeDeQueue( &queue,&nodept );			/* retrieves the first element of the queue*/
			treeNodeListPush( &(node->children),nodept );	/*and adds it at the head of the children list*/
		}
	}
	node->inds = calloc(node->n,sizeof(int));
	for(i=0;i< node->n;i++){
		fscanf( fp,"%d ",&(node->inds[i]) );	/* reads the indices of stored points*/
	}
	fscanf(fp,"\n");
	return node;
}
