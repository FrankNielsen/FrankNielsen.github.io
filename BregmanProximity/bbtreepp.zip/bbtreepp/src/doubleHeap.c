#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "doubleHeap.h"

void heapArrayDecreaseKey( double *keys, int *inds, int h, double key ){
	int parent, tempInd;
	double tempKey;
	if( key > keys[h] )
		printf("error: new key is larger than the actual key\n");
	keys[h] = key;
	parent = heapParent(h);
	while( h > 0 && keys[parent] > keys[h] ){
		// exchange the two elements
		tempKey = keys[parent];
		keys[parent] = keys[h];
		keys[h] = tempKey;
		tempInd = inds[parent];
		inds[parent] = inds[h];
		inds[h] = tempInd;
		h = parent;
		parent = heapParent(h);
	}
}

/* /* lets the value at index h float down in the min-heap so that the subtree rooted at index ind becomes a min-heap
(it assumes that both LEFT(ind) and RIGHT(ind) are min-heaps)*/
void minArrayHeapify( double *keys, int *inds, int heapSize, int h ){
	int l,r,smallest,tempInd;
	double tempKey;
	
	l = heapLeftChild(h);
	r = heapRightChild(h);
	if( l < heapSize && keys[l] < keys[h] )
		smallest = l;
	else
		smallest = h;
	if( r < heapSize && keys[r] < keys[smallest] )
		smallest = r;
	if( smallest!=h ){
		// exchange the two elements
		tempKey = keys[smallest];
		keys[smallest] = keys[h];
		keys[h] = tempKey;
		tempInd = inds[smallest];
		inds[smallest] = inds[h];
		inds[h] = tempInd;
		minArrayHeapify( keys,inds,heapSize,smallest );
	}
}

void minArrayHeapSort( double *keys, int *inds, int heapSize ){
	int i, tmpInd;
	double tmpKey;
	buildMinArrayHeap( keys,inds,heapSize );
	for( i=heapSize-1;i>0;i--){
		// exchange elements 0 and i
		tmpKey = keys[0];
		tmpInd = inds[0];
		keys[0] = keys[i];
		inds[0] = inds[i];
		keys[i] = tmpKey;
		inds[i] = tmpInd;
		heapSize--;
		minArrayHeapify( keys,inds,heapSize,0 );
	}	
}

void buildMinArrayHeap( double *keys, int *inds, int length ){
	int i;
	for( i = (int)(floor((double)(length/2))-1.0); i>=0; i-- )
		minArrayHeapify( keys,inds,length,i );
}

