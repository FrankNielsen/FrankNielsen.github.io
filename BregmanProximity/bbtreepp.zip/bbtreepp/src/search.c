#ifndef SEARCH_C
#define SEARCH_C

/* choose between classical and hessian dichotomic search:
	- HALVE_GEODESIC
	- HESSIAN_HALVE_GEODESIC
*/
#define HALVE_GEODESIC

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "divergence.h"
#include "tree.h"
#include "search.h"
#include "utils.h"
#include "treeHeap.h"
#include "listUtils.h"
#define LAMBDA_PRECISION 0.00001

double *x;  //temp variables used throughout
long distCount;
double *dtoNNs;
int *NNs;
double *xMin, *xMax, *hesMin, *hesMax;
extern double avgDistCount;
int numExploredLeaf;
extern double avgExploredLeaf;
extern double avgNumExploredNodes;

/*Performs the search of the k-th nearest neighbor for m query points*/
void multisearch(TREENODE* root, double **Q, double**data, int n, int d, int m, int k, int *kthInd, double *kthDist, int maxNumExploredLeaf){
  
	int i,j;
	double* gradQ;
	x = calloc(d,sizeof(double));
	xMin = calloc( d,sizeof(double) );
	xMax = calloc( d,sizeof(double) );
	hesMin = calloc( d,sizeof(double) );
	hesMax = calloc( d,sizeof(double) );
	gradQ = calloc(d,sizeof(double));
	dtoNNs = calloc(k,sizeof(double));
	NNs = calloc(k,sizeof(int));

	//Note that dtoNNs and NNs should really be implemented using a 
	//efficient heap structure.  They are currently just kept as sorted
	//arrays, which is probably fine if k is small.

	for(i=0;i<m;++i){
		/* inizialize arrays of the k nearest neighbors */
		distCount=0;
		numExploredLeaf=0;
		for(j=0;j<k;j++){
			dtoNNs[j]=HUGE_VAL;
			NNs[j]=-1;
		}        
		grad( gradQ,Q[i],d );
		/* call the iterative version of the search algorithm */
		iterSearch(root,Q[i],gradQ,data,d,k,maxNumExploredLeaf);
				
		//printf("number of computed distances %d \n",distCount);
		/*printf("query %d nns are \n",i);
		for(j=0;j<k;j++)
		printf("%d ",NNs[j]);
		printf("\n"); */
	
		kthInd[i] = NNs[0];
		kthDist[i] = dtoNNs[0];
		avgDistCount+=distCount;
		avgExploredLeaf+=numExploredLeaf;
  }
	
	avgDistCount/=m;
	avgExploredLeaf/=m;
	
	free(x);
	free(xMin);
	free(xMax);
	free(hesMin);
	free(hesMax);
	free(gradQ);
	free(NNs);
	free(dtoNNs);

}

void iterSearch(TREENODE *root, double *q, double *gradQ, double**data, int d, int k, int maxNumExploredLeaf){
  
	TREENODE *node;			
	double divTemp;
	int i;
	int subQueueSize;
	int heapSize = 0;
	int stop = 0;
	LIST_NODE *nodeChild;
	HEAPTREENODE *subQueue;
	int isToBeVisited = 0;
		
	HEAPTREENODE *queue;	// declares and allocates memory for a min-priority queue used during iterative search
	queue = (HEAPTREENODE*)calloc( root->n,sizeof(HEAPTREENODE) );	
	if(queue==NULL)
		printf("Impossible to allocate memory for the queue\n");
	
	nodeChild = calloc( 1,sizeof(LIST_NODE) );
	minHeapInsert( queue,&heapSize,root,0.0 );		// adds the root to the queue(the key value is not important because the root is always the first node retrieved from the queue)
	while ( stop==0 && heapSize>0 ){				// while there is at least one node to be explored and the stop condition has not been reached
		node = heapExtractMin( queue,&heapSize );
		isToBeVisited = needToExplore( node,q,d,dtoNNs[0] );
		avgNumExploredNodes++;
		// the actual node has to be visited and is not a leaf
		while( isToBeVisited && ( !node->isLeaf ) ){
			// go down towards a leaf
			// use a subQueue for only children of the actual node
			subQueue = &(queue[heapSize]);
			subQueueSize = 0;
			treeNodeListHeadCopy( node->children,nodeChild );		// retrieves the first child node			
			for( i=0;i<node->nChildren;i++ ){
				nodeChild->treeNodePt->divQToMu = divergence( q,nodeChild->treeNodePt->mu,d );
				distCount++;
				minHeapInsert( subQueue,&subQueueSize,nodeChild->treeNodePt,nodeChild->treeNodePt->divQToMu );	//push each child into the subqueue and retrieve the first after reordering (this is the subtree that has to be explored)
				treeNodeListHeadCopy( nodeChild->next,nodeChild );		// retrieves the following child node
			}
			heapSize += node->nChildren-1;						// update the size of the overall queue
			node = heapExtractMin( subQueue,&subQueueSize );	// extracts the min element from the subqueue
		}

		if( isToBeVisited ){
			// the actual node is a leaf: visit it
			distCount+=node->n;							// update the overall number of divergence computations
			for( i=0;i<(node->n);i++ ){
				divTemp = divergence( data[node->inds[i]],q,d );
				if ( NNs[0]==-1 || divTemp < dtoNNs[0] ){
				//put the new point into the vector of the k nearest neighbors
				insert(NNs,dtoNNs,node->inds[i],divTemp,k);  			
				} 
		    }
			numExploredLeaf++;
			stop = checkStopCondition(numExploredLeaf,maxNumExploredLeaf);
			minHeapify( queue,heapSize,0 );
		}	
	}
	free(queue);
}

#ifdef HALVE_GEODESIC
// classic projection based on halving interval [lambdaMin,lambdaMax]
int needToExplore( TREENODE *node, double *q, int d, double qToActualKnnDist ){
	int nIter;
	double lambda, lambdaMin, lambdaMax, xToMu, xToQ, lbnd;
		
	lambdaMin = 0.0;
	lambdaMax = 1.0;
	nIter = 0;

	if( node->divQToMu < node->R || node->divQToMu < qToActualKnnDist)
		return 1;
		
	while(1){
		/*explores the node if the query is close enough to the ball projection*/
		if( (lambdaMax-lambdaMin) < LAMBDA_PRECISION )
			return 1;
		lambda = 0.5*(lambdaMin+lambdaMax);		// halve the interval

		// if the actual x is not close enough to the ball projection
		geodesicPoint( x,node->mu,q,d,lambda );	// finds the corresponding point on the geodesic
		xToMu = divergence( x,node->mu,d );	// for an asymmetric divergence D(x||mu) is coherent with how the radius is computed
		xToQ = divergence( x,q,d );
		distCount+=2;
		lbnd = xToQ + ( 1.0/lambda -1.0 )*( xToMu - node->R );
		
		/*prunes the node if the boundary of the ball can't be closer to the query than the actual kNN candidate (lower bound)*/
		if( qToActualKnnDist < lbnd ){
			return 0;
		}
			
		/*if the actual estimation of x is outside the ball*/
		if( xToMu > node->R ){
			lambdaMax = lambda;
		}
		/*if the actual estimation of x is inside the ball*/
		else if( xToQ < qToActualKnnDist ){
			return 1;
		}
		else{
			lambdaMin = lambda;
		}
		nIter++;			
	}
	
}

#endif


#ifdef HESSIAN_HALVE_GEODESIC
// classic projection based on halving interval [lambdaMin,lambdaMax]
int needToExplore( TREENODE *node, double *q, int d, double qToActualKnnDist ){
	int nIter, i;
	double lambda, lambdaMin, lambdaMax, xToMu, xToQ, lbnd;
	double l2hesMin, l2hesMax;
	
	lambdaMin = 0.0;
	lambdaMax = 1.0;
	nIter = 0;
	
	if( node->divQToMu < node->R || node->divQToMu < qToActualKnnDist)
		return 1;
	
	while(1){
		/*explores the node if the query is close enough to the ball projection*/
		if( (lambdaMax-lambdaMin) < LAMBDA_PRECISION )
			return 1;
			
		// actual extrema of the geodesic interval
		geodesicPoint( xMin,node->mu,q,d,lambdaMin );
		geodesicPoint( xMax,node->mu,q,d,lambdaMax );
		hessian( hesMin,xMin,d );
		hessian( hesMax,xMax,d );
		// computes the squared norm of the hessian at extrema
		l2hesMin = 0.0;
		l2hesMax = 0.0;
		for( i=0;i<d;i++ ){
			l2hesMin += hesMin[i];
			l2hesMax += hesMax[i];
		}
		lambda = lambdaMin + ( l2hesMax/(l2hesMax+l2hesMin) )*( lambdaMax-lambdaMin );
		
		// if the actual x is not close enough to the ball projection
		geodesicPoint( x,node->mu,q,d,lambda );	// finds the corresponding point on the geodesic
		xToMu = divergence( x,node->mu,d );	// for an asymmetric divergence D(x||mu) is coherent with how the radius is computed
		xToQ = divergence( x,q,d );
		distCount+=2;
		lbnd = xToQ + ( 1.0/lambda -1.0 )*( xToMu - node->R );
		
		/*prunes the node if the boundary of the ball can't be closer to the query than the actual kNN candidate (lower bound)*/
		if( qToActualKnnDist < lbnd ){
			return 0;
		}
			
		/*if the actual estimation of x is outside the ball*/
		if( xToMu > node->R ){
			lambdaMax = lambda;
		}
		/*if the actual estimation of x is inside the ball*/
		else if( xToQ < qToActualKnnDist ){
			return 1;
		}
		else{
			lambdaMin = lambda;
		}
		nIter++;			
	}
}

#endif


int checkStopCondition( int explored, int maxNumExplored ){
	// check if the tree search has to be stopped based on the number of leaf nodes explored
	// still temporary: never stop the search
	//return 0;
	if( explored >= maxNumExplored )
        return 1; 	
    return 0;
}


#endif
