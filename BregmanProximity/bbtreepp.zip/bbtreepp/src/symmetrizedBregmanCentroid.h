#ifndef SBC_H
#define SBC_H

void distributionToMultinomial( double*,double*,int );

void multinomialToDistribution( double*,double*,int );

void symmetrizedBregmanCentroidGeodesicWalk( double*, double**, int, int );

#endif