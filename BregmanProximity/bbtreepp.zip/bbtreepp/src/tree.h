#ifndef TREE_H
#define TREE_H

#include "newTypes.h"

TREENODE* buildTree(double**,int,int,int );

TREENODE* recSubtreeBuild( double**,int*,int,int,int,int,double );

TREENODE* setupNode( int,int );

void GmeansPlusPlus( CLUSTER_LIST_PT*,int*,double**,int*,int,int,double );

void initTwoMeansPlusPlus( int*,int*,int*,int*,double**,int*,int,int );

void deleteTree( TREENODE* );

int genRand(int);

double unifRand(double);

#endif
