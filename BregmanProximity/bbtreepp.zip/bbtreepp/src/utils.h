#ifndef UTILS_H
#define UTILS_H

//#include "tree.h"
//#include "newTypes.h"
//#include<stdio.h>
#include <time.h>

//#define CLOSEENOUGH 1e-3

double timediff(struct timeval,struct timeval);
void insert(int*,double*,int,double,int);

#endif
