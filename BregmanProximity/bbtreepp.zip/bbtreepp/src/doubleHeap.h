#ifndef DOUBLE_HEAP_H
#define DOUBLE_HEAP_H

void heapArrayDecreaseKey( double*,int*,int,double );
void minArrayHeapify( double*,int*,int,int );
void minArrayHeapSort( double *,int*,int );
void buildMinArrayHeap( double*,int*,int );

#endif
