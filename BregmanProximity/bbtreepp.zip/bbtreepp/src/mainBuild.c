/* main function for testing the tree building*/

#include <string.h>
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <time.h>
#include "tree.h"
#include "divergence.h"
#include "utils.h"
#include "bbtreeIO.h"
//#include "windows.h"


void processArgs(int,char**);		/* processes the input arguments of the main function*/

char *datafile;
char *outfile;
char *resultsFile;
int isOutfile=0;
int isResFile = 0;
int n=-1;
int d=-1;
int bucketSize = 50;	/* default value for bucketSize (maybe to be used as a pre-processor definition)*/

/*global variables for statistics on the tree*/
int maxDepth = 0;	// used for evaluating the maximum depth of the tree
double sumLeafDepth = 0.0;	// each node gives as a contribution the number of data stored in it x its depth
double NumChildrenOfNonLeaves = 0;
int numNonLeafNodes = 0;
int numLeafNodes = 0;

int main(int argc, char** argv){
  
	int i;
	double **x;
	TREENODE *root;
	  
	/*LARGE_INTEGER startCount, endCount, freqCount;		// variables used for time measures (only windows)
	BOOL isHrCounter, isStart, isEnd;						//
	isHrCounter = QueryPerformanceFrequency(&freqCount);	// verify the presence of the high-resolution timer	*/

	struct timeval startTime,endTime;

	printf("**** processing input arguments **** \n");
	processArgs(argc,argv);
		  
	x = calloc( n,sizeof(double*) );		/* allocates memory for the dataset*/
	for(i=0;i<n;i++)						/*						*/
		x[i]=calloc( d,sizeof(double) );	/*						*/

	readData( x,n,d,datafile );
	  
	  
	/* ************** BUILD THE BBTREE *************************/
	  
	printf("**** bbtree++ building ****... \t");
	/*if (isHrCounter)
	   isStart = QueryPerformanceCounter( &startCount );  */
	  
	// start timer
	gettimeofday(&startTime,NULL);
	root = buildTree( x,n,d,bucketSize );		// recursively builds the bbtree++
	  
	/*if (isHrCounter)
	     isEnd = QueryPerformanceCounter( &endCount );
	  if (isStart && isEnd)
		 printf( "done in %6.6f seconds \n",timediff( startCount,endCount,freqCount ) );*/

	// stop timer 
	gettimeofday(&endTime,NULL);
	printf("done in %6.6f seconds \n",timediff(startTime,endTime));
	     
	//save the bbtree:
	if(isOutfile)
		writeTree(root,d,outfile);

	//save results of the experiment
	if(isResFile)
		writeResults(resultsFile,bucketSize,maxDepth,sumLeafDepth/(double)n,NumChildrenOfNonLeaves/(double)numNonLeafNodes,numNonLeafNodes,numLeafNodes,timediff(startTime,endTime));

	  /* free the memory*/
	  for(i=0;i<n;i++)
	    free(x[i]);
	  free(x);
	  
	  deleteTree(root);

	  //system("pause");
	  return 0;
}

/* processes the input argument to the main function*/
void processArgs(int argc, char**argv){
  int i=1;
  if(argc <= 1){
    printf("usage:\n buildbbt -f dataFile -n numPoints -d dimPoints -o outFile -r resultsFile [-s bucketsize] \n");
    exit(0);
  }
  
  while(i<argc){
    if(!strcmp(argv[i], "-d"))
      d = atoi(argv[++i]);
    else if(!strcmp(argv[i], "-n"))
      n=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-f"))
      datafile = argv[++i];
    else if(!strcmp(argv[i], "-s"))
      bucketSize=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-o")){
      outfile= argv[++i];
      isOutfile=1;
    }
	else if(!strcmp(argv[i], "-r")){
      resultsFile= argv[++i];
      isResFile=1;
    }
    else{
      fprintf(stderr,"unrecognized option.. exiting \n");
      exit(1);
    }
    i++;
  }
  
  if(n==-1 || d==-1 || datafile==NULL || outfile==NULL || resultsFile==NULL){
    fprintf(stderr,"more arguments needed.. exiting \n");
    exit(1);
  }
}  
