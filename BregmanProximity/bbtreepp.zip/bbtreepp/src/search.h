#ifndef SEARCH_H
#define SEARCH_H

#include "newTypes.h"

void multisearch( TREENODE*,double**,double**,int,int,int,int,int*,double*,int );
void iterSearch( TREENODE*,double*,double*,double**,int,int,int );
int needToExplore( TREENODE*,double*,int,double );
int checkStopCondition( int,int );

#endif
