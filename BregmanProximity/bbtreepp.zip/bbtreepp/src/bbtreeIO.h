#ifndef BBTREE_IO_H
#define BBTREE_IO_H

#include "newTypes.h"

void writeResults(char*,int,int,double,double,int,int,double);
void readData(double**,int,int,char*);
void writeTree(TREENODE*,int,char*);
void writeNode(TREENODE*,int,FILE*);
TREENODE* readTree(char*);
TREENODE* readNode(int,FILE*);

#endif
