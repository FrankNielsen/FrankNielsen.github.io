/* main function for testing bbtree++ search*/
#include <string.h>
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
//#include "tree.h"
#include "divergence.h"
#include "utils.h"
#include "search.h"
//#include "windows.h"
#include "treeHeap.h"
#include "doubleHeap.h"
#include "newTypes.h"
#include "bbtreeIO.h"

void processArgs(int,char**);
char *treefile, *datafile, *queryfile; 
char *outfile, *resultsFile;
int isOutfile=0;
int isResFile = 0;
int n=-1, m=-1;
int d=-1;
//int bucketSize = 50;
int k=1;
int maxNumExploredLeaf = 100;
double avgNumCloserPerError = 0.0;
double avgDistCloserPerError = 0.0;
double avgDistCount = 0.0;
double avgExploredLeaf;
double avgNumExploredNodes = 0.0;

int main(int argc, char** argv){ 
	int i,j;
	double **x, **q;
	double *kthDist;
	int *kthInd;
	double bbtime;
	int *NNs, errCount;			
	double *dToNNs;
	double brutetime, divTemp;
	double *trueDToNNs;
	int *trueNNs;
	int isTrueNN;
	int numberCloser;

	TREENODE *root;
	/*LARGE_INTEGER startCount, endCount, freqCount;
	BOOL isHrCounter, isStart, isEnd;
	isHrCounter = QueryPerformanceFrequency(&freqCount);*/
	struct timeval startTime,endTime;

	printf("**** reading input data **** \n");
	processArgs(argc,argv);
	x = calloc(n,sizeof(double*));
	q = calloc(m,sizeof(double*));
	  
	for(i=0;i<n;i++)
		x[i]=calloc(d,sizeof(double));                    
	for(i=0;i<m;i++)
		q[i]=calloc(d,sizeof(double));
	kthDist = calloc(m,sizeof(double));
	kthInd = calloc(m,sizeof(int));
	dToNNs = calloc(n,sizeof(double));
	NNs = calloc(n,sizeof(int));
	trueNNs = calloc(n,sizeof(int));
	trueDToNNs = calloc(n,sizeof(double));

	readData(x,n,d,datafile);
	readData(q,m,d,queryfile);
       
  	/* ************** VISIT THE BBTREE *************************/  
	root = readTree(treefile);	//Retrieve the bbtree
	printf("searching.....\n");
	/*if (isHrCounter)
		isStart = QueryPerformanceCounter(&startCount);*/
	// start timer
	gettimeofday(&startTime,NULL);
	multisearch(root,q,x,n,d,m,k,kthInd,kthDist,maxNumExploredLeaf);
	/*if (isHrCounter)
		isEnd = QueryPerformanceCounter(&endCount);
	if (isStart && isEnd){
		bbtime = timediff(startCount,endCount,freqCount);
		printf("BBTREE search time elapsed = %6.6f s \n",bbtime);
	}*/
	// stop timer 
	gettimeofday(&endTime,NULL);
	bbtime = timediff(startTime,endTime);
	printf("BBTREE search time elapsed = %6.6f s \n",bbtime);

	/* ****************** BRUTE-FORCE SEARCH *********************/
	//double curmin;
	//int curBest, errCount;
	errCount = 0;
	brutetime = 0.0;
	/*
	if (isHrCounter)
		isStart = QueryPerformanceCounter(&startCount);
	for(i=0;i<m;i++){		// for each query point
		for(j=0;j<k;j++){	// inizialize kNN vector
			dToNNs[j]=HUGE_VAL;
			NNs[j]=-1;
		}
		for(j=0;j<n;j++){	// for each reference point
			divTemp = divergence(x[j],q[i],d);	// compute the divergence
			if(NNs[0]==-1 || divTemp < dToNNs[0])
				insert(NNs,dToNNs,j,divTemp,k);  // update the kNN vector
		} 
		if (NNs[0]!=kthInd[i]){
		errCount++;
		   //printf("error for query %d\n",i);
		}

    	}
	
	if (isHrCounter)
		isEnd = QueryPerformanceCounter(&endCount);
	if (isStart && isEnd){
		brutetime = timediff(startCount,endCount,freqCount);
		printf("BRUTE time elapsed = %6.6f s \n",brutetime);
	}
	printf("k-th nn errors: %d \n",errCount);     
	*/
	/* ****************** EVALUATES kNN ERRORS *********************/
	// valid only for 1-NN
	
	/*for(i=0;i<m;i++){		// for each query point
		for(j=0;j<n;j++){	// inizialize kNN vector
			trueDToNNs[j]=HUGE_VAL;
			trueNNs[j]=j;
		}
		for(j=0;j<n;j++){	// for each reference point
			divTemp = divergence(x[j],q[i],d);	// compute the divergence
			heapArrayDecreaseKey( trueDToNNs,trueNNs,j,divTemp );
		}
		minArrayHeapSort(trueDToNNs,trueNNs,n);
		isTrueNN = 0;
		numberCloser = 0;
		errCount++;
		while(!isTrueNN){
			if( fabs( trueDToNNs[n-numberCloser-1] - kthDist[i]) < 0.000001 ){
				isTrueNN = 1;
				if(numberCloser==0)
					errCount--;
			}
			/*if (trueNNs[n-numberCloser-1]==kthInd[i]){
				isTrueNN = 1;
				if(numberCloser==0)
					errCount--;
			}*/
			/*else{
				numberCloser++;
				//printf("error for query %d\n",i);
			}
		}
		avgNumCloserPerError+=numberCloser; 
		avgDistCloserPerError+=fabs((trueDToNNs[n-1]-kthDist[i])/trueDToNNs[n-1]);
			

    	}
	printf("k-th nn errors: %d \n",errCount);   
	avgNumCloserPerError/=errCount;
	avgDistCloserPerError/=errCount;*/
	avgNumExploredNodes/=m;
	
	if(isOutfile){
		FILE*fp = fopen(outfile,"a");
		for (i=0;i<m;i++)
			fprintf(fp,"%d \t %6.8f \n",kthInd[i],kthDist[i]);
		fclose(fp);
	}
	if(isResFile){
		FILE*fp = fopen(resultsFile,"a");
		fprintf(fp,"%d %f %f %f %f %f %d %d %f %f\n",maxNumExploredLeaf,avgDistCount,avgExploredLeaf,avgNumCloserPerError,avgDistCloserPerError,avgNumExploredNodes,m,errCount,bbtime,brutetime);
		fclose(fp);
		//saves results of the experiment
	}

	for(i=0;i<n;i++)
    		free(x[i]);
	for(i=0;i<m;i++)
		free(q[i]);
	free(x);
	free(q);
	free(NNs);
	free(dToNNs);
	free(trueDToNNs);
	free(trueNNs);
	deleteTree(root);

	//system("pause");
	return 0;
}

void processArgs(int argc, char**argv){
  int i=1;
  if(argc <= 1){
    printf("usage:\n bbsearch -f dataFile -t treeFile -q queryFile -n numPts -m numQueries -d dim -o outFile -r resultsFile [-k numNeighbors] [-e maxNumExploredLeaf] \n");
    exit(0);
  }
  
  while(i<argc){
    if(!strcmp(argv[i], "-d"))
      d = atoi(argv[++i]);
    else if(!strcmp(argv[i], "-n"))
      n=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-m"))
      m=atoi(argv[++i]);
    else if(!strcmp(argv[i], "-f"))
      datafile = argv[++i];
    else if(!strcmp(argv[i], "-t"))
      treefile = argv[++i];
    else if(!strcmp(argv[i], "-q"))
      queryfile= argv[++i];
    else if(!strcmp(argv[i], "-o")){
      outfile= argv[++i];
      isOutfile=1;
    }
	else if(!strcmp(argv[i], "-r")){
      resultsFile= argv[++i];
      isResFile=1;
    }
	else if(!strcmp(argv[i], "-e"))
      maxNumExploredLeaf = atoi(argv[++i]);
    else if(!strcmp(argv[i], "-k"))
      k=atoi(argv[++i]);
    else{
      fprintf(stderr,"unrecognized option.. exiting \n");
      exit(1);
    }
    i++;
  }
  
  if(m==-1 || d==-1 || treefile==NULL || queryfile==NULL || outfile==NULL || resultsFile==NULL){
    fprintf(stderr,"more arguments needed.. exiting \n");
    exit(1);
  }

}  
