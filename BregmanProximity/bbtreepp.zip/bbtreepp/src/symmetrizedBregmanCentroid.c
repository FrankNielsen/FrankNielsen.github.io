#ifndef SBC_C
#define SBC_C

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "divergence.h"
#include "utils.h"

/* Converts d-dimensional distribution to (d-1)-dimensional multinomial (lowers by one dimension)*/
void distributionToMultinomial( double *out, double *p, int d ){
	/* the sum of components of p must be 1*/
	int i;
	double den, sum;
	
	sum = 0.0;
	for( i=0;i<d;i++ )
		sum = sum + p[i];
	if( fabs(sum-1.0)> 0.000001 )
		printf("warning: components of input point do not sum up to 1!\n");
	
	den = p[d-1];
	for( i=0;i<d-1;i++ )
		out[i] = log(p[i]/den);	
}

/* Converts d-dimensional multinomial to (d+1)-dimensional distribution (augments by one dimension)*/
void multinomialToDistribution( double *out, double *p,int d ){
	int i;
	double sum;
	sum = 0.0;
	
	for( i=0;i<d;i++ )
		sum+=exp( p[i] );
	out[d] = 1.0/( 1.0+sum );
	for( i=0;i<d;i++ )
		out[i] = out[d]*exp(p[i]);

}

/* Walks on the geodesic to find the 2-mean (non-uniform weight) 
    (Nielsen and Nock, 2007)*/

void symmetrizedBregmanCentroidGeodesicWalk( double *centroid, double **data, int n, int d ){
	int i;
	double **theta, *thetaR, *thetaL, *pThetaGeodesic;	/* arrays in the space of parameter theta (dimension d-1)*/
	double l, lMin, lMax;
	
	// memory allocation of work variables
	theta = calloc( n,sizeof(double*) );	
	for( i=0;i<n;i++ )
		theta[i] = calloc( d-1,sizeof(double) );
	thetaR = calloc( d-1,sizeof(double) );
	thetaL = calloc( d-1,sizeof(double) );
	pThetaGeodesic = calloc( d-1,sizeof(double) );
	
	// STEP 1: convert data (dimension d) to vectors of multinomial natural parameters (dimension d+1)
	for( i=0;i<n;i++ )
		distributionToMultinomial( theta[i],data[i],d );
	
	// STEP 2: Compute the right-type and left-type sided centroids
	rightCentroid( thetaR, theta, n, d-1 );
	multinomialLeftCentroid( thetaL, theta, n, d-1 );
	// We do not need theta set anymore from now on, just the sided centroids
	
	/* STEP 3: Take a walk on the geodesic 
	(either in curved or primal space): Here in curved primal space*/
	lMin = 0.0;
	lMax = 1.0;
	while( (lMax-lMin)>1.0e-6 ){
		l = ( lMin+lMax )/2;
		multinomialGeodesicPoint( pThetaGeodesic,thetaR,thetaL,d-1,l );
		if( multinomialDivergence( thetaR,pThetaGeodesic,d-1 ) > multinomialDivergence( pThetaGeodesic,thetaL,d-1 ))
			lMax = l;
		else
			lMin = l;
	}
	l = ( lMin+lMax )/2.0;
	multinomialGeodesicPoint( pThetaGeodesic,thetaR,thetaL,d-1,l );
	
	/* STEP 4: Transform back multinomial natural (d-1)-dimensional parameters to d-dimensional distribution parameters*/
	multinomialToDistribution( centroid,pThetaGeodesic,d-1 );
		
	for( i=0;i<n;i++ )
		free(theta[i]);
	free(theta);
	free(thetaR);
	free(thetaL);
	free(pThetaGeodesic);
	
}

#endif
