(C) 2013 Frank Nielsen, Frank.Nielsen@acm.org, All rights reserved 
Non-Commercial Research Use License only
No liabilities


The main entry program is fDivergence.java
 