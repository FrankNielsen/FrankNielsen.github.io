
class Chi2Pearson extends fDiv
{
double f(double u)
{return (u-1)*(u-1);}
}
