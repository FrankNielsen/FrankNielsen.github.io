class KullbackLeibler extends fDiv
{
double f(double u)
{return -Math.log(u);}	
}