abstract class AEF
{

double theta;

abstract double L2T(double l); // usual to natural parameter conversion
abstract double F(double t); // log-normalizer
abstract double dF(double t);// first derivative
abstract double ddF(double t); // second derivative
abstract double variate();
abstract double density(double x);

// Formula section 2.A
double chiP(AEF X2)
{
double theta1=theta;
double theta2=X2.theta;	
return Math.exp(F(2*theta2-theta1)-(2*F(theta2)-F(theta1)))-1;
}

double chiP2(AEF X2)
{
double theta1=theta;
double theta2=X2.theta;	
return (Math.exp(F(2*theta2-theta1))/Math.exp(2*F(theta2)-F(theta1))) -1;
}


// reverse
double chiN(AEF X2)
{return X2.chiP(this);}


  static double fact(double n){
		double f = 1;
		for (int i=1; i<=n; i++)
			f *= i;
		return f;
	}
	
public static int choose(int nn, int kk)
{
return (int)(fact(nn)/(fact(kk)*fact(nn-kk)));	
}


public   double KL(double l1, double l2)
{
	double t1=L2T(l1);
	double t2=L2T(l2);
	return F(t2)-F(t1)-(t2-t1)*dF(t1);}



}