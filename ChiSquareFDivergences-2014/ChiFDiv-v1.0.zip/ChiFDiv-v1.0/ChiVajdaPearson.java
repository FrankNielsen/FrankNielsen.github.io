// Higher order chi square divergence
class VajdaPearson extends fDiv
{
int k;
	
VajdaPearson(int kk){k=kk;}	

double f(double u)
{return Math.pow(u-1,k);}	
}

