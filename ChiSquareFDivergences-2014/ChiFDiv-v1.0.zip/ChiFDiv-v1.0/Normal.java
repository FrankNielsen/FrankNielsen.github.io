

// 1D standard normal family
class Normal extends AEF
{
double mu;

public static double sqr(double x){return x*x;}

double L2T(double l){return l;}

Normal(double m){mu=m; theta=m;}

double F(double t){return 0.5*t*t;} 
double dF(double t){return t;} 
double ddF(double t){return 1;} 

	
double density(double x){
return Math.exp(-0.5*sqr(x-mu))/Math.sqrt(2.0*Math.PI);}
	
double variate()
{double u1=Math.random();double u2=Math.random();
return mu+(Math.sqrt(-2*Math.log(u1))*Math.cos(2.0*Math.PI*u2));	
}
	
public static double VajdaChiK(double m1, double m2, int k)
{
double res=0;
int i;
double sign;
double term;

for(i=0;i<=k;i++)
{
	if (((k-i)%2)==0) sign=1; 
		else sign=-1;
		
	term=choose(k,i)*sign*Math.exp( 0.5*(i-1)*i*(m1-m2)*(m1-m2) );
	
	//System.out.println("\t"+i+" -> "+term+"  sign "+sign);
	res+= term;
}

return res;
}
	

double NormalChiP(AEF X2)
{
double mu2=((Normal)X2).mu;	
return Math.exp(sqr(mu2-mu))-1;
}
	 

}

