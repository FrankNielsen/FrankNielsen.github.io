class TriangularDivergence extends fDiv
{
double f(double u)
{return ((u-1)*(u-1))/(2*(1+u));}	
}