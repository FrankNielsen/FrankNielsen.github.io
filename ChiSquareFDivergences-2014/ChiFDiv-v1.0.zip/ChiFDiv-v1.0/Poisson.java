
class Poisson extends AEF
{
double lambda;


double L2T(double l){return Math.log(l);}

//
// Exact formula (checked, work when l1 is quite separated from l2)
//
public static double VajdaChiK(double l1, double l2, int k)
{
double res=0;
int i;
double sign;
double term;

for(i=0;i<=k;i++)
{
	if (((k-i)%2)==0) sign=1; 
		else sign=-1;
		
	term=choose(k,i)*sign*Math.exp(Math.pow(l1,1-i)*Math.pow(l2,i)-((1-i)*l1+ i*l2) );
	
	//System.out.println("\t"+i+" -> "+term+"  sign "+sign);
	res+= term;
}

return res;
}


	
double density(double x)
{return (Math.pow(lambda, x)*Math.exp(-lambda)) / (fact(x));
}

double PoissonChiP(AEF X2)
{
Poisson P2=(Poisson)X2;	
double l1=this.lambda;
double l2=P2.lambda;	
double term=(l2*l2/l1)-2*l2+l1;	
return Math.exp(term)-1;	
}

Poisson(double l){lambda=l; theta=Math.log(l);}

double F(double theta){return Math.exp(theta);}
double dF(double theta){return Math.exp(theta);}
double ddF(double theta){return Math.exp(theta);}

double variate() {
		
		// Initialization
		double l = Math.exp(-lambda);
		double p = 1.0;
		int    k = 0;
		
		// Loop
		do{
			k++;
			p *= Math.random();
		} while(p>l);
		
		return k-1;
	 
	}

}

