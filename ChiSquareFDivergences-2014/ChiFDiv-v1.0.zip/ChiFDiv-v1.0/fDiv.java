//
// Abstract f-divergence
//
abstract class fDiv
{
abstract double f(double u);
double secondDerivative(double u){return -1;}

// Stochastic integration
double stoEval(AEF X1, AEF X2, int n)
{
double r=0;
int i;
double x;

for(i=0;i<n;i++)
{
x=X1.variate();	
r += f(X2.density(x)/X1.density(x));	
}

for(i=0;i<n;i++)
{
x=X2.variate();	
r += (X1.density(x)/X2.density(x))* f(X2.density(x)/X1.density(x));	
}


return r/(2.0*n);	
}

}