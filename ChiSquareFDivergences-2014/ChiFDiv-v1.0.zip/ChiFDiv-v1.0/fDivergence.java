
class fDivergenceChi
{

//
// Check Lemma 3, Vajda higher order (binomial expansion)
//
public static void TestVajdaChiNormal()
{
double chiVajdaP;
double stoVajdaP;
int nsample=10000000;
int i,k=4;
//double l1=Math.random(), l2=Math.random();

double m1=3, m2=4;

Normal N1=new Normal(m1);
Normal N2=new Normal(m2);

System.out.println("[Test Vajda Chi binomial expansion for the Normal family]");


System.out.println("Normal family, m1="+N1.mu+" m2="+N2.mu);
 

for(i=2;i<=10;i++)
{
// high-order signed chi distance
fDiv VajdaPearson=new VajdaPearson(i);
 
System.out.println("Vajda Pearson divergence for k=:"+i); 



stoVajdaP=VajdaPearson.stoEval(N1,N2,nsample);
System.out.println("Stochastic Vajda Pearson:\t"+stoVajdaP);


chiVajdaP=Normal.VajdaChiK(m1,m2,i);
System.out.println("Exact Vajda Pearson:\t"+chiVajdaP);
}

}

public static void TestVajdaChiPoisson()
{
double chiVajdaP;
double stoVajdaP;
int nsample=10000000;
int i,k=4;
//double l1=Math.random(), l2=Math.random();

double l1=0.6, l2=0.3;

Poisson P1=new Poisson(l1);
Poisson P2=new Poisson(l2);

System.out.println("[Test Vajda Chi binomial expansion for the Poisson family]");


System.out.println("Poisson family, lambda1="+P1.lambda+" lambda2="+P2.lambda);

double chi2P=P1.chiP(P2);
System.out.println("chi2 P:"+chi2P); 

for(i=2;i<=10;i++)
{
// high-order signed chi distance
fDiv VajdaPearson=new VajdaPearson(i);
 
System.out.println("Vajda Pearson divergence for k=:"+i); 



stoVajdaP=VajdaPearson.stoEval(P1,P2,nsample);
System.out.println("Stochastic Vajda Pearson:\t"+stoVajdaP);


chiVajdaP=Poisson.VajdaChiK(l1,l2,i);
System.out.println("Exact Vajda Pearson:\t"+chiVajdaP);
}

}

 

//
// Approximation
//
public static void TestJensenShannonChi2Approximation()
{
System.out.println("[Test JensenShannon divergence approximated with a Chi2 rescaling]");	
	
fDiv JS=new JensenShannonDivergence();
double l1=5, l2=l1+0.1;
Poisson P1=new Poisson(l1);
Poisson P2=new Poisson(l2);
int nsample=10000000;
double sto;
sto=JS.stoEval(P1,P2,nsample);

System.out.println("Jensen-Shannon divergence: Stochastic evaluation:\t"+sto);

double chi2=P1.chiP(P2);
double scale=0.5*JS.secondDerivative(1);
double approx=scale*chi2;

System.out.println("Approximation with Chi2:\t"+approx);
double error=100.0*Math.abs(approx-sto)/sto;
System.out.println("Error in %:\t"+error);
}

//
// Triangular divergence
//
public static void TestTriangularDivergence()
{
System.out.println("[Test  Triangular divergence (Stochastic evaluation/analytic formula)]");	
	
fDiv triangularDiv=new TriangularDivergence();
double l1=1.1, l2=0.2;
Poisson P1=new Poisson(l1);
Poisson P2=new Poisson(l2);
int nsample=10000000;
double sto;
sto=triangularDiv.stoEval(P1,P2,nsample);

System.out.println("Triangular divergence: Stochastic eval:\t"+sto);

int i;
double r=0;
double term;
double sign;
double scale=0;

for(i=0;i<10;i++)
{
	if (i%2==0) sign=1; else sign=-1;
	
	if (i==0) scale=0.5;
	if (i==1) scale=-1.5;
	if (i>=2) scale=2;
	
	term=sign*scale*Math.exp(Math.pow(l2,i)*Math.pow(l1,1-i)-i*l2-(1-i)*l1);
	
	System.out.println(" \t"+term);
	
	r+= term;
}

 

System.out.println("Formula from Taylor series:\t"+r);
	
}

//
// Test the Taylor expansion for the KL divergence
//
public static void TestKLTaylor()
{

System.out.println("[TEST KL and Taylor expansion with higher order Chi]");
 
	
double l1=0.6;
double l2=0.3;
	
Poisson P1=new Poisson(l1);
Poisson P2=new Poisson(l2);
int nsample=1000000;
fDiv KLD=new KullbackLeibler();
double stoKL=KLD.stoEval(P1,P2,nsample);

System.out.println("KL from stochastic integration:"+stoKL);

System.out.println("Poisson family, lambda1="+P1.lambda+" lambda2="+P2.lambda);

int i,s=20;
double r=0;
double sign, term;

double kl=P1.KL(l1,l2);
double klr=P1.KL(l2,l1);

System.out.println("KL from BD:"+kl);
 
System.out.println("KL from Taylor:");


for(i=2;i<s;i++)
{
System.out.print("\t expansion order="+i);	
if ((i%2)==0) sign=1; else sign=-1;

term=sign*Poisson.VajdaChiK(l1,l2,i)/(double)i;

r+=term;

System.out.println("\t KL approx="+r);
}


	
}

 
//
// Comparisons between stochastic approximation and chi square closed-form formula
// Lemma 1	
public static void TestChiSquare()
{
int nsample=1000000;	

System.out.println("[TEST Chi square distance]");
System.out.println("--- Test Pearson/Neyman chi square divergence ---");
System.out.println("--- Closed formula and stochastic approximations");

System.out.println("Stochastic integration with n="+nsample);

double chiP, chiP2, chiN, eChiP;
double stoChiP, stoChiN;
fDiv Chi2P=new Chi2Pearson();
fDiv Chi2N=new Chi2Neyman();

Poisson P1=new Poisson(3+3*Math.random());
Poisson P2=new Poisson(3+3*Math.random());

System.out.println("Poisson family, lambda1="+P1.lambda+" lambda2="+P2.lambda);

chiP2=P1.chiP2(P2);
chiP=P1.chiP(P2);
chiN=P1.chiN(P2);

stoChiP=Chi2P.stoEval(P1,P2,nsample);
stoChiN=Chi2N.stoEval(P1,P2,nsample);

eChiP=P1.PoissonChiP(P2);


System.out.println("Chi Pearson:\t"+chiP);

System.out.println("Chi Pearson equiv formula:\t"+chiP2);

System.out.println("Chi Neyman:\t"+chiN);

System.out.println("Stochastic Chi Pearson:\t"+stoChiP);
System.out.println("Stochastic Chi Neyman:\t"+stoChiN);

System.out.println("Explicit Chi Pearson:\t"+eChiP);

// now for the normal family

Normal N1=new Normal(3+3*Math.random());
Normal N2=new Normal(3+3*Math.random());

System.out.println("\n\nNormal family, mu1="+N1.mu+" mu2="+N2.mu);

chiP=N1.chiP(N2);
chiN=N1.chiN(N2);

stoChiP=Chi2P.stoEval(N1,N2,nsample);
stoChiN=Chi2N.stoEval(N1,N2,nsample);

System.out.println("Chi Pearson:\t"+chiP);
System.out.println("Chi Neyman:\t"+chiN);

System.out.println("Stochastic Chi Pearson:\t"+stoChiP);
System.out.println("Stochastic Chi Neyman:\t"+stoChiN);

eChiP=N1.NormalChiP(N2);
System.out.println("Explicit Chi Pearson:\t"+eChiP);
}	

public static void main(String [] args)
{
System.out.println("Showcasing: On the Chi square and  higher-order Chi distances for approximating f-divergences\nby Frank Nielsen and Richard Nock, 2013");	

TestChiSquare();	
TestVajdaChiPoisson();		
TestVajdaChiNormal();
TestJensenShannonChi2Approximation();
TestKLTaylor(); 	
}
}