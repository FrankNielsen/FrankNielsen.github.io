class JensenShannonDivergence extends fDiv
{
	
double secondDerivative(double u){return (1/u)-(1/(u+1));}	


double f(double u)
{return -(u+1)*Math.log(0.5*(1+u))+u*Math.log(u);}	
}

