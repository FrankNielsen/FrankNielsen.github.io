bregman.barycenter package
==========================

Submodules
----------

bregman.barycenter.base module
------------------------------

.. automodule:: bregman.barycenter.base
   :members:
   :undoc-members:
   :show-inheritance:

bregman.barycenter.bregman module
---------------------------------

.. automodule:: bregman.barycenter.bregman
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.barycenter
   :members:
   :undoc-members:
   :show-inheritance:
