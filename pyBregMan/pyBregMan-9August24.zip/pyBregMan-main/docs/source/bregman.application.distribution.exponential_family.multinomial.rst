bregman.application.distribution.exponential\_family.multinomial package
========================================================================

Submodules
----------

bregman.application.distribution.exponential\_family.multinomial.dissimilarity module
-------------------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.multinomial.dissimilarity
   :members:
   :undoc-members:
   :show-inheritance:

bregman.application.distribution.exponential\_family.multinomial.geodesic module
--------------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.multinomial.geodesic
   :members:
   :undoc-members:
   :show-inheritance:

bregman.application.distribution.exponential\_family.multinomial.multinomial module
-----------------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.multinomial.multinomial
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.exponential_family.multinomial
   :members:
   :undoc-members:
   :show-inheritance:
