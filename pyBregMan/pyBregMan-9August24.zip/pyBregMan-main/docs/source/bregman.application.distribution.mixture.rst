bregman.application.distribution.mixture package
================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bregman.application.distribution.mixture.discrete_mixture
   bregman.application.distribution.mixture.ef_mixture

Submodules
----------

bregman.application.distribution.mixture.mixture module
-------------------------------------------------------

.. automodule:: bregman.application.distribution.mixture.mixture
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.mixture
   :members:
   :undoc-members:
   :show-inheritance:
