bregman.application package
===========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bregman.application.distribution
   bregman.application.psd

Submodules
----------

bregman.application.application module
--------------------------------------

.. automodule:: bregman.application.application
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application
   :members:
   :undoc-members:
   :show-inheritance:
