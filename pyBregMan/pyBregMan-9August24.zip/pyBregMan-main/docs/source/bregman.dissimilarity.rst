bregman.dissimilarity package
=============================

Submodules
----------

bregman.dissimilarity.base module
---------------------------------

.. automodule:: bregman.dissimilarity.base
   :members:
   :undoc-members:
   :show-inheritance:

bregman.dissimilarity.bregman module
------------------------------------

.. automodule:: bregman.dissimilarity.bregman
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.dissimilarity
   :members:
   :undoc-members:
   :show-inheritance:
