bregman.application.distribution.mixture.ef\_mixture package
============================================================

Submodules
----------

bregman.application.distribution.mixture.ef\_mixture.ef\_mixture module
-----------------------------------------------------------------------

.. automodule:: bregman.application.distribution.mixture.ef_mixture.ef_mixture
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.mixture.ef_mixture
   :members:
   :undoc-members:
   :show-inheritance:
