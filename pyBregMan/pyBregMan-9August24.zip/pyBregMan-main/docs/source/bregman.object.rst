bregman.object package
======================

Submodules
----------

bregman.object.distribution module
----------------------------------

.. automodule:: bregman.object.distribution
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.object
   :members:
   :undoc-members:
   :show-inheritance:
