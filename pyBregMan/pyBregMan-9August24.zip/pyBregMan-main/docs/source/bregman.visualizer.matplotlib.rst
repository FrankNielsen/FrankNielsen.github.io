bregman.visualizer.matplotlib package
=====================================

Submodules
----------

bregman.visualizer.matplotlib.callback module
---------------------------------------------

.. automodule:: bregman.visualizer.matplotlib.callback
   :members:
   :undoc-members:
   :show-inheritance:

bregman.visualizer.matplotlib.matplotlib module
-----------------------------------------------

.. automodule:: bregman.visualizer.matplotlib.matplotlib
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.visualizer.matplotlib
   :members:
   :undoc-members:
   :show-inheritance:
