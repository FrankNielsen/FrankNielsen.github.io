bregman.ball package
====================

Submodules
----------

bregman.ball.base module
------------------------

.. automodule:: bregman.ball.base
   :members:
   :undoc-members:
   :show-inheritance:

bregman.ball.bregman module
---------------------------

.. automodule:: bregman.ball.bregman
   :members:
   :undoc-members:
   :show-inheritance:

bregman.ball.parameterized module
---------------------------------

.. automodule:: bregman.ball.parameterized
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.ball
   :members:
   :undoc-members:
   :show-inheritance:
