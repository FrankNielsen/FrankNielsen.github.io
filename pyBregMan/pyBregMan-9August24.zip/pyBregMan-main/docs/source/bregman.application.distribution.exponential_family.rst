bregman.application.distribution.exponential\_family package
============================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bregman.application.distribution.exponential_family.categorical
   bregman.application.distribution.exponential_family.gaussian
   bregman.application.distribution.exponential_family.multinomial

Submodules
----------

bregman.application.distribution.exponential\_family.exp\_family module
-----------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.exp_family
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.exponential_family
   :members:
   :undoc-members:
   :show-inheritance:
