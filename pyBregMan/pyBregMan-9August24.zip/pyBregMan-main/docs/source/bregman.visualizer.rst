bregman.visualizer package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bregman.visualizer.matplotlib

Submodules
----------

bregman.visualizer.visualizer module
------------------------------------

.. automodule:: bregman.visualizer.visualizer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.visualizer
   :members:
   :undoc-members:
   :show-inheritance:
