bregman.application.distribution.exponential\_family.gaussian package
=====================================================================

Submodules
----------

bregman.application.distribution.exponential\_family.gaussian.dissimilarity module
----------------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.gaussian.dissimilarity
   :members:
   :undoc-members:
   :show-inheritance:

bregman.application.distribution.exponential\_family.gaussian.gaussian module
-----------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.gaussian.gaussian
   :members:
   :undoc-members:
   :show-inheritance:

bregman.application.distribution.exponential\_family.gaussian.geodesic module
-----------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.gaussian.geodesic
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.exponential_family.gaussian
   :members:
   :undoc-members:
   :show-inheritance:
