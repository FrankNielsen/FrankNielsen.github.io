bregman package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bregman.application
   bregman.ball
   bregman.barycenter
   bregman.dissimilarity
   bregman.manifold
   bregman.object
   bregman.visualizer

Submodules
----------

bregman.base module
-------------------

.. automodule:: bregman.base
   :members:
   :undoc-members:
   :show-inheritance:

bregman.constants module
------------------------

.. automodule:: bregman.constants
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman
   :members:
   :undoc-members:
   :show-inheritance:
