bregman.application.distribution.exponential\_family.categorical package
========================================================================

Submodules
----------

bregman.application.distribution.exponential\_family.categorical.categorical module
-----------------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.exponential_family.categorical.categorical
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.exponential_family.categorical
   :members:
   :undoc-members:
   :show-inheritance:
