bregman.application.distribution package
========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   bregman.application.distribution.exponential_family
   bregman.application.distribution.mixture

Submodules
----------

bregman.application.distribution.distribution module
----------------------------------------------------

.. automodule:: bregman.application.distribution.distribution
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution
   :members:
   :undoc-members:
   :show-inheritance:
