bregman.manifold package
========================

Submodules
----------

bregman.manifold.bisector module
--------------------------------

.. automodule:: bregman.manifold.bisector
   :members:
   :undoc-members:
   :show-inheritance:

bregman.manifold.connection module
----------------------------------

.. automodule:: bregman.manifold.connection
   :members:
   :undoc-members:
   :show-inheritance:

bregman.manifold.coordinate module
----------------------------------

.. automodule:: bregman.manifold.coordinate
   :members:
   :undoc-members:
   :show-inheritance:

bregman.manifold.generator module
---------------------------------

.. automodule:: bregman.manifold.generator
   :members:
   :undoc-members:
   :show-inheritance:

bregman.manifold.geodesic module
--------------------------------

.. automodule:: bregman.manifold.geodesic
   :members:
   :undoc-members:
   :show-inheritance:

bregman.manifold.manifold module
--------------------------------

.. automodule:: bregman.manifold.manifold
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.manifold
   :members:
   :undoc-members:
   :show-inheritance:
