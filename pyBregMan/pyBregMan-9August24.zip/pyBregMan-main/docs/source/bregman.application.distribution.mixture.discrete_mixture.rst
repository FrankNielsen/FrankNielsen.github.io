bregman.application.distribution.mixture.discrete\_mixture package
==================================================================

Submodules
----------

bregman.application.distribution.mixture.discrete\_mixture.discrete\_mixture module
-----------------------------------------------------------------------------------

.. automodule:: bregman.application.distribution.mixture.discrete_mixture.discrete_mixture
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: bregman.application.distribution.mixture.discrete_mixture
   :members:
   :undoc-members:
   :show-inheritance:
