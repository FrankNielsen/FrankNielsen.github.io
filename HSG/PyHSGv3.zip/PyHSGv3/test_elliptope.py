#!/usr/bin/env python

from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import numpy as np
from scipy.stats import invwishart
from Elliptope import Elliptope
from sklearn import metrics

def blob( N, D, df=30 ):
    '''
    '''
    C = invwishart.rvs( df=D+1, scale=np.eye(D), size=1 )

    return invwishart.rvs( df=df, scale=C, size=N )

def artificial_dataset( k, N, D ):
    cluster_size = [ int(N/k) for i in range(k) ]
    cluster_size[-1] = N - sum(cluster_size[:-1])

    covs = []
    labels = []
    for i, s in enumerate( cluster_size ):
        covs.append( blob( s, D ) )
        labels += [ i for _ in range( s ) ]
    cov = np.vstack( covs )

    corrs = []
    for C in cov:
        a = np.diag( np.diag( C )**(-.5) )
        corrs.append( Elliptope( a.dot( C.dot( a ) ) ) )

    return corrs, labels

def exp( compute_distance, repeat=500 ):
    acc = np.zeros( repeat )

    for run in range( repeat ):
        data, labels = artificial_dataset( 3, 100, 3 )
        result = Elliptope.kmeansplusplus( data, 3, compute_distance )
        acc[run] = metrics.adjusted_mutual_info_score( result, labels )

    print( '{:.2f}-{:.2f}'.format( acc.mean(), acc.std() ) )

np.random.seed( 2017 )

print('hilbert')
exp( Elliptope.hilbert_distance )

print('euclidean')
exp( Elliptope.euclidean_distance )

print('l1')
exp( Elliptope.l1_distance )

print('logdet')
exp( Elliptope.logdet_distance )
