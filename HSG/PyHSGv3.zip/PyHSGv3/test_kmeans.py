#!/usr/bin/env python

from __future__ import print_function, division, absolute_import

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype']  = 42
matplotlib.rcParams['font.family'] = "serif"
matplotlib.rcParams['font.size'] = 10

from square import square
from Multinomial import Multinomial
from sklearn import metrics

import numpy as np
import sys, itertools
sys.stdout = sys.stderr

from itertools import permutations
from sklearn import datasets

def digits():
    digits = datasets.load_digits()
    images = digits.data + 0.1
    labels = digits.target

    data = []
    for image in images:
        data.append( Multinomial( image ) )
    return data, labels

def artificial_dataset( N, k, seed, dim, sigma, scale=False, generator=0, eps=1e-16 ):
    '''
        N -- sample size
        k -- number of clusters
     seed -- random seed
      dim -- dimension of the probability vector
    sigma -- noise level

    return a list of Multinomail distributions and their labels
    '''
    assert( k > 0 )
    rng = np.random.RandomState( seed )

    theta  = []
    labels = []
    s      = []

    cluster_size = [ int(N/k) for _ in range(k-1) ]
    cluster_size.append( N - sum(cluster_size) )

    for i, _n in enumerate( cluster_size ):
        # center is uniform in the simplex
        center = rng.dirichlet( np.ones(dim+1) )

        # add Gaussian noise in the log coordinates
        if generator == 0:
            theta.append( sigma * rng.randn( _n, dim+1 ) + np.log( center+eps ) )
        else:
            theta.append( sigma * rng.standard_t( 5, [_n, dim+1] ) + np.log( center+eps ) )
        labels += [ i for _ in range(_n) ]
        s += [ np.random.gamma(10, 0.1, size=_n) ]

    theta = np.vstack( theta )
    eta = np.exp( theta )
    eta += eta.max(1)[:,None] * 1e-4

    if scale:
        s = np.hstack( s )
        return [ Multinomial(p, normalize=False) for p in eta*s[:,None] ], labels

    else:
        return [ Multinomial(p) for p in eta ], labels

def visualize_clusters( ofilename, N=100, num_clusters=3, RES=200, dim=2, sigma=0.3, plusplus=False, seed=2001 ):
    '''
    show toy clustering results

    ofilename    -- output file name
    N            -- number of Multinomial points
    num_clusters -- number of clusters
    RES          -- resolution (image quality)
    dim          -- dimension (set to 2)
    sigma        -- noise level
    plusplus     -- whether to show kmeans++
    seed         -- random seed

    Fig. (1) in the paper
    '''
    distributions, labels = artificial_dataset( N, num_clusters, seed, dim, sigma )

    fig = plt.figure( figsize=(12,3), dpi=100 )
    grid = ImageGrid( fig, 111,
                 nrows_ncols=(1,4),
                 axes_pad=0.5,
                 share_all=True,
                 cbar_location="right",
                 cbar_mode="each",
                 cbar_size="3%",
                 cbar_pad=0,
                 )

    def showdist( ax, clustering, compute_distance, title ):
        if plusplus:
            assign, centers = clustering( distributions, num_clusters, seed=seed, max_itrs=0 )
        else:
            assign, centers = clustering( distributions, num_clusters, seed=seed )

        _distance = np.array( [ square( c, compute_distance, RES ) for c in centers ] ).min(0)

        vmax = _distance[np.logical_not(np.isinf(_distance))].max() * .5
        im   = ax.imshow( _distance, origin='lower', cmap='afmhot_r', vmin=0, vmax=vmax )
        cbar = ax.cax.colorbar( im )

        levels = [ 0.2*i for i in range( 1, 20 ) ]
        ax.contour( _distance, origin='lower', cmap='afmhot_r', levels=levels, linewidths=1, alpha=.5 )

        if not plusplus:
            for cluster_idx in range( num_clusters ):
                cluster = [ distributions[i] for i,idx in enumerate(assign) if np.isclose(idx, cluster_idx) ]
                c = centers[cluster_idx]
                enclosing = max( [ compute_distance( _d, c ) for _d in cluster ] )
                ax.contour( square( c, compute_distance, RES ), origin='lower', cmap='YlGn_r', levels=[enclosing], linewidths=2, alpha=.5 )

        markers = [ 'o', '1', '*', '2', 'x' ]
        colors  = [ 'r', 'b', 'w', 'g', 'c' ]
        for _, _dist in zip( assign, distributions ):
            eta = _dist.eta()
            ax.scatter( eta[0]*RES, eta[1]*RES, color=colors[_], edgecolor='k', linewidths=.5, marker=markers[_], s=16, alpha=.8 )

        ax.set_xticks( [0, RES] )
        ax.set_xticklabels( ['0','1'] )
        ax.set_yticks( [0, RES] )
        ax.set_yticklabels( ['0','1'] )
        ax.set_title( title )

    showdist( grid[0], Multinomial.riemannian_kcenters, Multinomial.riemannian_distance, r'$\rho_{\mathrm{FHR}}$' )
    showdist( grid[1], Multinomial.kl_kcenters,         Multinomial.kl,                  r'$\rho_{\mathrm{IG}}$' )
    showdist( grid[2], Multinomial.hilbert_kcenters,    Multinomial.hilbert_distance,    r'$\rho_{\mathrm{HG}}$' )
    showdist( grid[3], Multinomial.l1_kcenters,         Multinomial.l1_distance,         r'$\rho_{\mathrm{L1}}$' )

    fig.savefig( ofilename, bbox_inches='tight' )

def exp( clustering, dim, sigma, N, num_clusters, max_itrs, max_center_itrs=50, repeat=300, generator=0 ):
    '''
             alg -- algorithm
             dim -- simplex dimension
           sigma -- noise level
               N -- sample size
    num_clusters -- number of clusters

        max_itrs -- max #iterations (if 0 then kmeans++)
    max_center_itrs -- number of iterations during center computation

          repeat -- number of repeats
    '''

    acc = np.zeros( repeat, dtype=np.float )
    for run in range( repeat ):
        magic_number = 2017+run
        distributions, labels = artificial_dataset( N, num_clusters, magic_number, dim, sigma, generator=generator )
        assign, centers = clustering( distributions, num_clusters, seed=magic_number, max_itrs=max_itrs, max_center_itrs=max_center_itrs )
        acc[run] = metrics.adjusted_mutual_info_score( assign, labels )

    return acc.mean(), acc.std()

def main():
    if sys.argv[1].lower() == 'v':
        visualize_clusters( 'kcenters3.png', num_clusters=3, plusplus=False )
        visualize_clusters( 'kcenters5.png', num_clusters=5, plusplus=False )
        visualize_clusters( 'plusplus3.png', num_clusters=3, plusplus=True )
        visualize_clusters( 'plusplus5.png', num_clusters=5, plusplus=True )

    #elif sys.argv[1].lower() == 'd':
        #data, labels = digits()

        #print('riemannian')
        #assign = Multinomial.riemannian_kcenters( data, 10, verbose=True )
        #print( accuracy( assign, labels, None ) )

        #print('kl')
        #assign = Multinomial.kl_kcenters( data, 10, verbose=True )
        #print( accuracy( assign, labels, None ) )

        #print('hilbert')
        #assign = Multinomial.hilbert_kcenters( data, 10, verbose=True )
        #print( accuracy( assign, labels, None ) )

    elif sys.argv[1] == '+':
        # experiments on k-means++
        arr_num_clusters = [ 3, 5 ]
        arr_N            = [ 50 ]
        arr_dim          = [  9 ]
        arr_sigma        = [ 0.5, 0.9 ]
        distances = [ Multinomial.kl_distance,
                      Multinomial.rkl_distance,
                      Multinomial.skl_distance,
                      Multinomial.birkhoff_distance ]
        repeat = 300

        configs = itertools.product( arr_num_clusters, arr_N, arr_dim, arr_sigma )

        for num_clusters, N, dim, sigma in configs:
            result = []
            for _dist in distances:
                acc = np.zeros( repeat, dtype=np.float )
                for run in range( repeat ):
                    distributions, labels = artificial_dataset( N, num_clusters, 2019+run, dim, sigma, scale=True )
                    assign, centers = Multinomial.kmeansplusplus( distributions, num_clusters, _dist )
                    acc[run] = metrics.normalized_mutual_info_score( assign, labels )
                result.append( ( acc.mean(), acc.std() ) )
            result = np.array( result )
            best_mean = result[:,0].max()

            # format the resulting latex table
            for _mean, _std in result:
                if np.abs( _mean - best_mean ) < 0.02:
                    print( r'& $\bm{{{:.2f}\pm{:.2f}}}$'.format(_mean,_std), end=' ' )
                else:
                    print( r'& ${:.2f}\pm{:.2f}$'.format(_mean,_std), end=' ' )
            print( r'\\' )

    else:
        arr_num_clusters = [ 3, 5 ]
        arr_N            = [ 50, 100 ]
        arr_dim          = [  9, 255 ]
        arr_sigma        = [ 0.5, 0.9 ]
        algos = [ Multinomial.riemannian_kcenters,
                  Multinomial.kl_kcenters,
                  Multinomial.hilbert_kcenters,
                  Multinomial.euclidean_kcenters,
                  Multinomial.l1_kcenters ]

        for num_clusters, N, dim, sigma in itertools.product(
            arr_num_clusters, arr_N, arr_dim, arr_sigma ):

            result = np.array( [ exp( clustering, dim, sigma, N, num_clusters, 200, generator=1 )
                                 for clustering in algos ] )
            best_mean = result[:,0].max()

            # format the latex table
            for _mean, _std in result:
                if np.abs( _mean - best_mean ) < 0.02:
                    print( r'& $\bm{{{:.2f}\pm{:.2f}}}$'.format(_mean,_std), end=' ' )
                else:
                    print( r'& ${:.2f}\pm{:.2f}$'.format(_mean,_std), end=' ' )
            print( r'\\' )

if __name__ == '__main__':
    if len( sys.argv ) < 2:
        print( 'usage: %s [0-5V]' % sys.argv[0] )
    else:
        main()

