from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import numpy as np

class Elliptope( object ):

    ##################################################################################
    # static methods
    ##################################################################################
    @staticmethod
    def hilbert_distance( a, b ):
        return a.hilbert_distance( b )

    @staticmethod
    def euclidean_distance( a, b ):
        return a.euclidean_distance( b )

    @staticmethod
    def l1_distance( a, b ):
        return a.l1_distance( b )

    @staticmethod
    def logdet_divergence( a, b ):
        return a.logdet_divergence( b )

    @staticmethod
    def logdet_distance( a, b ):
        return a.logdet_distance( b )

    ##########################################################################################
    # clustering
    ##########################################################################################
    @staticmethod
    def kmeansplusplus( matrices, k, compute_distance ):
        '''
        choosing k matrices based on kmeans++
        this is usually for initalizing the kmeans algorithm

                matrices -- a list of matrices
                       k -- number of clusters
        compute_distance -- a distance-like function
        '''
        idx = np.random.randint( len(matrices) )
        centers   = [ matrices[idx] ]
        _distance = np.array( [ compute_distance( _d, centers[0] ) for _d in matrices ] )

        # tackle infinity distance
        infidx = np.isinf( _distance )
        idx = np.logical_not( infidx )
        _distance[infidx] = _distance[idx].max()

        # run k-means++ to get the centers
        while len( centers ) < k:
            p = _distance**2
            p /= p.sum() + matrices[0].eps

            idx = np.random.choice( range( len(matrices) ), p=p )
            centers.append( matrices[idx] )

            _distance = np.minimum( _distance, [ compute_distance( _d, centers[-1] )
                                                 for _d in matrices ] )

        # assign all distributions to nearest center
        assign      = []
        for _dist in matrices:
            distance = [ compute_distance( _dist, c ) for c in centers ]
            assign.append( np.argmin( distance ) )

        return assign
    #######################################################################
    # static methods
    #######################################################################

    def __init__( self, C ):
        '''
        '''
        self.dtype = np.float
        self.eps = np.finfo( self.dtype ).eps

        # p.s.d. matrix with diagonal entries equals to 1
        self.C = np.array( C, dtype=self.dtype )

    def __str__( self ):
        return str( self.C )

    def line_searching( self, C1, C2, max_tries=50 ):
        alpha = 2
        alpha_min = 1
        alpha_max = np.inf

        for i in range( max_tries ):
            C = (1-alpha) * C1 + alpha * C2 

            # sign is the smallest eigen-value
            w, v = np.linalg.eigh( C )
            sign = w.min()

            if np.isclose( sign, 0 ):
                #print( 'converged after {} tries!'.format(i+1) )
                break

            elif sign > 0 : # still inside the elliptope, increase alpha
                alpha_min = alpha
                if np.isinf( alpha_max ):
                    alpha *= 2
                else:
                    alpha = .5 * (alpha_min+alpha_max)

            else: # shooting too far
                alpha_max = alpha
                alpha = .5 * (alpha_min + alpha_max)

        return alpha

    def hilbert_distance( self, other ):
        '''
        Hilbert distance
        '''
        if np.allclose( self.C, other.C ): return 0

        alpha = self.line_searching( self.C, other.C )
        beta  = self.line_searching( other.C, self.C )

        if np.isclose( alpha, 1 ): return np.inf
        if np.isclose( beta, 1 ): return np.inf

        return np.log( alpha ) + np.log( beta ) - np.log( alpha - 1 ) - np.log( beta - 1 )

    def euclidean_distance( self, other ):
        '''
        Euclidean distance
        '''
        return np.linalg.norm( self.C - other.C )

    def l1_distance( self, other ):
        '''
        total variance
        '''
        return np.abs( self.C - other.C ).sum()

    def logdet_divergence( self, other ):
        prod = np.dot( self.C, np.linalg.inv( other.C ) )
        div = np.trace( prod )-np.linalg.slogdet( prod )[1]-self.C.shape[0]
        return np.maximum( div, 0 )

    def logdet_distance( self, other ):
        return np.sqrt( self.logdet_divergence( other ) )


