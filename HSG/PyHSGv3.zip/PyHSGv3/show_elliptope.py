#!/usr/bin/env python

from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from Elliptope import Elliptope

def corr_matrix():
    A = np.random.randn( 3, 3 )
    #D = np.array( [1, np.random.uniform(1e-3,1), 1e-3] )
    #np.random.shuffle( D )
    #C = np.dot( A, np.dot( np.diag(D), A.T ) )
    C = np.dot( A, A.T )
    a = np.diag( np.diag( C )**(-.5) )
    C = a.dot( C.dot( a ) )
    return C

X = []
Y = []
Z = []
for i in range( 10000 ):
    C = corr_matrix()

    X.append( C[0,1] )
    Y.append( C[0,2] )
    Z.append( C[1,2] )

X = np.array( X )
Y = np.array( Y )
Z = np.array( Z )
R = np.sqrt( X**2 + Y**2 + Z**2 )

idx = np.argsort( R )
X = X[idx]
Y = Y[idx]
Z = Z[idx]
R = R[idx]

fig = plt.figure( figsize=(5,5), dpi=100 )
ax = fig.add_subplot(111, projection='3d')
ax.scatter( X, Y, Z, c=R, cmap='afmhot_r' )

for angle in [30, 60]:
    ax.view_init( 30, angle )
    plt.savefig( 'elliptope{}.png'.format( angle ), bbox_inches='tight' )

