from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

from Multinomial import Multinomial
import numpy as np

def square( ref, compute_distance, RES ):
    '''
    comptue the distance from any point to ref
    '''

    _distance = np.inf * np.ones( [RES, RES] )

    for i in range( RES ):
        for j in range( RES-i ):
            _distance[i,j] = compute_distance( Multinomial( p=( RES-i-j-.5, j+.5, i+.5 ) ), ref )

    return _distance

def harpe_square( ref, compute_distance, RES, R ):
    '''
    cojmpute distance from any point to ref
    '''

    _distance = np.inf * np.ones( [RES,RES] )

    a = 2 * R / ( RES - 1 )
    for i in range( RES ):
        for j in range( RES ):
            h1 = a * j - R
            h2 = a * i - R
            _distance[i,j] = compute_distance( Multinomial( harpe=(h1,h2) ), ref )
    return _distance

