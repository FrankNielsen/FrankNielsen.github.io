#!/usr/bin/env python

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

import numpy as np
from Multinomial import Multinomial
import numpy as np
import sys, time

import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype']  = 42
matplotlib.rcParams['font.family']  = "serif"
matplotlib.rcParams['font.size']    = 9

def compute_kappa( compute_distance, dim, repeat=1e6, eps=1e-10 ):
    '''
    experimentally evaluate the kappa constant
    '''
    kappa = []
    for run in range( int(repeat) ):
        p = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        q = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        r = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )

        pq = compute_distance( p, q )**2
        pr = compute_distance( p, r )**2
        qr = compute_distance( q, r )**2

        # avoid divide by 0
        if np.isclose( pr+qr, 0 ): continue

        _k = pq/(pr+qr)
        if np.isinf( _k ) or np.isnan( _k ): continue

        kappa.append( _k )

    kappa = np.array( kappa )
    print( 'statistics based on {} runs'.format( kappa.size ) )
    return kappa.min(), kappa.mean(), kappa.std(), kappa.max()

def exp( compute_distance, dim_range, ax, title ):
    start_t = time.time()

    print( 'experimenting {0}'.format( title ) )
    result = np.array( [ compute_kappa( compute_distance, d+1 ) for d in dim_range ] ).T
    ax.plot( dim_range, result[3], label='max' )
    ax.errorbar( dim_range, result[1], yerr=result[2], label='mean$\pm$std', fmt='--o' )
    ax.plot( dim_range, result[0], label='min' )

    ax.legend( loc='best' )

    ax.set_xticks( dim_range )
    ax.set_title( title + r", $\max(\kappa_1)={0:.2f}$".format( result[3].max() ) )
    ax.set_xlabel( 'd' )
    ax.set_ylabel( r'$\kappa_1$' )

    time_cost = ( time.time() - start_t ) / 60
    print( 'finished in {:.1f} minutes'.format( time_cost ) )

def skl( a, b ):
    '''
    square root of symmetric KL
    '''
    return np.sqrt( .5 * ( a.kl( b ) + b.kl( a ) ) )

def main():
    np.random.seed( 2017 ) # make the exp repeatable

    dim_range = range(1,11)
    fig = plt.figure( figsize=(8,2), dpi=200 )
    grid = ImageGrid( fig, 111,
                 nrows_ncols=(1,4),
                 axes_pad=0.1,
                 share_all=False,
                 aspect=False
                 )

    print( 'Warning: this takes 2 hours' )
    exp( Multinomial.riemannian_distance, dim_range, grid[0], r'$\rho^2_{\mathrm{FHR}}$' )
    exp( skl,                             dim_range, grid[1], r'$\rho_{\mathrm{IG}}$' )
    exp( Multinomial.hilbert_distance,    dim_range, grid[2], r'$\rho^2_{\mathrm{HG}}$' )
    exp( Multinomial.l1_distance,         dim_range, grid[3], r'$\rho^2_{\mathrm{L1}}$' )

    fig.savefig( 'kappa.png', bbox_inches='tight' )

if __name__ == '__main__':
    main()

