#!/usr/bin/env python

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

import numpy as np
from Multinomial import Multinomial
import numpy as np
import sys, time

import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype']  = 42
matplotlib.rcParams['text.usetex']  = True
matplotlib.rcParams['font.family']  = "serif"
matplotlib.rcParams['font.size']    = 10

def v( mul ):
    h = np.log( mul.p + mul.eps )
    h -= h.mean()
    return h

def compute_alpha_beta( l, dim, repeat=1e6, eps=1e-10 ):
    '''
    experimentally evaluate the kappa constant
    '''
    r = []
    for run in range( int(repeat) ):
        p = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        q = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )

        hd    = p.hilbert_distance( q )
        if np.isclose( hd, 0 ): continue

        lnorm = np.linalg.norm( v(p) - v(q), l )
        if np.isclose( lnorm, 0): continue

        ratio = hd / lnorm
        if np.isinf( ratio ) or np.isnan( ratio ): continue

        r.append( ratio )

    r = np.array( r )
    print( 'statistics based on {} records'.format( r.size ) )
    return r.min(), r.mean(), r.std(), r.max()

def exp( dim_range, l, ax, title ):
    start_t = time.time()

    print( 'experimenting {0}'.format(title) )
    result = np.array( [ compute_alpha_beta( l, d+1 ) for d in dim_range ] ).T
    ax.plot( dim_range, result[3], label='max' )
    ax.errorbar( dim_range, result[1], yerr=result[2], label='mean$\pm$std', fmt='--o' )
    ax.plot( dim_range, result[0], label='min' )

    ax.legend( loc='best' )

    ax.set_xticks( dim_range )
    ax.set_title( title )
    ax.set_xlabel( 'd' )
    ax.set_ylabel( r'$\Vert{v}\Vert_{H}/\Vert{v}\Vert_l$' )

    time_cost = ( time.time() - start_t ) / 60
    print( 'finished in %.1f minutes' % time_cost )

def main():
    np.random.seed( 2017 ) # make the exp repeatable

    dim_range = range( 1, 11 )
    fig = plt.figure( figsize=(9,2), dpi=200 )
    grid = ImageGrid( fig, 111,
                 nrows_ncols=(1,4),
                 axes_pad=0.1,
                 share_all=False,
                 aspect=False )

    print( 'warning: this takes 2 hours' )
    for i in range( 4 ):
        exp( dim_range, i+1, grid[i], r'$\rho_{{\mathrm{{L{0}}}}}$'.format(i+1) )

    fig.savefig( 'alphabeta.pdf', bbox_inches='tight' )

if __name__ == '__main__':
    main()

