#!/usr/bin/env python

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

from Multinomial import Multinomial
import numpy as np
import sys, time

def exp( compute_distance, dim, eps=1e-4 ):
    '''
    experimentally evaluate the kappa constant
    '''
    for run in range( int(100000) ):
        px = np.random.dirichlet( np.ones(dim) ) + eps
        qx = np.random.dirichlet( np.ones(dim) ) + eps
        px /= px.sum()
        qx /= qx.sum()

        #px2 = px.reshape( [int(dim/2),2] ).sum(1)
        #qx2 = qx.reshape( [int(dim/2),2] ).sum(1)
        px2 = np.hstack( [ px[0]+px[1], px[2:] ] )
        qx2 = np.hstack( [ qx[0]+qx[1], qx[2:] ] )

        pq  = compute_distance( Multinomial(  px ), Multinomial(  qx ) )
        pq2 = compute_distance( Multinomial( px2 ), Multinomial(  qx2 ) )
        if( pq2 > pq + eps ):
            print( 'exception: pq={} pq2={}'.format( pq, pq2) )
            sys.exit(0)

def main():
    np.random.seed( 2017 )
    exp( Multinomial.hilbert_distance, 10 )

if __name__ == '__main__':
    main()

