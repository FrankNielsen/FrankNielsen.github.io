#!/usr/bin/env python

'''
an expeirment to plot the convergence curve
of Hilbert center computation
'''

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype']  = 42
matplotlib.rcParams['font.family'] = "serif"
matplotlib.rcParams['font.size'] = 10

from Multinomial import Multinomial

import numpy as np
import sys, time

eps = 1e-10
true_itrs = 10000
max_itrs  = 300
repeat = 1

np.random.seed( 2017 )
fig = plt.figure( figsize=(6,3), dpi=300 )
ax1, ax2 = ImageGrid( fig, 111, nrows_ncols=(1,2), axes_pad=0.5, aspect=False, label_mode='all' )
start_t = time.time()

for n_samples in [ 10, 100 ]:
    for dim in [ 10, 256 ]:
        print( 'd={0}; n={1}'.format( dim-1, n_samples ) )

        err    = np.zeros( [repeat, max_itrs] )
        relerr = np.zeros( [repeat, max_itrs] )
        for run in range( repeat ):
            print( 'generating distributions...', end=' ' )
            center = np.random.dirichlet( np.ones(dim) )
            theta = np.random.randn( n_samples, dim ) + np.log( center+eps )
            distributions = [ Multinomial(p) for p in np.exp( theta ) ]

            print( 'true center...', end=' ' )
            trueC = Multinomial.hilbert_center( distributions, max_itrs=true_itrs )
            radius = max( [ Multinomial.hilbert_distance( _d, trueC ) for _d in distributions ] )

            print( 'convergence curve...' )
            C = Multinomial( np.random.choice( distributions ).p )
            for i in range( 1, max_itrs+1 ):
                err[run,i-1] = relerr[run,i-1] = C.hilbert_distance( trueC )
                relerr[run,i-1] /= radius

                far = np.argmax( [ _d.hilbert_distance( C ) for _d in distributions ] )
                C = C.hilbert_cut( distributions[far], 1/(i+1) )

        ax1.plot( err.mean(0),    label='d={0}; n={1}'.format( dim-1, n_samples ), alpha=.8 )
        ax2.plot( relerr.mean(0), label='d={0}; n={1}'.format( dim-1, n_samples ), alpha=.8 )

ax1.set_xlabel( '#iterations' )
ax1.set_xlim( [0,max_itrs] )
ax1.set_ylabel( 'Hilbert distance' )
ax1.legend( loc='best' )

ax2.set_xlabel( '#iterations' )
ax2.set_xlim( [0,max_itrs] )
ax2.set_ylabel( 'relative Hilbert distance' )
ax2.set_ylim( [0,1] )
ax2.legend( loc='best' )
fig.suptitle( 'Hilbert distance with the true Hilbert center' )

fig.savefig( 'convergence.pdf', bbox_inches='tight' )
print( 'finished in {0:.2} hours'.format( (time.time()-start_t)/3600 )  )
