#!/usr/bin/env python

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype']  = 42
matplotlib.rcParams['font.family'] = "serif"
matplotlib.rcParams['font.size'] = 10

from square import square, harpe_square
from Multinomial import Multinomial

def euc_square( RES, R ):
    _distance = np.inf * np.ones( [RES,RES] )

    a = 2 * R / ( RES - 1 )
    for i in range( RES ):
        for j in range( RES ):
            h1 = a * j - R
            h2 = a * i - R
            _distance[i,j] = np.sqrt( h1**2 + h2**2 + (h1+h2)**2 )
    return _distance

def show_center( ref, ofilename, N=20, RES=200, seed=2017 ):
    '''
    show the Hilbert center of a point cloud

    ref -- center of the point cloud
    ofilename -- output filename
    if R > 0: show harpe coordinates instead
    '''

    print( 'generating a point cloud (N={0})'.format(N) )
    np.random.seed( seed )
    C = Multinomial( np.array( ref, dtype=np.float ))

    print( 'computing distance grid with resolution={0}'.format(RES) )
    fig = plt.figure( figsize=(4,8), dpi=300 )
    grid = ImageGrid( fig, 111,
                 nrows_ncols=(1,1),
                 axes_pad=0.5,
                 share_all=False,
                 cbar_location="right",
                 cbar_mode="each",
                 cbar_size="3%",
                 cbar_pad=0,
                 )

    def showdist( ax, compute_center, compute_distance, title, R=-1 ):
        _distance = harpe_square( C, compute_distance, RES, R )
        euc_distance = euc_square( RES, R )

        levels = [ 0.5*i for i in range( 1, 20 ) ]
        CS = ax.contour( _distance, origin='lower', colors='k', levels=levels, linewidths=1, alpha=.7, inline=1 )
        plt.clabel( CS, levels, inline=1, fmt='%1.1f', fontsize=12 )

        ax.contour( euc_distance, origin='lower', colors='k', levels=[1], linewidths=2, alpha=1 )

        ax.set_xticks( [0, RES] )
        ax.set_yticks( [0, RES] )
        if R < 0:
            ax.set_xticklabels( ['0','1'] )
            ax.set_yticklabels( ['0','1'] )
        else:
            ax.set_xticklabels( [R,-R] )
            ax.set_yticklabels( [R,-R] )
        ax.set_title( title )

    showdist( grid[0], Multinomial.hilbert_center, Multinomial.hilbert_distance, '', R=2 )

    fig.savefig( ofilename, bbox_inches='tight' )

if __name__ == '__main__':
    show_center( (1/3,1/3,1/3), 'harpe{0}.pdf'.format(2017), seed=2017, RES=200 )

