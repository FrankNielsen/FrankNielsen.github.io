#!/usr/bin/env python

from __future__ import division, print_function, absolute_import
import numpy as np
from sklearn import metrics

EPS = np.finfo(np.float).eps

def kmeansplusplus( matrices, k, compute_distance ):
    '''
    choosing k matrices based on kmeans++
    this can be used for initalizing the kmeans algorithm

            matrices -- a list of psd matgrices
                   k -- number of clusters
    compute_distance -- a distance-like function

    return the list of cluster labels,
    as well as the list of Multinomial centers
    '''
    idxes = [ i for i in range( len(matrices) ) ]
    centers   = [ matrices[np.random.choice( idxes )] ]
    _distance = np.array( [ compute_distance( _d, centers[0] )
                            for _d in matrices ], dtype=np.float )

    # tackle infinity distance
    infidx = np.logical_or( np.isinf( _distance ), np.isnan( _distance ) )
    idx = np.logical_not( infidx )
    _distance[infidx] = _distance[idx].max()

    # run k-means++ to get the centers
    while len(centers) < k:
        p = _distance**2
        p /= ( p.sum() + EPS )

        centers.append( matrices[np.random.choice( idxes, p=p )] )

        _distance = np.minimum( _distance, [ compute_distance( _d, centers[-1] )
                                             for _d in matrices ] )

    # assign all matrices to nearest center
    assign      = []
    for _dist in matrices:
        assign.append( np.argmin( [ compute_distance( _dist, c ) for c in centers ] ) )

    return np.array( assign ), centers

def kl( A, B ):
    '''
    KL divergence between G(0,A) and G(0,B)
    '''
    assert( A.shape[0] == A.shape[1] == B.shape[0] == B.shape[1] )

    div = np.linalg.solve( B, A )
    sign, logdet = np.linalg.slogdet( div )
    assert( sign > 0 )

    return 0.5 * np.trace( div ) - 0.5 * logdet  - 0.5 * A.shape[0]

def kl_distance( A, B ):
    return np.sqrt( np.maximum( kl( A, B ), 0 ) )

def rkl_distance( A, B ):
    return np.sqrt( np.maximum( kl( B, A ), 0 ) )

def skl_distance( A, B ):
    return np.sqrt( np.maximum( 0.5 * kl( A, B ) + 0.5 * kl( B, A ), 0 ) )

def thompson( A, B ):
    assert( A.shape[0] == A.shape[1] == B.shape[0] == B.shape[1] )

    lamb = np.linalg.eigvals( np.linalg.solve( A, B ) )
    return ( np.abs( np.log( lamb ) ) ).max()

def gendata( k, dim, N ):
    matrices = []
    labels   = []

    for cluster in range( k ):
        Q, R = np.linalg.qr( np.random.randn( dim, dim ) )
        lamb = np.random.gamma( 5, 1, size=dim )
        C = np.dot( Q * lamb, Q.T )

        for i in range( N ):
            A = np.random.randn( dim, dim )
            matrices.append( C + 0.3 * np.dot( A, A.T ) )
            labels.append( cluster )

    return matrices, np.array( labels )

np.random.seed( 2019 )
repeat = 300
dim = 2
num_clusters = 5
cluster_size = 50

result = []
for _dist in [ kl_distance, rkl_distance, skl_distance, thompson ]:
    acc = np.zeros( repeat, dtype=np.float )
    for run in range( repeat ):
        matrices, labels = gendata( num_clusters, dim, cluster_size )
        assign, centers = kmeansplusplus( matrices, num_clusters, _dist )

        acc[run] = metrics.normalized_mutual_info_score( assign, labels )

    result.append( ( acc.mean(), acc.std() ) )
result = np.array( result )
best_mean = result[:,0].max()

# format the latex table
for _mean, _std in result:
    if np.abs( _mean - best_mean ) < 0.01:
        print( r'& $\bm{{{:.2f}\pm{:.2f}}}$'.format(_mean,_std), end=' ' )
    else:
        print( r'& ${:.2f}\pm{:.2f}$'.format(_mean,_std), end=' ' )
print( r'\\' )

