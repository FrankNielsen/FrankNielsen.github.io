#!/bin/bash

./test_kmeans.py 0
./test_kmeans.py 1
./test_kmeans.py 2
./test_kmeans.py 3
./test_kmeans.py 4
./test_kmeans.py 5
