#!/usr/bin/env python

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import ImageGrid

matplotlib.rcParams['pdf.fonttype'] = 42
matplotlib.rcParams['ps.fonttype']  = 42
matplotlib.rcParams['font.family'] = "serif"
matplotlib.rcParams['font.size'] = 10

from square import square, harpe_square
from Multinomial import Multinomial

def show_center( ref, ofilename, N=20, RES=500, seed=2017 ):
    '''
    show the Hilbert center of a point cloud

    ref -- center of the point cloud
    ofilename -- output filename
    if R > 0: show harpe coordinates instead
    '''

    print( 'generating a point cloud (N={0})'.format(N) )
    np.random.seed( seed )
    theta = 0.5 * np.random.randn( N, 3 ) + np.log( np.array( ref, dtype=np.float ) )
    distributions = [ Multinomial(p) for p in np.exp( theta ) ]

    print( 'computing distance grid with resolution={0}'.format(RES) )
    fig = plt.figure( figsize=(8,2), dpi=300 )
    grid = ImageGrid( fig, 111,
                 nrows_ncols=(1,4),
                 axes_pad=0.5,
                 share_all=False,
                 cbar_location="right",
                 cbar_mode="each",
                 cbar_size="3%",
                 cbar_pad=0,
                 )

    def showdist( ax, compute_center, compute_distance, title, R=-1 ):
        C = compute_center( distributions, verbose=True )
        if R < 0:
            _distance = square( C, compute_distance, RES )
        else:
            _distance = harpe_square( C, compute_distance, RES, R )

        vmax = _distance[np.logical_not(np.isinf(_distance))].max() * .6
        im   = ax.imshow( _distance, origin='lower', cmap='afmhot_r', vmin=0, vmax=vmax )
        cbar = ax.cax.colorbar( im )

        levels = [ 0.2*i for i in range( 1, 20 ) ]
        ax.contour( _distance, origin='lower', cmap='afmhot_r', levels=levels, linewidths=1, alpha=.7 )

        boldlevel = max( [ compute_distance( _dist, C ) for _dist in distributions ] )
        ax.contour( _distance, origin='lower', cmap='YlGn_r', levels=[boldlevel], linewidths=2, alpha=.5 )

        for _dist in distributions:
            if R < 0:
                eta = _dist.eta()
                ax.scatter( eta[0]*RES, eta[1]*RES, color='w', edgecolor='k', marker='o', s=9 )
            else:
                h = _dist.harpe()
                ax.scatter( .5*(h[0]+R)*(RES-1)/R,
                            .5*(h[1]+R)*(RES-1)/R,
                            color='w', edgecolor='k', marker='o', s=9 )

        ax.set_xticks( [0, RES] )
        ax.set_yticks( [0, RES] )
        if R < 0:
            ax.set_xticklabels( ['0','1'] )
            ax.set_yticklabels( ['0','1'] )
        else:
            ax.set_xticklabels( [R,-R] )
            ax.set_yticklabels( [R,-R] )
        ax.set_title( title )

    showdist( grid[0], Multinomial.riemannian_center, Multinomial.riemannian_distance, 'Riemannian center' )
    showdist( grid[1], Multinomial.kl_center, Multinomial.kl,  'IG center' )
    showdist( grid[2], Multinomial.hilbert_center, Multinomial.hilbert_distance,  'Hilbert center' )
    showdist( grid[3], Multinomial.l1_center, Multinomial.l1_distance, 'L1 center' )

    #showdist( grid[0], Multinomial.hilbert_center, Multinomial.hilbert_distance,  'Simplex' )
    #showdist( grid[1], Multinomial.hilbert_center, Multinomial.hilbert_distance,  'After isometry', R=2 )

    fig.savefig( ofilename, bbox_inches='tight' )

def show_ball( refs, ofilename, RES=200 ):
    '''
    Show a Hilbert Ball of different radius using contour plots
    '''
    n = len(refs)
    fig = plt.figure( figsize=(n*3,3), dpi=300 )
    grid  = ImageGrid( fig, 111,
                 nrows_ncols=(1,n),
                 axes_pad=0.5,
                 share_all=True,
                 cbar_location="right",
                 cbar_mode="single",
                 cbar_size="3%",
                 cbar_pad=0,
                 )

    def single_ball( ax, ref ):
        # the reference distribution
        ref = Multinomial( p=ref )
        print( 'reference: %s' % ref )

        HD = square( ref, Multinomial.hilbert_distance, RES )

        im   = ax.contour( HD, 20, vmin=0, vmax=8, origin='lower', linewidths=1 )
        cbar = ax.cax.colorbar( im )

        eta = ref.eta()
        ax.scatter( eta[0]*RES, eta[1]*RES, color='black', edgecolor='black', marker='o', s=15 )

        ax.set_xticks( [0, RES] )
        ax.set_xticklabels( ['0','1'] )
        ax.set_yticks( [0, RES] )
        ax.set_yticklabels( ['0','1'] )

    for i in range( n ):
        single_ball( grid[i], refs[i] )
    fig.savefig( ofilename, bbox_inches='tight' )

def show_div( ref, profiles, ncols, ofilename, RES=100 ):
    '''
    visualize a grid of distance profiles

          ref -- the reference point
     profiles -- a list of (distance, name)
        ncols -- #cols in the visualization
    ofilename -- output filename
    '''
    nrows = int( np.ceil( len(profiles)/ncols ) )

    # the reference distribution
    ref = Multinomial( p=ref )
    print( 'reference: {}'.format( ref ) )

    # visualize
    fig = plt.figure( figsize=(ncols*2,nrows*2), dpi=100 )
    grid = ImageGrid( fig, 111,
                 nrows_ncols=(nrows,ncols),
                 axes_pad=0.5,
                 share_all=True,
                 cbar_location="right",
                 cbar_mode="each",
                 cbar_size="3%",
                 cbar_pad=0,
                 )

    def showdist( ax, compute_distance, title, vmax ):
        dist = square( ref, compute_distance, RES )

        if vmax is None: vmax = dist[np.logical_not(np.isinf(dist))].max() * .3
        im   = ax.imshow( dist, origin='lower', cmap='afmhot_r', vmin=0, vmax=vmax )
        cbar = ax.cax.colorbar( im )

        levels = [ 0.2*i for i in range( 1, 20 ) ]
        im   = ax.contour( dist, origin='lower', cmap='afmhot_r', levels=levels, linewidths=1, alpha=.5 )

        eta = ref.eta()
        ax.scatter( eta[0]*RES, eta[1]*RES, color='black', edgecolor='black', marker='o', s=15 )

        ax.set_xticks( [0, RES] )
        ax.set_xticklabels( ['0','1'] )
        ax.set_yticks( [0, RES] )
        ax.set_yticklabels( ['0','1'] )
        ax.set_title( title )
    
    for i, (compute_distance, title, vmax) in enumerate( profiles ):
        showdist( grid[i], compute_distance, title, vmax )

    fig.savefig( ofilename, bbox_inches='tight' )

def show_distance_profiles():
    # produce distance comparison figure
    profiles = \
      [ ( Multinomial.euclidean_distance,  'Euclidean distance',  None ),
        ( Multinomial.cs_divergence,       'CS divergence',       None ),
        ( Multinomial.riemannian_distance, 'Riemannian distance', None ),
        ( Multinomial.kl,                  'KL divergence',       None ),
        ( Multinomial.hellinger_distance,  'Hellinger distance',  None ),
        ( Multinomial.hilbert_distance,    'Hilbert distance',    None ),
        ( Multinomial.l1_distance,         'L1 distance',         None )
      ]

    # alpha divergence
    for alpha in np.linspace( -2, 2, 9 ):
        def __alphadivergence( a, b, alpha=alpha ):
            return a.alphadiv( b, alpha )
        profiles.append( ( __alphadivergence, r'({0:+.1f})-divergence'.format( alpha ), .8 ) )

    show_div( (3,3,1), profiles, 4, 'categories1.png' )
    show_div( (5,1,1), profiles, 4, 'categories2.png' )

if __name__ == '__main__':
    show_distance_profiles()

    # hilbert balls
    #show_ball( [ (1,1,1), (4,1,1), (.2,1,1), (2,8,1), (1,1,9) ], 'ball.pdf' )
    #show_ball( [ (1,1,1) ],   'ball1.pdf' )
    #show_ball( [ (4,1,1) ],   'ball2.pdf' )
    #show_ball( [ (20,1,1) ], 'ball3.pdf' )
    #show_ball( [ (.2,1,1) ],  'ball4.pdf' )
    #show_ball( [ (2,8,1) ],   'ball5.pdf' )
    #show_ball( [ (1,1,9) ],   'ball6.pdf' )

    # show a point cloud and smallest encolsing ball
    #show_center( (1/3,1/3,1/3), 'center1.pdf' )
    #show_center( (1/6,2/3,1/6), 'center2.pdf' )
    #show_center( (1/7,3/7,3/7), 'center3.pdf' )

    #for s in range( 2017, 2030 ):
    #   show_center( (1/3,1/3,1/3), 'harpe{0}.pdf'.format(s), seed=s, RES=500 )

