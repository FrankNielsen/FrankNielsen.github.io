#!/usr/bin/env python

from __future__ import print_function
from __future__ import division
from __future__ import absolute_import

from Multinomial import Multinomial
import numpy as np
import sys

def parallelogram( harpe=False ):
    # A+C = B+D 
    A = Multinomial( p=(1,1,1) )
    C = Multinomial( p=(1,4,1) )
    B = Multinomial( p=(2,3,1) )

    if harpe:
        O = Multinomial( harpe=0.5*(A.harpe()+C.harpe()) )
        D = Multinomial( harpe=2*O.harpe()-B.harpe() )
        assert( np.allclose( A.harpe()+C.harpe(), B.harpe()+D.harpe() ) )
    else:
        O = Multinomial( p=0.5*(A.p+C.p) )
        D = Multinomial( p=(2*O.p-B.p) )
        assert( np.allclose( A.p+C.p, B.p+D.p ) )

    left  = 2*( A.hilbert_distance(B)**2 + B.hilbert_distance(C)**2 )
    right = A.hilbert_distance(C)**2 + B.hilbert_distance(D)**2

    if np.abs( left-right ) > 1e-3:
        print( "HSG failed palallelogram law" )
        print( 'A', A )
        print( 'B', B )
        print( 'C', C )
        print( 'D', D )
        print( "left={} right={}\n".format( left, right ) )

def semi_parallelogram( compute_distance, dim, eps=1e-1 ):
    '''
    test that HSG fails the semi-parallelogram law
    '''
    for run in range( int(1000) ):
        x1 = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        x2 = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        z = x1.hilbert_cut( x2, 0.5 )

        d12 = compute_distance( x1, x2 )
        d1z = compute_distance( x1, z )
        d2z = compute_distance( x2, z )

        assert( np.isclose( d1z, d2z ) )
        assert( np.isclose( 2*d1z, d12 ) )

        for i in range( 10 ):
            x = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )

            left  = d12**2 + 4*(compute_distance( x, z )**2)
            right = 2*(compute_distance(x,x1)**2) + 2*(compute_distance(x,x2)**2)

            if left > right + eps:
                print( 'HSG failed the semi-Parallelogram law' )
                print( 'x1=', x1 )
                print( 'x2=', x2 )
                print( '{} > {}\n'.format( left, right ) )
                return

def non_positive_curvature( dim, eps=0.1 ):
    for run in range( int(1000) ):
        x = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        y = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )
        u = Multinomial( np.random.dirichlet( np.ones(dim) ) + eps )

        mu1 = x.hilbert_cut( u, 0.5 )
        mu2 = y.hilbert_cut( u, 0.5 )

        assert( np.isclose( mu1.hilbert_distance(x), mu1.hilbert_distance(u) ) )
        assert( np.isclose( 2*mu1.hilbert_distance(x), x.hilbert_distance(u) ) )
        assert( np.isclose( mu2.hilbert_distance(y), mu2.hilbert_distance(u) ) )
        assert( np.isclose( 2*mu2.hilbert_distance(y), y.hilbert_distance(u) ) )

        left  = mu1.hilbert_distance( mu2 )
        right = 0.5 * x.hilbert_distance( y )

        if left > right + eps:
            print( 'HSG failed the "non-positive curvature in the sense of Busemann"' )
            print( 'x=', x )
            print( 'y=', y )
            print( 'u=', u )
            print( '{} > {}\n'.format( left, right ) )
            return

    print( 'HSG satisfies the "non-positive curvature in the sense of Busemann"' )

if __name__ == '__main__':
    np.random.seed( 2018 )

    non_positive_curvature( 3 )
    semi_parallelogram( Multinomial.hilbert_distance, 3 )
    parallelogram( True )
    parallelogram( False )
