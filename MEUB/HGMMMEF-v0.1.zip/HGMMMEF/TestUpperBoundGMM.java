// HGMMMEF Frank.Nielsen@acm.org

class TestUpperBoundGMM
{
	
	
public static void main(String[] args)	
{System.out.println("MaxEnt upper bounds for the differential entropy of Gaussian mixture models");
	TestGMM();
//TestRayleigh();	
//TestAMEF();
//TestS();	
//TestK1();	
//TestMEF();
}

static void TestRayleigh()
{
double theta=-1-Math.random();
double l=6;

double FR=MEF.posFRie(l,theta);
double F=MEF.posF(l,theta);
System.out.println(l+" log normalizer: Rie "+FR+" F cf "+F );

double HR=MEF.posHRie(l,theta,F);

System.out.print(l+" Entropy a Rie:"+HR+" Htheta "+MEF.posHtheta(l,theta));

double eta=MEF.eta(theta,l);
System.out.println("   Heta="+MEF.posHeta(l,eta));	
}



// whant log s_l+1/s_l close to zero
static void TestS()
{
int k=2;
System.out.println("log sigma");
GMM gmm=GMM.random(k);	
gmm.w[0]=gmm.w[1]=0.5;
gmm.mu[0]=gmm.mu[1]=0.0;
gmm.sigma[0]=gmm.sigma[1]=1.0;

// double eps=0;
double eps=1.0e-1;
gmm.sigma[1]=gmm.sigma[0]+eps;
double l=5;
	
for(l=1;l<=100;l+=5.0)
{

double lhs=Math.log(gmm.sigmal(l+1)/gmm.sigmal(l));	

System.out.println(l+" "+lhs);	
	}
	
}


// k=1 and bounds
static void TestK1()
{int l;
double sigma=1+1000000*Math.random();
double H=GMM.H1(sigma); // exact
for(l=1;l<10;l++)
{
double etam=Gaussian.absMoment(l,sigma);
double Heta=MEF.Heta(l,etam);	

System.out.println(l+" "+H+" "+Heta);
}

}

// AMEF log-normalizer and entropy
static void TestAMEF()
{
double theta=-(1+Math.random());
int l,i;

for(i=1;i<=10;i++)
{
l=i;//l=7*i;	
//System.out.println(l+" "+MEF.FaRie(l,theta)+" "+MEF.Fafc(l,theta));
double Fal=MEF.Fafc(l,theta);
double HaRie=MEF.Hatheta(l,theta,Fal);
double Ha=MEF.Hatheta(l,theta);
System.out.print(l+" Entropy a Rie:"+HaRie+ " Htheta "+Ha );

double eta=MEF.eta(theta,l);
System.out.println("   Heta="+MEF.Haeta(l,eta));
}
	
}


	
static void Test2()
{
int i,l;
double delta;

for(l=2;l<30;l+=2)
{
delta=MEF.b(l+2)+(1.0/(double)(l+2))*MEF.logz(l+2)-
(MEF.b(l)+(1.0/(double)(l))*MEF.logz(l));	

System.out.println(delta);
}
	
}
	
	

static void TestMEF()
{double theta=-3*(1+Math.random()); 
int l=8;
boolean check=false;
double Ftheta=MEF.FRie(l,theta);

double m=4+Math.random(); 
double s=2+Math.random();

m=0;s=1;

if (!check)
{
System.out.println("Check log-normalizer to get a ls proba:"+MEF.proba(l,theta,Ftheta,m,s));

double Hrls=MEF.HRie(l,theta,Ftheta,m,s);
double Hthetals=MEF.Htheta(l,theta)+Math.log(s);

System.out.println("H ls: "+Hrls+" "+Hthetals);
}

if (check)
System.out.println("Check log-normalizer to get a proba:"+MEF.proba(l,theta,Ftheta));

if (check){
double FR=MEF.FRie(l,theta);
double Fc1=MEF.Ffc1(l,theta);
double Fc2=MEF.Ffc2(l,theta);

System.out.println("log-normalizer: "+FR+" "+Fc1+" "+Fc2);
}

double Hr=MEF.HRie(l,theta, Ftheta);
double Hfc1=MEF.Htheta(l,theta);

System.out.println("Entropy: HRie="+ Hr+" Htheta="+Hfc1);

double eta=MEF.eta(theta,l);
if (check){
double theta2=MEF.theta(eta,l);
System.out.println("coord: "+ theta+" "+eta+" "+theta2);
}

double Hfc2=MEF.Heta(l,eta);
System.out.println("Entropy: "+ Hfc2);
}



static void TestGMM()
{int k=2;
System.out.println("Test H upper bounds on entropy of GMMs");

for(int nbtest=0;nbtest<10;nbtest++)
{

GMM gmm=GMM.random(k);
gmm.mu[0]=	gmm.mu[1]=0;
System.out.println("Random GMM:"+gmm);
int nsample=1000000;
double HRie=GMM.Hsto(gmm,nsample);

System.out.println("H stochastic (nsamples="+nsample+"):"+HRie+ " (no guarantee!)");


System.out.println("Upper bound MEU1:"+GMM.Habs(gmm));
System.out.println("Upper bound MEU2:"+GMM.Hvar(gmm));

}
/*
int i;
for(i=1;i<5;i++)
{
int p=2*i;
double mom=gmm.moment(2*i);
double U=MEF.Heta(2*i,mom);

	
}
*/


}

}