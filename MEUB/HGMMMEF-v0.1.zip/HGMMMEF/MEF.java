
class MEF
{
static int step=10000000;
static double minx=-10,maxx=-minx,dx=(maxx-minx)/(double)step;
	
int l; // degree

// F Riemann
static double FRie(double l, double theta)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+=Math.exp(Math.pow(x,l)*theta);}

return Math.log(res*dx);
}	


static double posFRie(double l, double theta)
{double x; double res=0;

for(x=0;x<=maxx;x+=dx)
	{res+=Math.exp(Math.pow(x,l)*theta);}

return Math.log(res*dx);
}	

	
// AMEF	
static double FaRie(double l, double theta)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+=Math.exp(Math.pow(Math.abs(x),l)*theta);}

return Math.log(res*dx);
}



static double Fafc(double l,double theta)
{
return Math.log(2)+	logGamma(1.0/(double)l) - Math.log(l)
   -(1.0/(double)l)*Math.log(-theta);
}

static double posF(double l,double theta)
{
return 	logGamma(1.0/(double)l) - Math.log(l)
   -(1.0/(double)l)*Math.log(-theta);
}
	

static double proba(double l, double theta, double Ftheta)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+=Math.exp(Math.pow(x,l)*theta);}

return res*dx/Math.exp(Ftheta);
}

static double density(double x, double l, double theta, double Ftheta)
{return Math.exp(Math.pow(x,l)*theta-Ftheta);}


// location scale with dispersion s parameter
static double densityls(double x, double l, double theta, double Ftheta, double m, double s)
{return (1/s)*Math.exp(Math.pow((x-m)/s,l)*theta-Ftheta);}

static double logdensityls(double x, double l, double theta, double Ftheta, double m, double s)
{return Math.pow((x-m)/s,l)*theta-Ftheta-Math.log(s);}

static double proba(double l, double theta, double Ftheta, double m, double s)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+=densityls(x,l,theta,Ftheta,m,s);}

return res*dx;
}

// Stochastic integration of the entropy
static double HRie(double l, double theta, double Ftheta)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+=(Math.pow(x,l)*theta-Ftheta)*Math.exp(Math.pow(x,l)*theta-Ftheta);}

return -res*dx;
}


static double posHRie(double l, double theta, double Ftheta)
{double x; double res=0;

for(x=0;x<=maxx;x+=dx)
	{res+=(Math.pow(x,l)*theta-Ftheta)*Math.exp(Math.pow(x,l)*theta-Ftheta);}

return -res*dx;
}


static double HRie(double l, double theta, double Ftheta, double m, double s)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+= densityls(x,l,theta,Ftheta,m,s)*logdensityls(x,l,theta,Ftheta,m,s);}

return -res*dx;
}

// closed-form entropy formula using the natural parameter space
static double Htheta(double l, double theta)
{
return Math.log(2)+	logGamma(1.0/(double)l)
   -Math.log(l)+
   (1.0/(double)l)*(1-Math.log(-theta));	
}

static double posHtheta(double l, double theta)
{
return  	logGamma(1.0/(double)l)
   -Math.log(l)+
   (1.0/(double)l)*(1-Math.log(-theta));	
}



static double Hatheta(double l, double theta, double Fal)
{double x; double res=0;

for(x=minx;x<=maxx;x+=dx)
	{res+=(Math.pow(Math.abs(x),l)*theta-Fal)*Math.exp(Math.pow(Math.abs(x),l)*theta-Fal);}

return -res*dx;
}

// Checked, same formula as Htheta without abs
static double Hatheta(double l, double theta)
{
return a(l)-(1.0/(double)l)*Math.log(-theta);
//return Math.log(2)+	logGamma(1.0/(double)l)
 //  -Math.log(l)+
  // (1.0/(double)l)*(1-Math.log(-theta));	
}


static double a(double l)
{return Math.log(2)+	logGamma(1.0/(double)l)
   -Math.log(l)+
   (1.0/(double)l);}

// Entropy of MEF using the eta coordinate system
static double Heta(double l,double eta)
{
return Math.log(2)+logGamma(1.0/(double)l)-Math.log(l)+	
(1.0/(double)l)*(Math.log(l)+1+Math.log(eta));
}

static double posHeta(double l,double eta)
{
return logGamma(1.0/(double)l)-Math.log(l)+	
(1.0/(double)l)*(Math.log(l)+1+Math.log(eta));
}

static double Haeta(double l,double eta)
{
return b(l)+(1.0/(double)l)*Math.log(eta);
//return Math.log(2)+logGamma(1.0/(double)l)-Math.log(l)+	
//(1.0/(double)l)*(Math.log(l)+1+Math.log(eta));
}

static double b(double l)
{return Math.log(2)+logGamma(1.0/(double)l)-Math.log(l)+	
(1.0/(double)l)*(Math.log(l)+1);}
   
   
static double logz(double l)
{return (l/2.0)*Math.log(2)-0.5*Math.log(Math.PI)+logGamma(0.5*(1+l));}
   
   
   
static double Ffc1(double l,double theta)
{
return Math.log(2)+	logGamma(1+1.0/(double)l)
   -(1.0/(double)l)*Math.log(-theta);

}


static double Ffc2(double l,double theta)
{
return Math.log(2)+	logGamma(1.0/(double)l)
   -(1.0/(double)l)*Math.log(-theta)-Math.log(l);

}


static double eta(double theta, double l)
{return -1.0/(l*theta);}

static double theta(double eta,double l)
{return -1.0/(l*eta);}




	static double logGamma(double x) {
      double tmp = (x - 0.5) * Math.log(x + 4.5) - (x + 4.5);
      double ser = 1.0 + 76.18009173    / (x + 0)   - 86.50532033    / (x + 1)
                       + 24.01409822    / (x + 2)   -  1.231739516   / (x + 3)
                       +  0.00120858003 / (x + 4)   -  0.00000536382 / (x + 5);
      return tmp + Math.log(ser * Math.sqrt(2 * Math.PI));
   }
}