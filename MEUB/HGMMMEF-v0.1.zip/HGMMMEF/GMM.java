class GMM
{
  int d=1;
  int k;
  
  double [] w;
  double [] mu;
  double [] sigma;
  
  double truncA, truncB;
  
  // power mean
  public  double sigmal(double l)
  {double res=0;
  int i;
  
  for(i=0;i<k;i++)
   res+=w[i]*Math.pow(sigma[i],l);
   
   
  
  return Math.pow(res,1.0/(double)l);
  }
  
  
  public static GMM random(int k)
  {double [] m=new double[k];
  double [] s=new double[k];
  double [] w=new double[k];
  double cw=0;
  int i;
  
  	for(i=0;i<k;i++)
{//m[i]=0;
	m[i]=Math.random(); 
s[i]=0.05+1*Math.random();
	w[i]= Math.random();
//w[i]=1.0/(double)k;
	 cw+=w[i];
	}
 
for(i=0;i<k;i++) w[i]/=cw;	


GMM gmm=new GMM(w,m,s);	
return gmm;
}
  
    // Entropy: stochastic approximation
  public static double Hsto(GMM m, int n)
  {
    int i;
    double res=0.0;
    double [] set=m.sample(n);
    double tmp, p;

    for (i=0; i<n; i++)
    {
      p=m.density(set[i]);	
      res+=Math.log(p);
    }

    return -res/(double)n;
  }
  
  public String toString()
  {int i;
  String res="k="+k+",";
  for(i=0;i<k;i++)
  {res=res+"("+w[i]+" m="+mu[i]+" s="+sigma[i]+")\n";}
  
  return res+"\n";
  }
  
  double mean()
  {double res=0;
  
  for(int i=0;i<k;i++) res+=w[i]*mu[i];
  
  return res;
  }
  
  double variance()
  {double res=0;
  
  for(int i=0;i<k;i++) res+=sqr(w[i])*sqr(sigma[i]);
  
  return res;
  }
  
  // Shift the GMM so has to have zero.
  void shiftToZero()
  {double m=mean();
  
  for(int i=0;i<k;i++) mu[i]=mu[i]-m;
  }
  
  void normalizeStandard()
  {double lambdaMean=mean();
  double lambdaVariance=variance();
  
  	for(int i=0;i<k;i++) 
  	{
  		if (lambdaMean!=0.0) mu[i]/=lambdaMean;
  		if (lambdaVariance!=0.0) sigma[i]/=Math.sqrt(lambdaVariance);
  	}
  }
  
  
  GMM(double[] ww, double[] m, double [] s)
  {
  this.k=m.length;
  mu=new double [k]; 
  sigma=new double [k];
  w=new double[k];
  
  for(int i=0;i<k;i++)
  {
  	w[i]=ww[i] ;mu[i]=m[i]; sigma[i]=s[i];
  	}
  	
  }
  
  
 
  
  //
  public double moment(int p)
  {double res=0;
  
  if (p<=-1) return 0;
  if (p==0) return 1;
  //System.out.println("gmm m"+p);
  
  for(int i=0;i<k;i++)
    {res+=w[i]*Gaussian.moment(p,mu[i],sigma[i]);
    //System.out.println(Gaussian.moment(p,mu[i],sigma[i]));
    }
  
 return res;
  }
  
  public String plotcmdarg()
  {String res="";
  int i,j;
  res=" ";
  for(i=0;i<k;i++)
  {j=i+1;
  res=res+"g"+j+"(x)  lt 1  lc 1  notitle , ";
  	}
  res+="m(x) lw 5 lt 1 title \"Gaussian Mixture Model (k="+k+")\"  ";
  return res;
  } 
   
  public String gnuplot()
  {
  int i,j;
  String res="", mix="m(x)=";
  
  for(i=0;i<k;i++)
  {j=i+1;
  res=res+"g"+j+"(x)=("+w[i]+")*gaussian(x,"+mu[i]+","+sigma[i]+")\n";
  mix=mix+"g"+j+"(x)+";}
  mix+="0\n";
  
  res=res+mix;
  
  

  return res;	
  }
  
  
  
  
     public static double sqr(double x){return x*x;}

 public static double gaussianDensity(double x, double m, double s)
  {
    return 1.0/(Math.sqrt(2.0*Math.PI)*s)*Math.exp(-0.5*sqr((x-m)/s));
  }

public  double  density(double x)
{
double r=0;
for(int i=0;i<k;i++)	
r+=w[i]*gaussianDensity(x,mu[i],sigma[i]);

return r;}


 public static double variate1D()
  {
    double u1=Math.random(), u2=Math.random();
    return Math.sqrt(-2.0*Math.log(u1))*Math.cos(2.0*Math.PI*u2);
  }
  
    public static double variate1D(double mu, double sigma)
  {
    	
    double z=variate1D();
    return mu+sigma*z;
  }



    double [] sample(int n)
  {
    double [] res=new double[n];
    int i;
    double u;
    double csum;
    int label;
    for (i=0; i<n; i++)
    {
      u=Math.random();
      csum=0.0; 
      label=0;
      // select component
      while (u>csum)	
      {
        csum=csum+w[label]; 
        label++;
      }
      label=label-1;
      //System.out.println("component:"+label);
      res[i]=variate1D(mu[label], sigma[label]);
    }
    return res;
  }
  
  public static double F(double theta, int l)
  {double res;
  
  res=Math.log(2)+logGamma((l+1)/(double)l)-(1.0/(double)l)*Math.log(-theta);
  return res;}
  
  // entropy for 1 gaussian
   public static double H1(double s)
   {return 0.5*Math.log(2.0*s*s*Math.PI*Math.E);}
   
   // for k=1, the aggregated variance  matches sigma2
    public static double Hvar(GMM m)
    {
    int i;
    double v=0.0;
    double mean=m.moment(1);
    
    for(i=0;i<m.k;i++)
    {
    v+=m.w[i]*(sqr(m.mu[i]-mean)+sqr(m.sigma[i]));
    }	
    	
  //  System.out.println("sigma aggreg="+Math.sqrt(v));	
    return H1(Math.sqrt(v));
    }
    
    
    public static double Habs(GMM m)
    {
    int i;
    double sig=0.0;
     
    
    for(i=0;i<m.k;i++)
    {
    sig+=m.w[i]*m.sigma[i];
    }	
    	
  //  System.out.println("sigma aggreg="+Math.sqrt(v));	
    return 1+Math.log(2*Math.sqrt(2/Math.PI)*sig);
    }
    
    
    
  
 public static double ubH(GMM m,int l)
 {double res=0.0;
 
 double ml=m.moment(l);
 // theta of MEF
 double theta=-1.0/(l*ml);
 
// System.out.println(l+" theta ubH:="+Math.sqrt(-0.5/theta));
// System.out.println("sigma ubH:="+Math.sqrt(-0.5/theta));
 
 double ratio= (gamma((l+1)/(double)l))/((l/2.0)*Math.pow(-theta,1.0/(double)l));
 
 res=(Math.exp(-F(theta,l))*ratio)  +F(theta,l);
 
 return res;
 }

  public static double KLsto(GMM m1, GMM m2, int n)
  {
    int i;
    double res=0.0;
    double [] set=m1.sample(n);
    double tmp, p, q;

    for (i=0; i<n; i++)
    {
      p=m1.density(set[i]);
      q=m2.density(set[i]);	
      tmp=Math.log(p/q)+(q/p)-1.0; // Burg entropy...	
      res+=tmp;
    }

    return res/(double)n;
  }
  
  // from http://introcs.cs.princeton.edu/java/91float/Gamma.java
  
     static double logGamma(double x) {
      double tmp = (x - 0.5) * Math.log(x + 4.5) - (x + 4.5);
      double ser = 1.0 + 76.18009173    / (x + 0)   - 86.50532033    / (x + 1)
                       + 24.01409822    / (x + 2)   -  1.231739516   / (x + 3)
                       +  0.00120858003 / (x + 4)   -  0.00000536382 / (x + 5);
      return tmp + Math.log(ser * Math.sqrt(2 * Math.PI));
   }
   static double gamma(double x) { return Math.exp(logGamma(x)); }
   
   // more 
   private static double[] getPowerSeries1F1(final double aValue,
            final double bValue, final double zValue) {
        // Set up for power series summation
        double an = aValue, bn = bValue;
        double a0 = 1.0, n = 1.0, t = 1.0;
        double maxt = 0.0;
        double[] result = {1.0, 0.0};   // sum, error
        while (t > Double.MIN_VALUE) {
            // Check bn first since if both an and bn are zero it is a
            // singularity
            if (bn == 0) {
                result[0] = Double.POSITIVE_INFINITY;
                return result;
            }
            if (an == 0) {
                return result;
            }
            if (n > 200) {
                break;
            }
            final double u = zValue * (an / (bn * n));

            // Check for blowup (100% error)
            if ((Math.abs(u) > 1.0)
                    && (maxt > (Double.MAX_VALUE / Math.abs(u)))) {
                result[1] = 1.0;
                return result;
            }
            a0 *= u;
            result[0] += a0;
            t = Math.abs(a0);
            if (t > maxt) {
                maxt = t;
            }
            an += 1.0;
            bn += 1.0;
            n += 1.0;
        }

        // Estimate error due to roundoff and cancellation
        if (result[0] != 0.0) {
            maxt /= Math.abs(result[0]);
        }
        maxt *= Double.MIN_VALUE;
        result[1] = Math.abs(Double.MIN_VALUE * n + maxt);
        return result;
    }

    /**
     * Calculate the asymptotic series summation for 1F1.
     *
     * @param aValue A value
     * @param bValue B value
     * @param zValue Z value
     * @return Asymptotic series summation for 1F1 and calculation error
     */
    private static double[] getAsymptoticSeries1F1(final double aValue,
            final double bValue, final double zValue) {
        double[] result = {0.0, 0.0};
        if (zValue == 0.0) {
            result[0] = Double.POSITIVE_INFINITY;
            result[1] = 1.0;
            return result;
        }

        double temp = Math.log(Math.abs(zValue));
        double t = zValue + temp * (aValue - bValue);
        double u = -temp * aValue;
        if (bValue > 0.0) {
            temp = logGamma(bValue);
            t += temp;
            u += temp;
        }

        double[] hyp1 = getHyperG2F0(aValue, aValue - bValue + 1,
                -1.0 / zValue, 1);
        temp = Math.exp(u) / gamma(bValue - aValue);
        hyp1[0] *= temp;
        hyp1[1] *= temp;

        double[] hyp2 = getHyperG2F0(bValue - aValue, 1.0 - aValue,
                1.0 / zValue, 2);
        if (aValue < 0) {
            temp = Math.exp(t) / gamma(aValue);
        } else {
            temp = Math.exp(t - logGamma(aValue));
        }
        hyp2[0] *= temp;
        hyp2[1] *= temp;

        if (zValue < 0.0) {
            result[0] = hyp1[0];
        } else {
            result[0] = hyp2[0];
        }

        result[1] = Math.abs(hyp1[1]) + Math.abs(hyp2[1]);
        if (bValue < 0.0) {
            temp = gamma(bValue);
            result[0] *= temp;
            result[1] *= Math.abs(temp);
        }
        if (result[0] != 0.0) {
            result[1] /= Math.abs(result[0]);
        }

        // Fudge factor, since error of asymptotic formula often seems this
        // much larger than advertised
        result[1] *= 30.0;
        return result;
    }

    /**
     * Calculate the confluent hypergeometric function 2F0.
     *
     * @param aValue A value
     * @param bValue B value
     * @param zValue Z value
     * @param type Determines what converging factor to use
     * @return Confluent hypergeometric function 2F0 evaluated at (a, b, z) and
     * calculation error
     */
    private static double[] getHyperG2F0(final double aValue,
            final double bValue, final double zValue, final int type) {
        double an = aValue, bn = bValue;
        double a0 = 1.0, alast = 1.0, n = 1.0, t;
        double maxt = 0.0;
        double tlast = 1000000000;
        double[] result = {0.0, 0.0};
        boolean did_converge = false;
        do {
            if (an == 0.0 || bn == 0.0) {
                did_converge = true;
                break;
            }

            // Check for blowup
            final double u = an * (bn * zValue / n);
            if ((Math.abs(u) > 1.0)
                    && (maxt > (Double.MAX_VALUE / Math.abs(u)))) {
                result[1] = 1; //Double.MAX_VALUE;
                return result;
            }

            a0 *= u;
            t = Math.abs(a0);

            // Terminating condition for asymptotic series
            if (t > tlast) {
                break;
            }

            // The sum is one term behind
            tlast = t;
            result[0] += alast;
            alast = a0;

            if (n > 200) {
                break;
            }

            an += 1.0e0;
            bn += 1.0e0;
            n += 1.0e0;
            if (t > maxt) {
                maxt = t;
            }
        } while (t > Double.MIN_VALUE);

        // Series converged! (estimate error due to roundoff and cancellation)
        if (did_converge) {
            result[0] += a0;
            result[1] = Math.abs(Double.MIN_VALUE * (n + maxt));
            return result;
        } // Series did not converge
        else {
            n -= 1.0;
            final double z_value_inv = 1.0 / zValue;
            if (type == 1) {
                alast *= (0.5 + (0.125 + 0.25 * bValue - 0.5 * aValue
                        + 0.25 * z_value_inv - 0.25 * n) / z_value_inv);
            } else if (type == 2) {
                alast *= 2.0 / 3.0 - bValue + 2.0 * aValue + z_value_inv - n;
            }

            // Estimate error due to roundoff, cancellation, and nonconvergence
            result[1] = Double.MIN_VALUE * (n + maxt) + Math.abs(a0);
        }
        result[0] += alast;
        return result;
    }

    // *************************************************************************
    // PUBLIC METHODS
    // *************************************************************************
    /**
     * Calculate the confluent hypergeometric function 1F1.
     *
     * @param aValue A value
     * @param bValue B value
     * @param zValue z value
     * @return Confluent hypergeometric function 1F1 evaluated at (a, b, z)
     */
    public static double eval1f1(final double aValue, final double bValue,
            final double zValue) {
        // See if a Kummer transformation will help
        if (Math.abs(bValue - aValue) < 0.001 * Math.abs(aValue)) {
            return (Math.exp(zValue) * eval1f1(bValue - aValue, bValue,
                    -zValue));
        }

        // Power series
        final double[] power_sum = getPowerSeries1F1(aValue, bValue, zValue);
        if (power_sum[1] < 1e-15) {
            return power_sum[0];
        }

        // Asymptotic series
        final double[] asym_sum = getAsymptoticSeries1F1(aValue, bValue,
                zValue);

        // Pick the result with less estimated error
        return asym_sum[1] < power_sum[1] ? asym_sum[0] : power_sum[0];
    }
   
}