 
public class Gaussian {
	
	 public static int fact(int n)
  {
    int res=1;
    int i;
    for (i=2; i<=n; i++) res*=i;
    return res;
  }

  public static int doublefactPlain(int n)
  {
    if (n<=1) return 1;
    int res=1;
    int i;
    for (i=n; i>=1; i-=2) res*=i;
    return res;
  }
  
  // z!! = \sqrt{\frac{2^{z+1}}{\pi}} \Gamma(\frac{z}{2}+1)
   public static int doublefact(int n)
  {
     
    return (int)(Math.sqrt(Math.pow(2,n+1)/Math.PI)*gamma((double)n/2.0+1));
  }

static double logGamma(double x) {
      double tmp = (x - 0.5) * Math.log(x + 4.5) - (x + 4.5);
      double ser = 1.0 + 76.18009173    / (x + 0)   - 86.50532033    / (x + 1)
                       + 24.01409822    / (x + 2)   -  1.231739516   / (x + 3)
                       +  0.00120858003 / (x + 4)   -  0.00000536382 / (x + 5);
      return tmp + Math.log(ser * Math.sqrt(2 * Math.PI));
   }
   static double gamma(double x) { return Math.exp(logGamma(x)); }
   
   
  public static int choose(int n, int k)
  {
    int res=1;

    if (k>(n/2)) return choose(n, n-k);

    for (int i=n; i>=n-k+1; i--) res*=i;

    return res/fact(k);
  }


// central absolute moment
// https://arxiv.org/pdf/1209.4340v2.pdf
public static double absMoment(int l, double sigma)
{
return Math.pow(sigma,l)*Math.pow(2,0.5*l)*gamma(0.5*(1+l))/Math.sqrt(Math.PI);
	
}


public static double moment(int p, double mu, double sigma)
  {
    int i;
    double res=0;
    for (i=0; i<=(p/2); i++) 
    {
      res+=choose(p, 2*i)*doublefact(2*i-1)*Math.pow(mu, p-2*i)*Math.pow(sigma, 2*i);
    }
    
    //System.out.println(">m"+p+" "+mu+" "+sigma);
    return res;
  }
  
   public static double sqr(double x)
   {return x*x;}
 
 public static double truncatedMoment(int p, double mu, double sigma, double a, double b)
  {
 if (p==-1) return 0;
 if (p==0) return 1;
 else
  	{double res;
  	double ratio, tb=(b-mu)/sigma, ta=(a-mu)/sigma;
  	
  	ratio=(Math.pow(b,p-1)*pdf(tb)-Math.pow(a,p-1)*pdf(ta))/(cdf(tb)-cdf(ta));
  	
  	res=(p-1)*sqr(sigma)*truncatedMoment(p-2,mu,sigma,a,b)+
  	mu*truncatedMoment(p-1,mu,sigma,a,b)-sigma*ratio;
     
    return res;
  }
  }
   
  

    // return pdf(x) = standard Gaussian pdf
    public static double pdf(double x) {
        return Math.exp(-x*x / 2) / Math.sqrt(2 * Math.PI);
    }

    // return pdf(x, mu, signma) = Gaussian pdf with mean mu and stddev sigma
    public static double pdf(double x, double mu, double sigma) {
        return phi((x - mu) / sigma) / sigma;
    }

    // return cdf(z) = standard Gaussian cdf using Taylor approximation
    public static double cdf(double z) {
        if (z < -8.0) return 0.0;
        if (z >  8.0) return 1.0;
        double sum = 0.0, term = z;
        for (int i = 3; sum + term != sum; i += 2) {
            sum  = sum + term;
            term = term * z * z / i;
        }
        return 0.5 + sum * phi(z);
    }

    // return cdf(z, mu, sigma) = Gaussian cdf with mean mu and stddev sigma
    public static double cdf(double z, double mu, double sigma) {
        return cdf((z - mu) / sigma);
    } 

    // Compute z such that cdf(z) = y via bisection search
    public static double inverseCDF(double y) {
        return inverseCDF(y, 0.00000001, -8, 8);
    } 

    // bisection search
    private static double inverseCDF(double y, double delta, double lo, double hi) {
        double mid = lo + (hi - lo) / 2;
        if (hi - lo < delta) return mid;
        if (cdf(mid) > y) return inverseCDF(y, delta, lo, mid);
        else              return inverseCDF(y, delta, mid, hi);
    }


    // return phi(x) = standard Gaussian pdf
    @Deprecated
    public static double phi(double x) {
        return pdf(x);
    }

    // return phi(x, mu, signma) = Gaussian pdf with mean mu and stddev sigma
    @Deprecated
    public static double phi(double x, double mu, double sigma) {
        return pdf(x, mu, sigma);
    }

    // return Phi(z) = standard Gaussian cdf using Taylor approximation
    @Deprecated
    public static double Phi(double z) {
        return cdf(z);
    }

    // return Phi(z, mu, sigma) = Gaussian cdf with mean mu and stddev sigma
    @Deprecated
    public static double Phi(double z, double mu, double sigma) {
        return cdf(z, mu, sigma);
    } 

    // Compute z such that Phi(z) = y via bisection search
    @Deprecated
    public static double PhiInverse(double y) {
        return inverseCDF(y);
    } 

    // test client
    public static void main(String[] args) {
        double z     = Double.parseDouble(args[0]);
        double mu    = Double.parseDouble(args[1]);
        double sigma = Double.parseDouble(args[2]);
        System.out.println(cdf(z, mu, sigma));
        double y = cdf(z);
        System.out.println(inverseCDF(y));
    }
}

 