class Edge 
{Point p1,p2;

Edge()
{
p1=new Point(0,0);
p2=new Point(0,0);
}

Edge(Point q1, Point q2)
{
 p1=q1;
 p2=q2;
}

}
