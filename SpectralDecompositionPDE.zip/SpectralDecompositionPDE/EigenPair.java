import Jama.*;

class EigenPair implements Comparable<EigenPair>
{
 double eigenvalue;
 Matrix eigenvector;
 
 public int compare(EigenPair o1, EigenPair o2) {
            if (o1.eigenvalue>o2.eigenvalue) return -1; else return 1;
        }
        
        public int compareTo(EigenPair o1) {
            if (o1.eigenvalue>this.eigenvalue) return -1; else return 1;
        }
        
        
        
double norm()
{
  return Math.sqrt(this.InnerProduct(this));
}

double InnerProduct(EigenPair e1)
{
  int i, d=e1.eigenvector.getRowDimension();
  double res=0;

  for (i=0; i<d; i++)
  {
    res+=e1.eigenvector.get(i, 0)*this.eigenvector.get(i, 0);
  }

  return res;
}


static double InnerProduct(EigenPair e1, EigenPair e2)
{
  int i, d=e1.eigenvector.getRowDimension();
  double res=0;

  for (i=0; i<d; i++)
  {
    res+=e1.eigenvector.get(i, 0)*e2.eigenvector.get(i, 0);
  }

  return res;
}


}
